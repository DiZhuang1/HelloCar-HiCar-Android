package com.hellocar.car

import android.app.Activity
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * M2c 全屏渲染视图：连接成功后自动切入，显示 HiCar 投屏画面。
 *
 * - TextureView 全屏（800×480 信号拉伸到屏幕），MediaRenderer 解码渲染；
 *   v0.10.46 由 SurfaceView 改 TextureView：后者参与窗口合成，不会因兄弟视图
 *   elevation 破坏 punch hole 而"必须点一下屏幕才显影"。
 * - 触摸事件 → 归一化 [0,1] → nativeSendInput(INPUT_TOUCH)（按下/移动/抬起）；
 * - 音量/方向键（可选按键）→ nativeSendInput(INPUT_KEY)；
 * - 退出按钮返回主界面（停止媒体链路）；
 * - 状态浮层显示：链路阶段、解码帧数、PCM 字节、最后日志。
 */
class RenderActivity : Activity(), TextureView.SurfaceTextureListener {

    private lateinit var overlay: TextView
    private lateinit var renderSurface: TextureView
    private var renderSurfaceObj: Surface? = null
    private var renderer: MediaRenderer? = null
    private var audioPlayer: AudioPlayer? = null
    private var mediaSession: MediaSession? = null
    private val sessionRef = AtomicReference<MediaSession?>(null)
    private val touching = AtomicBoolean(false)
    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val lastLogs = ArrayDeque<String>()
    private var lastMediaState = "media:未启动"

    companion object {
        // v0.10.48: 持有当前投屏页实例——MainActivity 检测到蓝牙/TCP 断开后直接收口，
        // 不必等 45 秒看门狗（用户诉求：断开后应该自动回到主页）。
        @Volatile
        private var active: java.lang.ref.WeakReference<RenderActivity>? = null

        /** 对端链路已断开：延迟 6 秒收口，给重连留出窗口。 */
        fun notifyPeerLost() {
            active?.get()?.let { it.uiHandler.postDelayed(it.peerLostFinish, 6000) }
        }

        /** 链路恢复：撤销待执行的收口。 */
        fun notifyPeerBack() {
            active?.get()?.let { it.uiHandler.removeCallbacks(it.peerLostFinish) }
        }

        /**
         * v0.10.56: 主动关掉当前投屏页（必须在主线程调用）。
         * 用途是发起新一轮连接前清场：1111(34) 证明旧 MediaSession 会一直占着视频通道
         * （日志里视频流还在 1700/1800/1900 地涨），新会话一进来手机就判重复会话，
         * 把蓝牙和 TCP 4005-4007 一起掐掉。返回是否真的关掉了一个页面。
         */
        fun closeIfActive(): Boolean {
            val a = active?.get() ?: return false
            a.finish()
            return true
        }
    }

    private val peerLostFinish = Runnable { finish() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // v0.10.53: 全屏化。车机默认给 Activity 套系统标题栏（1111(31) 照片顶部
        // 那条 "HelloCar 车机端" 白带）和状态栏，两个后果：一是白边吃掉屏占比
        // （用户要求"画面大小直接扩大"），二是 Activity 内容区与屏幕不一致，
        // 会让按 View 宽高归一化的触摸坐标整体偏移。Manifest 已补 theme 双保险，
        // 这里再在窗口层面强制去标题栏 + 全屏 + 沉浸式。
        requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        window.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_render)
        applyImmersive()
        // v0.10.66: 不再清空 hellocar_media.log。
        // 原来这里 writeText("") 抹掉上一轮日志，为的是避免旧端口混入分析；但代价是
        // 「上一次断联到底停在哪一行」被连同证据一起删掉——用户已反馈主界面看不到断联日志，
        // 而车机文件管理器又进不去 /data/data 私有目录，等于彻底拿不到。
        // 改成只追加一行会话分隔：既保留历史，又能区分边界。
        try {
            java.io.File(filesDir, "hellocar_media.log")
                .appendText("===== 新投屏会话 ${System.currentTimeMillis()} =====\n")
        } catch (_: Exception) {}

        renderSurface = findViewById(R.id.renderSurface)
        renderSurface.surfaceTextureListener = this
        // v0.10.52: TextureView 默认 isOpaque=false，走的是带 alpha 的合成路径。
        // 车机 GPU 在该路径下典型症状就是"首帧不进合成队列、要点一次屏幕才刷出来"。
        // 1111(27)(28)(29)(30) 四轮都报这个现象，而去 elevation / 换 TextureView /
        // 每帧 postInvalidateOnAnimation 三种解法全部无效——所以改从合成模式下手。
        renderSurface.setOpaque(true)
        // v0.10.56: 第 7 个"点一下才出画面"的方案——让渲染层自己拿触摸焦点。
        // 前六个方案（去 elevation / 换 TextureView / 每帧 invalidate / setOpaque /
        // setDefaultBufferSize / onWindowFocusChanged）全部失效，但现象始终一致：
        // 用户手指落下后画面立刻出现。说明车机合成器认的是"这个窗口被触摸过"这个
        // 状态，而不是"窗口有焦点"。isFocusableInTouchMode + requestFocus 会让
        // 系统在触摸模式下把这个 View 标成已聚焦并派发一次 focus 变更，
        // 对合成器而言与一次真实触摸的窗口状态变化等价，且不会向手机回传触摸。
        renderSurface.isFocusableInTouchMode = true
        renderSurface.requestFocus()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        active = java.lang.ref.WeakReference(this)

        // v0.10.86: 车机常驻导航栏避让——只算像素值，**绝不动 View 的尺寸**。
        // v0.10.85 用 layoutParams.bottomMargin 给 TextureView 留白，实测三个副作用：
        // ① 画面走 fitCenter 等比缩小，左右留黑边（用户要的是"长度不变、只压高度"）；
        // ② TextureView 尺寸变化触发 Surface 重建 → onSurfaceTextureAvailable 会
        //    sessionRef.stop() 并重建 MediaRenderer/AudioPlayer，输入通道一起被拆；
        // ③ 于是方向盘/方控键全部失效。
        // 正确做法：View 保持全屏，只在 applyVideoAspect 里把画面纵向压到导航栏上方。
        val navInsetDp = HellocarConfig.Display.navInsetDp(this)
        navInsetPx = (navInsetDp * resources.displayMetrics.density).toInt()

        overlay = findViewById(R.id.renderOverlay)
        findViewById<Button>(R.id.btnExit).setOnClickListener { goHome() }
        // v0.10.52: 绝不能给 overlay 设 OnClickListener。View.setOnClickListener()
        // 会隐式把 clickable 置 true，浮层重新变成可点击，其矩形（左下角日志那块）
        // 会吃掉落在上面的触摸，事件到不了 Activity.onTouchEvent——用户 1111(30)
        // 问"左下角日志区是否对触屏有影响"，答案就是这行。
        startWatchdog()
        // v0.10.86: 避让一旦生效就打一条落地日志——v0.10.85 改了 dp 却没有任何记录，
        // 用户无法确认设置到底有没有被投屏页读到。
        if (navInsetPx > 0) {
            appendMediaLog("导航栏避让 ${navInsetDp}dp 已生效（画面横向铺满、纵向压到顶部）")
        }
        // v0.10.46: 页面刚建立的前 3 秒每 300ms 主动重绘一次——TextureView 由普通
        // 绘制流程合成，配合重绘可在 SurfaceTexture 首帧到达前保持稳定显示。
        val wake = android.os.Handler(mainLooper)
        wake.postDelayed(object : Runnable {
            var n = 0
            override fun run() {
                renderSurface.postInvalidate()
                if (++n < 10) wake.postDelayed(this, 300)
            }
        }, 300)
    }

    /** v0.10.53: 沉浸式全屏——隐藏状态栏/导航栏，并让内容延伸到这两块区域。 */
    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    /** v0.10.22 两段式看门狗：从未收到媒体 → 全局 120s 超时退出；
     *  收到过媒体 → 之后 45s 无帧/音频即退出（RTSP 协商慢不再被 45s 误杀）。 */
    private fun startWatchdog() {
        val startTime = System.currentTimeMillis()
        var lastMediaAt = 0L
        val runnable = object : Runnable {
            override fun run() {
                val frames = renderer?.decodedFrames() ?: 0L
                val pcm = audioPlayer?.pcmBytes() ?: 0L
                val now = System.currentTimeMillis()
                if (frames > 0 || pcm > 0) lastMediaAt = now
                if (lastMediaAt == 0L) {
                    if (now - startTime > 120_000) {
                        appendMediaLog("投屏 120 秒未建立媒体链路，自动退出（请回主界面查看完整日志）")
                        finish()
                        return
                    }
                } else if (now - lastMediaAt > 12_000) {
                    // v0.10.50: 45s→12s，并改用「媒体静默」作为唯一退出判据。
                    // 手机投屏建立后主动关蓝牙属正常，不能代表投屏结束；视频+音频同时
                    // 12 秒无新增才是真的断了（1111(30) 三段会话断链后音频立刻归零）。
                    appendMediaLog("投屏 12 秒无媒体数据，自动退出（请回主界面查看完整日志）")
                    finish()
                    return
                }
                uiHandler.postDelayed(this, 5_000)
            }
        }
        uiHandler.postDelayed(runnable, 5_000)
    }

    override fun onResume() {
        super.onResume()
        // v0.10.55: 回到前台重新压一次沉浸式（防车机系统栏复现），与 onCreate 一致。
        applyImmersive()
        // 注册媒体回调（帧/音频）——nativeFeed 后由 JNI 调用。
        // 注意：回调在 feed 调用线程执行，实现内部自行 post 到 HandlerThread。
        val renderer = this.renderer
        val audioPlayer = this.audioPlayer
        if (renderer != null) HelloCarBridge.nativeSetFrameCallback(renderer)
        if (audioPlayer != null) HelloCarBridge.nativeSetAudioCallback(audioPlayer)
        // v0.10.80: 回到前台重新申请一次音频焦点（onPause 不放弃，只在这里续约）。
        requestAudioFocus()
        val session = sessionRef.get()
        if (session != null) session.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // v0.10.52: 窗口拿到焦点时主动刷一次。车机系统对"尚未获得焦点的窗口"
        // 常延后合成，用户的一次点击正好让它转成前台合成——这就是"点一下才出画面"
        // 的另一半解释。这里在焦点变化时就补上这一次。
        if (hasFocus) {
            // v0.10.55: 车机 Launcher 会在窗口失焦/回前台时把系统栏（顶部时间条、
            // 导航条）重新弹出来，盖在我们已经铺满的画面顶部——1111(33) 用户报的
            // "扩大到通知栏但被原生通知栏遮挡"。每次拿到焦点都重新压一次沉浸式。
            applyImmersive()
            renderSurface.invalidate()
            renderSurface.postInvalidateOnAnimation()
        }
    }

    override fun onPause() {
        super.onPause()
        // v0.10.62 自检修复：这里原来调 sessionRef.getAndSet(null)?.stop()，是错的方向。
        // onPause 在投屏页"被系统弹窗压住、车机 Launcher 抢焦点、权限对话框"时都会触发，
        // 而 stop() 会给手机发 TEARDOWN 并关闭 RTSP 长连接 —— 一次遮挡就把整条会话退役，
        // 并且 sessionRef 已被置 null，onResume 的 session.start() 拿不到实例、不会重启，
        // 投屏永久黑掉。这里改为只解注册回调，会话与线程全部保持（车机常电，后台续跑代价很小），
        // 遮挡消失后 onResume 重新注册即立刻有画面。
        // v0.10.76: 只摘视频帧回调，音频回调必须保留。
        // 会话本身是存活的（见上），但把 audio callback 也置 null 之后，HiSight 推来的
        // 音频包没有接收者，AudioPlayer 直接断流——这就是"返回主界面声音暂停"的机制：
        // 画面还在投、会话还没退，声音却没了。音频不依赖 Surface，没有摘掉的理由。
        // 真正退出投屏页时由 onDestroy 统一摘除，避免回调指向已释放的播放器。
        HelloCarBridge.nativeSetFrameCallback(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        logRunning = false
        // v0.10.80: 退出投屏页才放弃音频焦点，onPause 不放弃——
        // 否则被系统弹窗短暂压住时焦点就被让出去，回来还得重新竞争。
        abandonAudioFocus()
        // v0.10.76: onPause 不再摘音频回调，所以退出投屏页时必须在这里统一摘掉，
        // 否则 native 侧仍持有指向已释放 AudioPlayer 的引用。
        HelloCarBridge.nativeSetAudioCallback(null)
        HelloCarBridge.nativeSetFrameCallback(null)
        renderer?.stop()
        audioPlayer?.stop()
        // v0.10.83 自检修复：onSurfaceTextureDestroyed 里已经清过一次，但那条回调
        // 在"Activity 被系统直接销毁、Surface 未走 destroyed"的路径上不会触发，
        // 留着就是让 MediaSession 的视频线程去调一个已经 stop 的播放器。这里兜底。
        MediaGlobals.audioStopper = null
        // 真正退出投屏页才退役会话（发 TEARDOWN + 关 RTSP）。其余场景一律保持会话存活，
        // 详见 MediaSession.stop(retire) 的注释。
        sessionRef.getAndSet(null)?.stop(retire = true)
        active?.let { if (it.get() === this) active = null }
    }

    // ------------------------------------------------------------ surface holder --

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        // v0.10.61: 尺寸取 MediaGlobals（主界面设置面板写入），不再写死。
        // 不设时 SurfaceTexture 默认取 View 尺寸（车机屏实际像素），MediaCodec 输出
        // 协商尺寸后还要额外做一次尺寸变换，部分设备会丢首帧。
        val vw = MediaGlobals.videoW
        val vh = MediaGlobals.videoH
        // v0.10.76: 回退 v0.10.74 的 buffer=View 尺寸。
        // 1111(46) 的解码帧率采样证明了代价：22.8 → 2.4fps 剧烈抖动、平均仅约 15fps，
        // 而队列积压恒为 1（post 没有堆积，是解码器吞吐本身被打穿）。
        // 1920×1080 的像素填充率是 1280×720 的 2.25 倍，这台车机的 GPU 扛不住。
        // 清晰度改由码率补偿，流畅性优先：buffer 回到协商尺寸，只保留一次上采样。
        runCatching { st.setDefaultBufferSize(vw, vh) }
        // v0.10.41: 回调可能被调用多次（Surface 重建），旧会话必须先停——
        // 否则两个 MediaSession 并发跑 runChain：各自连一次视频端口、各自
        // nativeOpenChannel，手机端面对重复媒体连接可能放弃推流（1111(25) 实测
        // 「media:等待 HiSight RTSP 端口」两段连续打印 = 双链路叠加）。
        sessionRef.getAndSet(null)?.stop()
        // v0.10.62 自检修复：旧渲染器/播放器必须先释放。这个回调在 Surface 重建
        // （Activity 重建、TextureView 重新 attach）时会被再调一次，原来直接覆盖字段，
        // 旧 MediaCodec 与 AudioTrack 没人 release —— 每重建一次泄漏一套硬解码器实例，
        // 几次之后 MediaCodec 池耗尽，表现为"投屏突然黑屏且再也起不来"。
        this.renderer?.stop()
        this.audioPlayer?.stop()
        val target = Surface(st)
        renderSurfaceObj = target
        appendMediaLog("渲染层就绪（TextureView ${width}x$height，协商 ${vw}x$vh，buffer 取协商尺寸）")
        val renderer = MediaRenderer(
            target,
            log = { appendMediaLog(it) },
            // v0.10.64: 不再每帧 postInvalidateOnAnimation。TextureView 的 SurfaceTexture
            // 内容更新由合成器直接取用，本来就不需要 invalidate；每帧触发一次 View
            // 的 invalidate→measure→layout→draw，是车机弱 GPU 上滑动卡顿的主要来源
            // （这招当初是为"免点击显影"加的，已被实车证伪，现在画面通路已通，去掉）。
            onFrameRendered = null,
            // v0.10.76: 解码格式回到协商尺寸。MediaCodec 最终以 SPS 为准，这里是
            // Surface 输出目标的 hint；与上面的 setDefaultBufferSize 保持一致。
            width = vw,
            height = vh,
            // v0.10.64: 拿到解码器真实输出的宽高，按比例修正 TextureView 的拉伸。
            // 同时把 SurfaceTexture 的 buffer 尺寸改成真实视频尺寸——协商值（
            // MediaGlobals.videoW/H）只是我们请求的尺寸，手机可能按自己的屏幕比例
            // 编码，两者不一致时 buffer 会再被二次缩放一次，字就更糊了。
            onVideoSize = { fw, fh ->
                renderSurface.post {
                    // v0.10.74: 不再把 buffer 改回视频真实尺寸——buffer 恒为 View 尺寸，
                    // 缩放只在 MediaCodec 输出端做一次。这里只按真实比例做 fitCenter。
                    applyVideoAspect(fw, fh)
                }
            }
        )
        this.renderer = renderer
        renderer.start()
        val audioPlayer = AudioPlayer(log = { appendMediaLog(it) })
        this.audioPlayer = audioPlayer
        audioPlayer.start()
        // v0.10.81: 把播放器交给 MediaSession，视频通道彻底放弃时联动停它。
        // 否则画面已经没了一直黑着，音频 UDP 还在收、AudioTrack 还在响。
        MediaGlobals.audioStopper = { audioPlayer.stop() }

        // 从 MainActivity 继承的链路参数：手机 IP（热点 DHCP）与音频 UDP socket。
        // v0.10.20: rtsp_port 由 MainActivity 随 Intent 传入（1111(8) 实测轮询读不到）。
        val rtspPortHint = intent.getIntExtra("rtsp_port", -1)
        val phoneIp = MediaGlobals.phoneIp
        val audioSocket = MediaGlobals.audioSocket?.takeIf { !it.isClosed } ?: run {
            val audioPort = intent.getIntExtra("audio_port", -1)
            if (audioPort > 0) {
                try {
                    val socket = java.net.DatagramSocket(null)
                    socket.reuseAddress = true
                    socket.bind(java.net.InetSocketAddress(audioPort))
                    socket
                } catch (e: Exception) {
                    null
                }
            } else {
                null
            }
        }
        val session = MediaSession(
            phoneIp = phoneIp,
            audioSocket = audioSocket,
            rtspPortHint = rtspPortHint,
            log = { appendMediaLog(it) },
            // v0.10.22: 状态变化同时落盘（此前仅 UI 更新，RTSP 连接失败/视频端口超时均不可见）。
            onState = { state ->
                lastMediaState = state
                // v0.10.26: 移除直接 refreshOverlay()——它在 MediaSession 线程（非主线程）
                // 操作 overlay.text 抛 CalledFromWrongThreadException，runChain 死在第一行，
                // 后续"端口获取/复用/连接"全不执行（1111(14/15/16) 投屏页 RTSP 段反复不落盘
                // 的真正根因）。appendMediaLog 内部已 uiHandler.post(refreshOverlay)。
                appendMediaLog(state)
            },
            frameSink = renderer,
            audioSink = audioPlayer,
        )
        sessionRef.set(session)
        HelloCarBridge.nativeSetFrameCallback(renderer)
        HelloCarBridge.nativeSetAudioCallback(audioPlayer)
        session.start()
    }

    private var lastVideoW = 0
    private var lastVideoH = 0
    private var aspectLogged = false
    /** v0.10.86: 车机常驻导航栏要留的高度（px）。0 = 不避让，走原来的 fitCenter。 */
    private var navInsetPx = 0

    /**
     * v0.10.64: 按视频真实比例修正 TextureView 的拉伸。
     *
     * 车机屏是超宽比例（照片实测约 2.2:1），手机推的是 16:9，而 TextureView 默认把
     * 画面拉伸铺满 View —— 横向被拉长约 1.3 倍，这就是"连接后字体被拉长"的直接原因：
     * 不是编码模糊，是几何拉伸。这里用 fitCenter 保持比例，多出来的边缘留黑，
     * 保证导航文字和图标不变形。
     */
    private fun applyVideoAspect(fw: Int, fh: Int) {
        if (fw <= 0 || fh <= 0) return
        lastVideoW = fw
        lastVideoH = fh
        val vw = renderSurface.width
        val vh = renderSurface.height
        if (vw <= 0 || vh <= 0) return
        val vwf = vw.toFloat()
        val vhf = vh.toFloat()
        // v0.10.67 修裁切：TextureView 的 buffer 默认就已经被拉伸铺满视图，
        // setTransform 是叠加在「默认铺满」之上的二次变换，所以这里只能算相对系数。
        // v0.10.64~66 用的是绝对缩放 min(vw/fw, vh/fh)=1.50（1280×720 → 1920×1080），
        // 等于把已经铺满的画面再放大 1.5 倍，实际 2.25 倍 → 只剩画面中间 44%，
        // 右侧「北庄/小桥头村」被整块裁掉（1111(37) 实拍 + 该版日志第 146 行）。
        val m = android.graphics.Matrix()
        var kxLog = 1f
        var kyLog = 1f
        var dxLog = 0f
        var dyLog = 0f
        if (navInsetPx > 0) {
            // v0.10.86: 导航栏避让模式。
            // 用户的诉求是"长度不变、只把高度压到导航栏上方"（原话：100×80 → 100×60），
            // 所以这里横向 kx=1 铺满整宽、纵向压到 (vh - inset) 且顶部对齐，
            // 不走 fitCenter 等比缩小（那会四周留黑边，正是 v0.10.85 被否掉的做法）。
            // 代价是画面纵向轻微压扁，这是"不遮挡 + 不缩窄"的必然取舍。
            val usable = (vhf - navInsetPx).coerceAtLeast(vhf * 0.5f)
            kxLog = 1f
            kyLog = usable / vhf
            dyLog = 0f
            m.setScale(1f, kyLog)
        } else {
            val sx = vwf / fw
            val sy = vhf / fh
            val s = minOf(sx, sy)
            val kx = s / sx          // 相对默认铺满的横向系数：同比例时为 1.0
            val ky = s / sy
            val dw = vwf * kx
            val dh = vhf * ky
            val dx = (vwf - dw) / 2f
            val dy = (vhf - dh) / 2f
            kxLog = kx
            kyLog = ky
            dxLog = dx
            dyLog = dy
            m.setScale(kx, ky)
            m.postTranslate(dx, dy)
        }
        renderSurface.setTransform(m)
        if (!aspectLogged) {
            aspectLogged = true
            appendMediaLog(
                "画面比例校正：视频 ${fw}×$fh → 视图 ${vw}×$vh，" +
                    "缩放系数 ${String.format("%.2f", kxLog)}×${String.format("%.2f", kyLog)}，" +
                    "黑边 x=$dxLog y=$dyLog"
                    + if (navInsetPx > 0) "（导航栏避让 ${navInsetPx}px 生效）" else ""
            )
        }
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
        // View 尺寸变了，之前的变换矩阵失效，按最后一次拿到的视频尺寸重算。
        if (lastVideoW > 0 && lastVideoH > 0) applyVideoAspect(lastVideoW, lastVideoH)
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        renderer?.stop()
        renderer = null
        audioPlayer?.stop()
        audioPlayer = null
        MediaGlobals.audioStopper = null
        // v0.10.62 自检修复：这个回调在 Activity finish 时比 onDestroy 更早触发，
        // 原来的无条件 stop() 会把会话停掉并置 null，等 onDestroy 再想 retire 时已经
        // 拿不到实例 —— TEARDOWN 永远发不出去、RTSP 长连接也不关，手机侧留着脏会话。
        // 用 isFinishing 区分「正在退出」与「仅 Surface 重建」。
        sessionRef.getAndSet(null)?.stop(retire = isFinishing)
        renderSurfaceObj?.let { runCatching { it.release() } }
        renderSurfaceObj = null
        return true
    }

    // --------------------------------------------------------------- touch/key --

    private var touchGeomLogged = false

    /**
     * v0.10.74: MOVE 事件节流窗口。
     *
     * 滑动时每秒可能产生上百个 ACTION_MOVE，每个都走 nativeSendInput → 引擎大锁，
     * 与视频 RTP 解析抢同一把 `with_engine` 锁 —— 手指越密集，视频帧被挤得越靠后，
     * 表现就是"滑动时画面掉帧、字发糊、松手才追上"。按 16ms（约 60Hz）合并后，
     * 位置不丢（最后一个点一定发），但不会把锁占满。
     */
    private var lastMoveAt = 0L
    private val moveThrottleMs = 16L

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val session = sessionRef.get() ?: return super.onTouchEvent(event)
        // v0.10.53: 改用 rawX/rawY 减去渲染层在屏幕上的真实位置再归一化。
        // 1111(31) 实测触摸落点与画面图标错位（日志 x 全落在 245~678、y 全落在
        // 342~445，用户点的却是画面中部的列表项），说明窗口被系统加装饰之后，
        // event.x / renderSurface.width 不再等价于"画面内的相对位置"。
        val loc = IntArray(2)
        renderSurface.getLocationOnScreen(loc)
        val w = renderSurface.width.coerceAtLeast(1).toFloat()
        val h = renderSurface.height.coerceAtLeast(1).toFloat()
        // v0.10.64: applyVideoAspect 是 fitCenter，画面比 View 窄/矮时四周有黑边。
        // 黑边不是画面内容，点上去必须映射到画面边缘而不是被 coerce 到 0/1 的角落，
        // 所以先按视频比例算出内容矩形，再把原始坐标投影到内容区归一化。
        val fw = lastVideoW
        val fh = lastVideoH
        var contentW = w
        var contentH = h
        var offX = 0f
        var offY = 0f
        if (navInsetPx > 0) {
            // v0.10.86: 与 applyVideoAspect 的避让分支保持一致——画面横向铺满整宽、
            // 纵向只占 (h - inset)。触摸的归一化区间必须是这块实际内容区，
            // 否则纵向会整体偏移（点上面的图标落到下面一行）。
            contentW = w
            contentH = (h - navInsetPx).coerceAtLeast(1f)
            offX = 0f
            offY = 0f
        } else if (fw > 0 && fh > 0) {
            val scale = minOf(w / fw, h / fh)
            contentW = fw * scale
            contentH = fh * scale
            offX = (w - contentW) / 2
            offY = (h - contentH) / 2
        }
        val cx = (((event.rawX - loc[0]) - offX) / contentW).coerceIn(0f, 1f)
        val cy = (((event.rawY - loc[1]) - offY) / contentH).coerceIn(0f, 1f)
        if (!touchGeomLogged) {
            touchGeomLogged = true
            appendMediaLog("触摸几何 view=${w.toInt()}x${h.toInt()} loc=(${loc[0]},${loc[1]}) " +
                "screen=${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels}")
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching.set(true)
                lastMoveAt = 0L
                session.sendTouch(cx, cy, 0)
            }
            MotionEvent.ACTION_MOVE -> {
                if (touching.get()) {
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastMoveAt >= moveThrottleMs) {
                        lastMoveAt = now
                        session.sendTouch(cx, cy, 2)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching.set(false)
                session.sendTouch(cx, cy, 1)
            }
        }
        return true
    }

    /** 方向键/音量键映射为 HiCar 按键（code 见 HelloCarBridge INPUT_KEY）。 */
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent): Boolean {
        // v0.10.23: 连接不通（无媒体）时返回键直接退出投屏页回主界面——1111(13) 实测
        // 用户被困在 RTSP 失败刷屏页，按返回键被映射为控制手机返回（sendKey(1)）无法退出。
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            val frames = renderer?.decodedFrames() ?: 0L
            val pcm = audioPlayer?.pcmBytes() ?: 0L
            if (frames == 0L && pcm == 0L) {
                appendMediaLog("无媒体连接，返回键退出投屏页（回主界面查看完整日志）")
                finish()
                return true
            }
        }
        // v0.10.82: 车机主页键 = 回车机原生桌面。
        // 原来把它映射成 sendKey(0) 发给手机（HiCar 的 Home），结果车机本地不动、
        // 手机回了 HiCar 主页 —— 用户点"主页"看到的是 HiCar 界面，不是车机桌面。
        // v0.10.83 自检修复：这段必须放在 session == null 判断之前。
        // 旧位置在会话建立之后，于是"投屏页已打开但会话还没起来 / 已 stop"时按主页键
        // 会直接落到 super.onKeyDown，goHome 永远不执行 —— 用户看到的还是"回桌面没反应"。
        if (keyCode == android.view.KeyEvent.KEYCODE_HOME) {
            goHome()
            return true
        }
        val session = sessionRef.get()
        if (session == null) return super.onKeyDown(keyCode, event)
        // v0.10.80: 长按返回键退出投屏页、回车机主界面。
        // 现行逻辑里有画面时 BACK 一律映射成 sendKey(1) 发给手机（只让手机返回上一级），
        // 本地根本不退出——用户按车机返回键想回到车机桌面，结果一直在 HiCar 里打转。
        // startTracking 让系统在按住后继续投递事件，onKeyLongPress 里才真正 finish。
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            // 长按期间系统会持续投递 repeat 事件，这里拦掉重复的 BACK，
            // 否则按住不放会给手机连发十几次"返回上一级"。
            if (event.repeatCount > 0) return true
            event.startTracking()
        }
        val code = when (keyCode) {
            android.view.KeyEvent.KEYCODE_DPAD_UP -> 5
            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> 6
            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> 3
            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> 4
            android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER -> 2
            android.view.KeyEvent.KEYCODE_BACK -> 1
            // KEYCODE_HOME 已在上面单独处理（回车机原生桌面），不再映射到 HiCar Home。
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> 7
            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> 8
            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> 9
            else -> return super.onKeyDown(keyCode, event)
        }
        session.sendKey(code)
        return true
    }

    /** v0.10.80: 按住返回键约 500ms 视为"退出投屏"，其余按键不受影响。 */
    override fun onKeyLongPress(keyCode: Int, event: android.view.KeyEvent): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            goHome()
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    /**
     * v0.10.82: 真正回到**车机原生桌面**。
     *
     * 之前退出投屏用的是 finish()，它只结束投屏页，任务栈底还压着 MainActivity —
     * 用户点"退出"看到的是 HelloCar 主界面，而不是车机桌面，反馈就是"回桌面失效"。
     * 这里显式发一个 CATEGORY_HOME 的 Intent 把 Launcher 拉到前台，再 finish 自己，
     * 中间不会闪一下主界面。MainActivity 的日志是落盘的，重新点图标进来仍能看到。
     */
    private fun goHome() {
        appendMediaLog("退出投屏：回车机原生桌面")
        runCatching {
            startActivity(android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                addCategory(android.content.Intent.CATEGORY_HOME)
                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }
        // v0.10.85 自检修复：原来这里调 finish()，它只弹掉投屏页，任务栈底还压着
        // MainActivity —— 用户点"退出"看到的是 HelloCar 主界面，所以判定"回桌面失效"。
        // 1111(50) 第一张实拍更直接：车机桌面已经显示出来了，左下角却仍挂着我们的日志浮层，
        // 说明只 finish 掉一层不够。finishAffinity 把整个 App 任务栈一起关掉，落点才是 Launcher。
        finishAffinity()
    }

    // ---------------------------------------------------------------- audio focus --

    private val audioManager by lazy { getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }

    private val audioFocusListener = android.media.AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            android.media.AudioManager.AUDIOFOCUS_LOSS -> {
                // v0.10.80: 车机切到 360 全景/原车媒体时焦点被夺走，这里主动让路，
                // 不去和系统抢；等 GAIN 回来再继续写，避免被判成"抢占音频"而被长期压制。
                audioPlayer?.onFocusLost()
                appendMediaLog("音频焦点丢失（被其它应用接管）")
            }
            android.media.AudioManager.AUDIOFOCUS_GAIN -> {
                audioPlayer?.onFocusGained()
                appendMediaLog("音频焦点恢复")
            }
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                audioPlayer?.onFocusLost()
            }
            android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // 导航播报类场景，忽略：duck 由系统做增益，我们继续原音量写入。
            }
        }
    }

    private fun requestAudioFocus() {
        runCatching {
            audioManager.requestAudioFocus(
                audioFocusListener,
                android.media.AudioManager.STREAM_MUSIC,
                android.media.AudioManager.AUDIOFOCUS_GAIN,
            )
        }
    }

    private fun abandonAudioFocus() {
        runCatching { audioManager.abandonAudioFocus(audioFocusListener) }
    }

    // ------------------------------------------------------------------ overlay --

    // v0.10.59: 日志不再在热路径同步写盘。
    // 「滑动卡顿 / 导航反应慢」的根因之一就在这里：AudioPlayer 每收一包就调
    // appendMediaLog（"feed ADTS" 约 25 次/秒），每一次 File.appendText 都是
    // open→write→close 的真实文件 IO，而且跑在音频接收线程上，直接把收包节奏
    // 拖慢；overlay 文本也是每包重建一次（字符串拼接 + setText）。
    // 改成热路径只入内存队列，后台线程每 800ms 批量落一次盘，overlay 限速 300ms。
    private val logQueue = java.util.concurrent.ConcurrentLinkedQueue<String>()
    private val overlayGate = java.util.concurrent.atomic.AtomicLong(0)
    @Volatile private var logFlusherStarted = false
    @Volatile private var logRunning = true

    private fun appendMediaLog(line: String) {
        logQueue.offer(line)
        val now = System.currentTimeMillis()
        if (now - overlayGate.get() >= HellocarConfig.OVERLAY_REFRESH_INTERVAL_MS) {
            overlayGate.set(now)
            uiHandler.post {
                lastLogs.addLast(line)
                while (lastLogs.size > 8) lastLogs.removeFirst()
                refreshOverlay()
            }
        }
        startLogFlusher()
    }

    private fun startLogFlusher() {
        if (logFlusherStarted) return
        synchronized(this) {
            if (logFlusherStarted) return
            logFlusherStarted = true
        }
        Thread({
            val f = File(filesDir, "hellocar_media.log")
            val sb = StringBuilder()
            var rounds = 0
            while (logRunning) {
                try { Thread.sleep(800) } catch (_: InterruptedException) { break }
                var n = 0
                while (n < 300) {
                    val s = logQueue.poll() ?: break
                    sb.append(s).append('\n')
                    n++
                }
                if (sb.isNotEmpty()) {
                    try { f.appendText(sb.toString(), Charsets.UTF_8) } catch (_: Exception) {}
                    sb.setLength(0)
                }
                // v0.10.66: 不再清空文件后，长会话会把日志涨到几十 MB —— 每 60 轮
                // （约 48 秒）检查一次，超 1MB 就只保留最后 2000 行，保证主界面读尾部不卡。
                rounds++
                if (rounds % 60 == 0) trimLogFile(f)
            }
        }, "media-log-flusher").start()
    }

    private fun trimLogFile(f: File) {
        try {
            if (!f.exists() || f.length() < 1_000_000L) return
            val tail = f.readLines().takeLast(2000)
            f.writeText(tail.joinToString("\n") + "\n")
        } catch (_: Exception) {}
    }

    private fun refreshOverlay() {
        val frames = renderer?.decodedFrames() ?: 0L
        val pcm = audioPlayer?.pcmBytes() ?: 0L
        overlay.text = buildString {
            append(lastMediaState)
            append("\nH.264 解码帧：$frames｜音频 PCM：${pcm / 1024}KB")
            if (lastLogs.isNotEmpty()) {
                append("\n")
                append(lastLogs.joinToString("\n"))
            }
            append("\n（触摸屏幕控制手机）")
        }
    }
}
