package com.hellocar.car

import android.app.Activity
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView

/**
 * v0.10.64: 独立设置页。
 *
 * 主界面只留「PIN / 启动 / 停止 / 连接状态 / 日志」，所有可调参数搬到这里。
 * 这样后续加功能（语音、方控、触控板、自适应码率……）只往这一页塞，
 * 主界面不会越堆越乱，也不影响车机上每天真正要按的那两个按钮。
 *
 * 参数读写统一走 HellocarConfig 里的两个数据类：
 *  - VideoProfile（画面：分辨率/码率/帧率，同时写 Rust 协商参数与 MediaGlobals）
 *  - ConnConfig（连接：model/MAC/CCMP/加密/业务信道）
 * 页面本身不持有任何业务逻辑，只做控件绑定。
 */
class SettingsActivity : Activity() {

    private lateinit var res480: TextView
    private lateinit var res600: TextView
    private lateinit var res720: TextView
    private lateinit var res1080: TextView
    private lateinit var bitrateSeek: SeekBar
    private lateinit var bitrateValue: TextView
    private lateinit var fpsSeek: SeekBar
    private lateinit var fpsValue: TextView
    private lateinit var modelInput: EditText
    private lateinit var macInput: EditText
    private lateinit var ccmpInput: EditText
    private lateinit var encInput: EditText
    private lateinit var businessChannelInput: EditText
    private lateinit var navInsetSeek: SeekBar
    private lateinit var navInsetValue: TextView

    private var videoW = HellocarConfig.DEFAULT_VIDEO_W
    private var videoH = HellocarConfig.DEFAULT_VIDEO_H

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.activity_settings)

        res480 = findViewById(R.id.res480)
        res600 = findViewById(R.id.res600)
        res720 = findViewById(R.id.res720)
        res1080 = findViewById(R.id.res1080)
        bitrateSeek = findViewById(R.id.bitrateSeek)
        bitrateValue = findViewById(R.id.bitrateValue)
        fpsSeek = findViewById(R.id.fpsSeek)
        fpsValue = findViewById(R.id.fpsValue)
        modelInput = findViewById(R.id.modelInput)
        macInput = findViewById(R.id.macInput)
        ccmpInput = findViewById(R.id.ccmpInput)
        encInput = findViewById(R.id.encInput)
        businessChannelInput = findViewById(R.id.businessChannelInput)
        navInsetSeek = findViewById(R.id.navInsetSeek)
        navInsetValue = findViewById(R.id.navInsetValue)
        findViewById<TextView>(R.id.settingsVersion).text = HellocarConfig.VERSION

        loadAll()

        res480.setOnClickListener { pick(800, 480) }
        res600.setOnClickListener { pick(1024, 600) }
        res720.setOnClickListener { pick(1280, 720) }
        res1080.setOnClickListener { pick(1920, 1080) }

        bitrateSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                bitrateValue.text = String.format("%.1f Mbps", 2.0 + progress * 0.1)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        fpsSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                fpsValue.text = "${15 + progress} fps"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        // v0.10.85: 车机常驻导航栏避让高度。
        navInsetSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                navInsetValue.text = "$progress dp"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnSaveSettings).setOnClickListener {
            saveAll()
            finish()
        }
    }

    // --------------------------------------------------------------- 读写 --

    private fun loadAll() {
        val vp = HellocarConfig.VideoProfile.load(this)
        videoW = vp.w
        videoH = vp.h
        pick(videoW, videoH)

        // v0.10.79: SeekBar 上限与 HellocarConfig.MAX_BITRATE 必须一致。
        // 1111(48) 之前这里是 130（2.0–15.0M），而常量已抬到 20M：
        // 载入 20M 时 progress 被夹到 130 显示成 15M，保存时又写回 15M，
        // 用户设定的码率会被静默降下来。倍率固定 0.1 Mbps/格，上限按常量算。
        val maxStep = ((HellocarConfig.MAX_BITRATE / 1_000_000.0 - 2.0) * 10).toInt()
        bitrateSeek.progress = (((vp.mbps - 2.0) * 10).toInt()).coerceIn(0, maxStep)
        bitrateValue.text = String.format("%.1f Mbps", 2.0 + bitrateSeek.progress * 0.1)
        fpsSeek.progress = (vp.fps - 15).coerceIn(0, 15)
        fpsValue.text = "${15 + fpsSeek.progress} fps"
        // v0.10.85: 导航栏避让
        navInsetSeek.progress = HellocarConfig.Display.navInsetDp(this)
        navInsetValue.text = "${navInsetSeek.progress} dp"

        val cc = HellocarConfig.ConnConfig.load(this)
        modelInput.setText(cc.model)
        macInput.setText(cc.btMac)
        ccmpInput.setText(cc.ccmpVersion.toString())
        encInput.setText(cc.encPref.toString())
        businessChannelInput.setText(cc.businessChannel.toString())
    }

    private fun saveAll() {
        val mbps = 2.0 + bitrateSeek.progress * 0.1
        val vp = HellocarConfig.VideoProfile(
            w = videoW,
            h = videoH,
            bitrate = (mbps * 1_000_000).toInt(),
            fps = 15 + fpsSeek.progress,
        )
        HellocarConfig.VideoProfile.save(this, vp)
        // v0.10.85: 导航栏避让高度单独存（属于布局，不属于视频协商参数）
        HellocarConfig.Display.saveNavInset(this, navInsetSeek.progress)
        // 立刻生效：写进 Rust 协商参数与渲染层尺寸，下次连接即用新值。
        vp.applyToGlobals()
        vp.apply()

        val cc = HellocarConfig.ConnConfig(
            model = modelInput.text.toString().trim().ifBlank { HellocarConfig.DEFAULT_MODEL },
            btMac = macInput.text.toString().trim().uppercase()
                .ifBlank { HellocarConfig.DEFAULT_BT_MAC },
            ccmpVersion = ccmpInput.text.toString().trim().toIntOrNull() ?: HellocarConfig.DEFAULT_CCMP,
            encPref = encInput.text.toString().trim().toIntOrNull() ?: HellocarConfig.DEFAULT_ENC_PREF,
            businessChannel = businessChannelInput.text.toString().trim().toIntOrNull()
                ?: HellocarConfig.DEFAULT_BUSINESS_CHANNEL,
        )
        HellocarConfig.ConnConfig.save(this, cc)
    }

    private fun pick(w: Int, h: Int) {
        videoW = w
        videoH = h
        style(res480, w == 800 && h == 480)
        style(res600, w == 1024 && h == 600)
        style(res720, w == 1280 && h == 720)
        style(res1080, w == 1920 && h == 1080)
    }

    private fun style(tv: TextView, on: Boolean) {
        tv.setBackgroundResource(if (on) R.drawable.seg_on else R.drawable.seg_off)
        tv.setTextColor(if (on) 0xFFFFFFFF.toInt() else 0xFF8B919E.toInt())
    }
}
