package com.hellocar.car

/**
 * JNI 桥接：加载两个 .so 并暴露协议核的 native 方法（M1 自检 + M2b 会话引擎 + M2c 媒体链路）。
 *
 * JNI 符号与 libhellocar_android.so 导出符号一一对应（llvm-readelf 实测）：
 *   Java_com_example_hellocar_HelloCarBridge_nativeInit / nativeStart / nativeStop / nativeStatus
 *   + M2b: nativeOpenChannel / nativeInitial / nativeFeed / nativeHeartbeat /
 *          nativeCloseChannel / nativeSetHotspotInfo / nativeSendInput
 *   + M2c: nativeSetAudioPort / nativeSetFrameCallback / nativeSetAudioCallback
 *
 * 加载顺序（编译报告 §5 策略）：先 hellocar_hichain（C 认证库），后 hellocar（Rust 协议核）。
 */
class HelloCarBridge private constructor() {

    companion object {
        init {
            System.loadLibrary("hellocar_hichain")
            // 预加载打包进 APK 的 OpenSSL（third_party/openssl/arm64-v8a/libcrypto_3.so），
            // 确保协议核 dlopen("libcrypto_3.so") 在应用命名空间内必然命中，
            // 不依赖车机系统的 libcrypto（v0.5.0 修复 -5 引擎/加密初始化失败）。
            System.loadLibrary("crypto_3")
            // 注意：Rust 协议核产物文件名为 libhellocar_android.so（见编译报告 §1），
            // loadLibrary 必须用 "hellocar_android"，否则 UnsatisfiedLinkError。
            System.loadLibrary("hellocar_android")
        }

        /** 通道类型（与 android_engine.rs ChannelKind 对应）。 */
        const val CH_NEARBY_RFCOMM = 0      // RFCOMM FE35
        const val CH_NEARBY_TCP = 1         // TCP 4005
        const val CH_BUSINESS = 2           // RFCOMM FE36
        const val CH_DATA = 3               // TCP 4006
        const val CH_CONTROL = 4            // TCP 4007 (DMSDP)
        const val CH_MEDIA_VIDEO = 5        // HiSight media TCP（4B BE len + RTP → H.264 AU）
        const val CH_MEDIA_AUDIO = 6        // HiSight audio UDP（0xAB + len + IV + AES-CTR(RTP)）
        const val CH_SIGHT = 7              // HiSight RTSP TCP（media/input endpoint 发现）

        /** 输入事件类型（nativeSendInput kind）。 */
        const val INPUT_TOUCH = 0
        const val INPUT_KEY = 1
        const val INPUT_KEYFRAME = 2

        /**
         * 初始化协议核（内部执行回环自检 + 加载身份 + 构建会话引擎）。
         *
         * @param authLibrary 认证库 soname（HiChain 适配器 dlopen 用）
         * @param storePath   HUKS/身份文件落盘目录（App 私有目录，须已含 identity.json）
         * @param model       车型 ID（8 位 hex，广播/身份种子）
         * @param address     蓝牙地址（身份种子/凭证 BSSID 占位）
         * @return 0 成功；-1 参数错误；-2 自检失败；-3 状态锁错误；-4 身份缺失/非法；-5 引擎/加密初始化失败
         */
        @JvmStatic
        external fun nativeInit(authLibrary: String, storePath: String, model: String, address: String): Int

        /** 启动协议核。返回 0 成功 / -1 未初始化。 */
        @JvmStatic
        external fun nativeStart(): Int

        /** 停止协议核（幂等，销毁会话引擎）。返回 0。 */
        @JvmStatic
        external fun nativeStop(): Int

        /** 返回 JSON 状态快照（含 engine 子对象：phase/authenticated/negotiated/rtsp_port/media_port/input_port/stats…）。 */
        @JvmStatic
        external fun nativeStatus(): String

        /** 打开一个协议通道（见 CH_*）。返回 channelId（>=0）或负错误码。 */
        @JvmStatic
        external fun nativeOpenChannel(kind: Int): Int

        /** 取通道初始帧字节（消费一次；无则空数组）。 */
        @JvmStatic
        external fun nativeInitial(channelId: Int): ByteArray

        /** 向通道喂入平台层字节流，返回协议回复字节（可能为空）。 */
        @JvmStatic
        external fun nativeFeed(channelId: Int, data: ByteArray): ByteArray

        /** DMSDP 心跳（协商后每 ~1s 调用一次）。 */
        @JvmStatic
        external fun nativeHeartbeat(channelId: Int): ByteArray

        /** 关闭通道。返回 0。 */
        @JvmStatic
        external fun nativeCloseChannel(channelId: Int): Int

        /**
         * 设置 Nearby 协商响应参数（v0.10.3：实车对照用）。
         *
         * @param ccmpVersion tag2 回值（CCMP 版本；手机实测请求 4，0 表示保持默认 2）
         * @param encPref     tag6 回值（加密偏好 0..=2；手机实测请求 2，默认 0）
         * 必须在 RfcommServer 打开 FE35 通道之前调用（nativeStart 之后立即调用）。
         * @return 0 成功；-1 未初始化 / -3 状态锁错误
         */
        @JvmStatic
        external fun nativeSetNegotiateParams(ccmpVersion: Int, encPref: Int): Int

        /**
         * 设置 FE36 业务端点 RFCOMM 信道号（v0.10.5：kind2 响应 uint(channel)）。
         *
         * Android 用 listenUsingRfcommWithServiceRecord 注册 FE36 时信道由系统分配，
         * 须先反射读取真实信道号再注入；0 表示保持默认 24。
         * 必须在 RfcommServer 打开 FE35 通道之前调用。
         * @return 0 成功；-1 未初始化 / -3 状态锁错误
         */
        @JvmStatic
        external fun nativeSetBusinessChannel(channel: Int): Int

        /**
         * v0.10.61：实时设置 HiSight 协商画面参数（分辨率/码率/帧率/GOP）。
         * 这些值原来编译期写死在 Rust 能力表里，改一次就要重编 .so 再让用户重装；
         * 参数化后主界面设置面板才调得动。下一次 GET_PARAMETER 用新值，触摸坐标
         * 换算与边界校验读同一组全局量，不会错位。返回 0。
         */
        @JvmStatic
        external fun nativeSetVideoParams(
            w: Int, h: Int, bitrate: Int, vbrMin: Int, vbrMax: Int, fps: Int, gop: Int
        ): Int

        /** 回填热点真实参数（SSID/密码/BSSID/本机IP/手机IP/端口/频点）。返回 0 成功。 */
        @JvmStatic
        external fun nativeSetHotspotInfo(
            ssid: String, password: String, bssid: String,
            ownerIp: String, clientIp: String, port: Int, frequency: Int,
        ): Int

        /**
         * 打包输入事件为 HiSight remotectl 线上字节（Kotlin 写入输入 TCP socket）：
         *   kind=INPUT_TOUCH：payload = [x f32BE][y f32BE][action u8]，x/y 归一化 [0,1]，
         *                      action 0=按下/1=抬起/2=移动（相对 800×480 协商显示）；
         *   kind=INPUT_KEY：payload = [code u8]（0 home/1 back/2 enter/3 left/4 right/
         *                      5 up/6 down/7 play_pause/8 next/9 previous）→ 返回 down+up 两包；
         *   kind=INPUT_KEYFRAME：payload 忽略 → 引擎置 wait_key，返回空数组。
         * @return 待写入输入 TCP 的字节（可能为空）；失败返回空数组（日志见 nativeStatus）。
         */
        @JvmStatic
        external fun nativeSendInput(kind: Int, payload: ByteArray): ByteArray

        /** 注入 Kotlin 绑定的本地音频 UDP 端口（打开 4007 控制通道后、speaker 协商前调用）。返回 0 成功。 */
        @JvmStatic
        external fun nativeSetAudioPort(port: Int): Int

        /** v0.10.35: 重发 HiSight PLAY（PLAY 后视频 0 帧兜底）。返回待写回 sight RTSP socket 的记录。 */
        @JvmStatic
        external fun nativeRequestPlay(channelId: Int): ByteArray

        /** 注册 H.264 帧回调（object : FrameSink 或 null 清除）。回调在 feed 调用线程执行。返回 0 成功。 */
        @JvmStatic
        external fun nativeSetFrameCallback(cb: Any?): Int

        /** 注册 AAC-ADTS 帧回调（object : AudioSink 或 null 清除）。回调在 feed 调用线程执行。返回 0 成功。 */
        @JvmStatic
        external fun nativeSetAudioCallback(cb: Any?): Int
    }

    /** H.264 帧接收回调（JNI 侧调用 onFrame(ZJ[B)V）。 */
    interface FrameSink {
        fun onFrame(key: Boolean, pts: Long, data: ByteArray)
    }

    /** AAC-ADTS 帧接收回调（JNI 侧调用 onAudio(J[B)V）。 */
    interface AudioSink {
        fun onAudio(pts: Long, data: ByteArray)
    }
}
