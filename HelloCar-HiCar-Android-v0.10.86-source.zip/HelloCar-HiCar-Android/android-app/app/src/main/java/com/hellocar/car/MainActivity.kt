package com.hellocar.car

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * M2b 主界面：连接链路编排 + 状态日志视图。
 *
 * 链路：权限 → 身份 → nativeInit/Start → BLE 广播(FDEE) → RFCOMM FE35/FE36 监听
 *       → TCP 4005/4006/4007 监听 →（轮询认证）→ 认证通过启动 LocalOnlyHotspot
 *       → 真实参数回填 → DMSDP 心跳。投屏（M2c）不做。
 *
 * 状态显示：phase 行（BLE 广播中/RFCOMM 等待/已配对/认证中/热点/会话）+ 滚动日志。
 */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var statusBadge: TextView
    private lateinit var pinText: TextView
    private lateinit var mainScroll: android.widget.ScrollView
    private lateinit var logScroll: android.widget.ScrollView
    /** v0.10.64: 参数已全部迁到设置页，主界面只读这里缓存的对象。 */
    private var conn: HellocarConfig.ConnConfig = HellocarConfig.ConnConfig()

    private val uiHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val scheduler: ScheduledExecutorService = Executors.newScheduledThreadPool(2)
    private val started = AtomicBoolean(false)
    private val hotspotRequested = AtomicBoolean(false)
    private val kotlinLog = ArrayDeque<String>()
    private var lastEngineLog: List<String> = emptyList()

    private var bleAdvertiser: BleAdvertiser? = null
    private var rfcommServer: RfcommServer? = null
    // v0.10.5：FE36 真实 RFCOMM 信道（RfcommServer 反射读取 mChannel 后回调），优先于 UI 输入
    private var fe36Channel: Int? = null
    private var tcpServer: TcpServer? = null
    private var hotspotManager: HotspotManager? = null

    private val btAddress = AtomicReference("02:00:00:00:00:00")
    private val modelId = AtomicReference("00040A00")
    private var pin = ""
    private val renderLaunched = AtomicBoolean(false)
    /** v0.10.31 自检修复（A3）: 上一次轮询的认证状态，用于检测 true→false→true 翻转。 */
    private var wasAuthenticated = false

    /** v0.10.1：BR/EDR 配对状态广播接收器（诊断手机-车机配对是否完成）。 */
    private val bondReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != BluetoothDevice.ACTION_BOND_STATE_CHANGED) return
            val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            val prev = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, -1)
            val now = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
            val name = device?.name ?: "?"
            val addr = device?.address ?: "?"
            appendLog("蓝牙配对状态变化：$name($addr) $prev→$now（10=无 11=配对中 12=已配对 13=解除中）")
            if (now == BluetoothDevice.BOND_BONDED) {
                setPhase("已与手机配对，等待重新发起连接…", 0xFF2E7D32.toInt())
            }
        }
    }

    companion object {
        private const val TAG = "HelloCar"
        // 不再运行时申请（车机 ROM 权限弹窗兼容性差，曾导致死机）。
        // targetSdk=28 后：Android 12+ 自动授予 BLUETOOTH_*/NEARBY_WIFI_DEVICES；
        // Android 10/11 走 BLUETOOTH/BLUETOOTH_ADMIN 安装即授予。
        // 以下权限仅用于状态检测（缺失→降级运行），不触发系统弹窗。
        private val CHECK_PERMISSIONS = buildList {
            add(Manifest.permission.BLUETOOTH_SCAN)
            add(Manifest.permission.BLUETOOTH_CONNECT)
            add(Manifest.permission.BLUETOOTH_ADVERTISE)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
        // v0.10.8：认证成功后启动 LocalOnlyHotspot 需要位置权限（targetSdk=28 下
        // ACCESS_FINE_LOCATION 仍是危险权限；不动态申请则热点起不来——v0.10.7 实测
        // "UID does not have Coarse/Fine Location permission"）。历史死机源于申请蓝牙
        // 权限弹窗（Android 12+ ROM 兼容 bug），本版只申请 location 组，且在用户点
        // "启动"后触发，避开蓝牙权限弹窗。
        private const val REQ_HOTSPOT_PERMISSIONS = 0x51
        private val HOTSPOT_PERMISSIONS = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        logText = findViewById(R.id.logText)
        statusBadge = findViewById(R.id.statusBadge)
        pinText = findViewById(R.id.pinText)
        mainScroll = findViewById(R.id.mainScroll)
        logScroll = findViewById(R.id.logScroll)

        // v0.10.64: 主界面不再有画面/连接参数控件，统一从设置页读取并把值推给引擎。
        loadConfigs()
        pinText.text = pin.ifBlank { "——" }

        findViewById<Button>(R.id.btnStart).setOnClickListener { startChain() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stopChain() }
        findViewById<Button>(R.id.btnCheck).setOnClickListener { selfCheck() }
        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }

        statusText.text = "状态：未启动（点「启动」开始；参数在「设置」里调）"
        appendLog("App 启动。目标：华为/荣耀手机发现 HelloCar → 配对 → 认证 → 热点 → DMSDP 会话")
        // v0.10.16: Java 层未捕获异常落盘（filesDir/crash_java.txt），与 Rust panic
        // hook（filesDir/hellocar/hellocar_panic.txt）互补，崩溃后可读现场。
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = java.io.StringWriter()
                throwable.printStackTrace(java.io.PrintWriter(sw))
                File(filesDir, "crash_java.txt").writeText(
                    "[${System.currentTimeMillis()}] thread=${thread.name}\n${throwable}\n$sw",
                    Charsets.UTF_8)
            } catch (_: Exception) {}
            android.util.Log.e("HelloCar", "uncaught crash", throwable)
        }
        try {
            registerReceiver(bondReceiver, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED))
        } catch (e: Exception) {
            appendLog("配对状态监听注册失败：${e.message}")
        }
    }

    // ------------------------------------------------------------------ UI --

    /** v0.10.16 日志落盘锁：appendLog 与 engine 日志增量都经此追加文件。 */
    private val logLock = Any()
    private var engineLogWritten = 0

    // ------------------------------------------------------- 画面参数设置面板 --
    // v0.10.61：这些值原来编译期写死在 Rust 的 GET_PARAMETER 能力表字符串里，
    // 改一次分辨率就得重编 .so、重打包、让用户重装一轮，车机上根本没法调。
    // 现在走 nativeSetVideoParams 写进 Rust 进程级原子量：能力表现场拼、
    // 触摸坐标换算和边界校验读同一组值，面板改完下一次协商立即生效。

    /** v0.10.64: 读设置页参数，并把画面参数推给引擎（下次连接生效）。 */
    private fun loadConfigs() {
        conn = HellocarConfig.ConnConfig.load(this)
        val vp = HellocarConfig.VideoProfile.load(this)
        // 先给渲染层定尺寸，再写 Rust 协商参数，避免"协商已是新尺寸、渲染还按旧尺寸"的中间态。
        vp.applyToGlobals()
        val rc = vp.apply()
        // onResume 每次都会走这里（从设置页/投屏页返回），参数没变就不重复刷日志。
        val summary = "${vp.describe()} rc=$rc；model=${conn.model}"
        if (summary != lastConfigSummary) {
            lastConfigSummary = summary
            appendLog("配置载入：$summary")
        }
    }

    /** 上一次已落盘的配置摘要，用于压制重复日志。 */
    private var lastConfigSummary: String? = null

    /** PIN 变化时刷新主界面那张卡。 */
    private fun refreshPin() {
        if (!::pinText.isInitialized) return
        runOnUiThread { pinText.text = pin.ifBlank { "——" } }
    }

    private fun setBadge(text: String, color: Int) {
        if (!::statusBadge.isInitialized) return
        runOnUiThread {
            statusBadge.text = text
            statusBadge.setTextColor(color)
        }
    }

    private fun appendLog(line: String) {
        synchronized(logLock) {
            try {
                val f = File(filesDir, "hellocar_run.log")
                f.appendText(line + "\n", Charsets.UTF_8)
                // v0.10.66: 运行日志无上限追加，跑几天会到几十 MB。每 200 条检查一次，
                // 超 1MB 只留最后 4000 行（主界面也是读尾部，历史更早的行已无用）。
                if (++runLogWrites % 200 == 0 && f.length() > 1_000_000L) {
                    val tail = f.readLines().takeLast(4000)
                    f.writeText(tail.joinToString("\n") + "\n")
                }
            } catch (_: Exception) {}
        }
        uiHandler.post {
            kotlinLog.addLast(line)
            while (kotlinLog.size > 400) kotlinLog.removeFirst()
            // v0.10.61: 渲染节流——原来每条日志都全量拼接 280 行再 setText，
            // 投屏阶段日志被合并回主界面时（每秒几十条）会把 UI 线程持续打满。
            // 内容没变时 renderLog 已有指纹短路，这里再按 150ms 合并一次。
            val now = System.currentTimeMillis()
            if (now - lastRenderAt >= 150L) {
                lastRenderAt = now
                renderLog()
            } else if (!renderPending) {
                // 兜底：确保被节流吞掉的最后一条（比如"链路已停止"）仍会显示
                renderPending = true
                uiHandler.postDelayed({
                    renderPending = false
                    lastRenderAt = System.currentTimeMillis()
                    renderLog()
                }, 160)
            }
        }
    }

    private var lastRenderAt = 0L
    private var renderPending = false
    /** 运行日志写入条数，用于每 200 条做一次体积检查。 */
    private var runLogWrites = 0

    /** 上次渲染的日志指纹；相同则跳过 setText（车机渲染慢，避免每 500ms 全量重绘导致闪屏）。 */
    private var lastLogFingerprint: String? = null

    /** 投屏阶段日志（hellocar_media.log）尾部缓存：按文件长度+修改时间判失效，避免每次重绘都读盘。 */
    private var mediaTailCache: String = ""
    private var mediaTailStamp: Long = -1L

    /**
     * v0.10.75: 投屏日志里必须永远可见的关键行标记。
     *
     * 这些都发生在投屏开头（渲染层就绪 / 解码输出格式变更 / 画面比例校正），
     * 只取尾部会被后续几百条视频音频行淹没 —— 1111(44) 正因为如此完全看不到
     * 手机的真实推流尺寸，"糊"和"卡"都失去了判据。
     */
    private val KEY_MEDIA_MARKERS = listOf(
        "渲染层就绪", "解码输出格式变更", "画面比例校正",
        "MediaCodec 视频解码器已就绪", "AudioTrack 已就绪", "ADTS 头",
        "重建 AudioTrack", "AudioTrack 写入失败", "队列积压",
    )

    private fun mediaLogTail(maxLines: Int): String {
        val f = File(filesDir, "hellocar_media.log")
        if (!f.exists()) return ""
        val stamp = f.length() * 31 + f.lastModified()
        if (stamp == mediaTailStamp) return mediaTailCache
        mediaTailCache = runCatching {
            val all = f.readLines()
            val tail = all.takeLast(maxLines)
            // 关键行固定保留（各取最后一次出现的，最多 12 条），再接尾部
            val pinned = all
                .filter { line -> KEY_MEDIA_MARKERS.any { line.contains(it) } }
                .takeLast(12)
            if (pinned.isEmpty()) tail.joinToString("\n")
            else (pinned + "──── 最近 ${tail.size} 行 ────" + tail).joinToString("\n")
        }.getOrDefault("")
        mediaTailStamp = stamp
        return mediaTailCache
    }

    private fun renderLog() {
        // 日志区是固定 220dp 的独立滚动块，只显示最后若干行，实时跟到最新。
        // 上一版把整页撑成 wrap_content 全量显示（最多 700 行），结果是：
        // 页面被拉到几百行，新日志落在视口外面，用户看到的是第一轮旧内容，
        // 以为「再连接不记录」；同时 TextView 越来越长，车机 setText 也越拖越慢。
        // v0.10.69: 原来只取尾部 60 行——dmsdp 事件密集时会把 sight/hisight 的行整段
        // 挤出去（1111(39) 的 engine 段只剩 15 行 dmsdp，完全看不到 SETUP 到底发没发、
        // Transport 里有没有 server_port，等于把最关键的证据自己藏了）。
        // 这里把协议协商相关的行单独挑出来必留，再补最近的行。
        val protocolLines = lastEngineLog.filter { it.contains("sight") || it.contains("hisight") }.takeLast(40)
        val engineLines = (lastEngineLog.takeLast(50) + protocolLines).distinct().takeLast(90)
        val mediaTail = mediaLogTail(80)
        val sb = StringBuilder()
        sb.append((kotlinLog.takeLast(160) + engineLines).joinToString("\n"))
        if (mediaTail.isNotEmpty()) {
            sb.append("\n──── 投屏阶段日志（尾部）────\n").append(mediaTail)
        }
        val text = sb.toString()
        if (text == lastLogFingerprint) return   // 内容没变就不重绘
        lastLogFingerprint = text
        logText.text = text
        if (::logScroll.isInitialized) {
            logScroll.post { logScroll.fullScroll(android.view.View.FOCUS_DOWN) }
        }
    }

    private fun setPhase(text: String, color: Int = 0xFF9AA3B2.toInt()) {
        uiHandler.post {
            statusText.text = "状态：$text\nPIN（HiChain 连接码）：$pin"
            statusText.setTextColor(color)
        }
    }

    // ------------------------------------------------------------- identity --

    /** 生成/读取持久身份（schema1：device_id 64hex + pin 6 位 + name）。 */
    private fun ensureIdentity(): Boolean {
        return try {
            // v0.10.73: 身份持久化加固。1111(42)/(43) 两轮日志都是「已生成新身份」，
            // 而 1111_1126 是「加载已有身份」——device_id 在某次启动后丢了。phone 端
            // 记录的「这台车机」靠 device_id 识别（我们的蓝牙 MAC 恒为占位
            // 02:00:00:00:00:00，无法用来区分），一旦 device_id 变了，手机看到的就是
            // 另一台车机，必然要求先「移除设备」。车机 ROM 的 filesDir 存在被清理的情况，
            // 所以双写内部 + 外部私有目录，读取时两处都找。
            val internal = File(File(filesDir, "hellocar").apply { mkdirs() }, "identity.json")
            val external = runCatching {
                getExternalFilesDir(null)?.let { File(File(it, "hellocar").apply { mkdirs() }, "identity.json") }
            }.getOrNull()
            val existing = listOfNotNull(internal, external).firstOrNull { it.exists() && it.length() > 0 }

            if (existing == null) {
                val random = java.security.SecureRandom()
                val deviceId = (0 until 32).joinToString("") { "%02x".format(random.nextInt(256)) }
                val pinVal = (0 until 6).joinToString("") { random.nextInt(10).toString() }
                val identity = JSONObject()
                    .put("schema", 1)
                    .put("device_id", deviceId)
                    .put("pin", pinVal)
                    .put("name", "HelloCar")
                val text = identity.toString()
                internal.writeText(text)
                runCatching { external?.writeText(text) }
                pin = pinVal
                appendLog("已生成新身份：device_id=$deviceId pin=$pin")
                appendLog("身份落盘：内部=${internal.length()}B 外部=${external?.length() ?: "无"}")
            } else {
                val parsed = JSONObject(existing.readText())
                pin = parsed.optString("pin", "000000")
                val deviceId = parsed.optString("device_id", "")
                appendLog("加载已有身份：device_id=$deviceId pin=$pin")
                appendLog("身份来源=${existing.absolutePath}（${existing.length()}B，mtime=${existing.lastModified()}）")
                // 两处只剩一份时补齐缺失的那份，保证下次一定读得到
                val other = if (existing == internal) external else internal
                if (other != null && (!other.exists() || other.length() == 0L)) {
                    runCatching {
                        other.parentFile?.mkdirs()
                        other.writeText(existing.readText())
                    }
                    appendLog("身份已补齐到 ${other.absolutePath}")
                }
            }
            // v0.10.64: PIN 变了就刷新主界面那张卡（原来只在状态行里混着显示）
            refreshPin()
            true
        } catch (e: Exception) {
            appendLog("身份生成/读取失败：${e.message}")
            false
        }
    }

    // ------------------------------------------------------------- permissions --

    /** 权限检测：缺失的权限仅记录日志并降级运行，绝不触发系统权限弹窗（车机 ROM 兼容）。 */
    private fun checkPermissions(): List<String> {
        val missing = CHECK_PERMISSIONS.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }.toMutableList()
        // v0.10.55: targetSdk=28 的应用永远不会被授予 BLUETOOTH_CONNECT/SCAN/ADVERTISE
        // （它们是 API 31+ 的运行时权限，系统按 targetSdk 判定，低版本只认 legacy）。
        // 实际蓝牙链路走的是 legacy BLUETOOTH/BLUETOOTH_ADMIN（normal 级、安装即授予）。
        // 旧实现把这三个新权限算进 missing，1111(33) 日志就出现了假告警，把排查
        // 方向带偏到"权限没给"——其实真正的问题是 legacy 权限被 maxSdkVersion 挡掉了
        // （已在 Manifest 修复）。这里按 legacy 授予情况剔除假缺失。
        val legacyBt = checkSelfPermission(Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED
        if (legacyBt) {
            missing.remove(Manifest.permission.BLUETOOTH_SCAN)
            missing.remove(Manifest.permission.BLUETOOTH_CONNECT)
            missing.remove(Manifest.permission.BLUETOOTH_ADVERTISE)
        }
        if (missing.isNotEmpty()) {
            appendLog("以下权限未授予（不弹窗申请，链路降级运行）：${missing}")
            setPhase("权限不足（降级运行）", 0xFFEF6C00.toInt())
        } else {
            appendLog("关键权限齐全（蓝牙/定位/邻近设备）")
        }
        return missing
    }

    /** v0.10.8：动态申请热点所需位置权限（仅 location 组，用户点"启动"后触发）。 */
    private fun requestHotspotPermissions() {
        val missing = HOTSPOT_PERMISSIONS.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            appendLog("热点位置权限已具备（无需弹窗）")
            return
        }
        appendLog("动态申请热点位置权限：${missing}")
        requestPermissions(missing.toTypedArray(), REQ_HOTSPOT_PERMISSIONS)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_HOTSPOT_PERMISSIONS) return
        val denied = permissions.indices.filter { grantResults[it] != PackageManager.PERMISSION_GRANTED }
            .map { permissions[it] }
        appendLog(
            if (denied.isEmpty()) "热点位置权限已授予（可启动 LocalOnlyHotspot）"
            else "热点位置权限被拒绝：${denied}（热点将无法启动，请在系统设置手动授权）"
        )
    }

    // ----------------------------------------------------------------- chain --

    private fun startChain() {
        if (started.get()) {
            appendLog("链路已在运行")
            return
        }
        setBadge("连接中", 0xFF2E7DFF.toInt())
        // 只检测不弹窗：缺失权限降级运行（蓝牙权限通常已自动授予，targetSdk=28）
        checkPermissions()
        // v0.10.8：热点需要位置权限，仅在用户点"启动"后动态申请（只弹 location 组）
        requestHotspotPermissions()
        val model = conn.model
        val mac = conn.btMac.uppercase()
        if (model.length != 8 || !model.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
            appendLog("model 必须是 8 位十六进制（如 00040A00）")
            return
        }
        if (!mac.matches(Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}"))) {
            appendLog("蓝牙地址格式非法（AA:BB:CC:DD:EE:FF）")
            return
        }
        modelId.set(model)
        btAddress.set(mac)
        // v0.10.56: 启动前也要清一次上一轮投屏页——用户不点"停止"直接再按"启动"时，
        // started 已经是 false（上次断链时被复位），走不到 stopChain 里的清理，
        // 旧 MediaSession 会继续占着视频通道，新会话再次被判重复。
        runCatching {
            if (RenderActivity.closeIfActive()) {
                appendLog("启动前关闭上一轮投屏页（清理残留媒体会话）")
            }
        }
        started.set(true)
        // v0.10.31 自检修复（A2）: engineLogWritten 必须重置——否则第二会话 nativeInit
        // 重建引擎后 log 数组从 0 重新开始，而 engineLogWritten 保留旧值（≥新长度），
        // 增量落盘条件 logArr.length() > engineLogWritten 恒 false → 新会话引擎日志
        // 完全不再落盘（断链重连后的取证丢失）。
        engineLogWritten = 0
        hotspotRequested.set(false)

        // 身份（nativeInit 需要 identity.json 已存在）
        if (!ensureIdentity()) {
            appendLog("身份不可用，链路终止")
            started.set(false)
            return
        }

        try {
            val storePath = File(filesDir, "hellocar").absolutePath
            val initRc = HelloCarBridge.nativeInit("libhellocar_hichain.so", storePath, model, mac)
            if (initRc != 0) {
                appendLog("nativeInit 失败 rc=$initRc（-4 身份缺失 / -5 引擎或加密初始化失败）")
                setPhase("协议核初始化失败($initRc)", 0xFFC62828.toInt())
                started.set(false)
                return
            }
            // v0.10.75: 列出 HiChain 存储目录，判断配对凭据有没有真的落盘。
            // 如果这里只有 identity.json，说明 HiChain runtime 是纯内存态，
            // 那么 has_pin=false 的"已配对直连"永远不可能成功，只能换思路。
            runCatching {
                val dir = File(filesDir, "hellocar")
                val files = dir.listFiles()?.sortedBy { it.name } ?: emptyList()
                appendLog("HiChain 存储目录：${files.size} 个文件（${dir.absolutePath}）")
                files.take(12).forEach { f -> appendLog("  · ${f.name}（${f.length()}B）") }
            }
            HelloCarBridge.nativeStart()
            // v0.10.4：Nearby 协商响应参数（CCMP 版本 / 加密偏好）——须在 openChannel 前注入；
            // 默认 2/0（协议降级应答），UI 可改。
            val ccmp = conn.ccmpVersion
            val enc = conn.encPref
            val negRc = HelloCarBridge.nativeSetNegotiateParams(ccmp, enc)
            appendLog("协商参数：CCMP版本=$ccmp 加密偏好=$enc（nativeSetNegotiateParams rc=$negRc）")
            appendLog("协议核已初始化并启动（自检通过）")
            setPhase("BLE 广播中…", 0xFF1565C0.toInt())
        } catch (e: Throwable) {
            appendLog("nativeInit 异常：${e.javaClass.simpleName}: ${e.message}")
            setPhase("初始化异常", 0xFFC62828.toInt())
            started.set(false)
            return
        }

        // 1) BLE 广播（FDEE ServiceData + LocalName）
        val adapter = try {
            BluetoothAdapter.getDefaultAdapter()
        } catch (e: SecurityException) {
            appendLog("蓝牙适配器访问被拒（缺 BLUETOOTH_CONNECT 权限）：${e.message}")
            null
        }
        if (adapter == null) {
            appendLog("蓝牙不可用——BLE/RFCOMM 跳过，仅 TCP 会话服务运行")
            setPhase("蓝牙不可用", 0xFFEF6C00.toInt())
        } else {
            val bleEnabled = try { adapter.isEnabled } catch (e: SecurityException) { false }
            if (!bleEnabled) {
                appendLog("蓝牙未开启或不可用——请先开启蓝牙；RFCOMM/BLE 将跳过")
                setPhase("蓝牙未开启", 0xFFEF6C00.toInt())
            } else {
                // v0.7.0 诊断增强：打印蓝牙适配器名与地址（供判断 BR/EDR 可发现性）。
                try {
                    appendLog("蓝牙信息：name=${adapter.name} address=${adapter.address} enabled=${adapter.isEnabled}")
                } catch (e: Exception) {
                    appendLog("蓝牙信息读取失败：${e.message}")
                }
                // v0.9.0：荣耀官方指引——"在车上发起连接，在手机端确认"。
                // 手机端必须先把荣耀车联停留在"连接车辆 > 通用连接方式 > HiCar > 无线连接"页面
                // 且蓝牙+WLAN 同时开启，车机广播才会被扫描并弹窗。
                appendLog("手机端操作：先打开 荣耀车联 > 连接车辆 > 通用连接方式 > HiCar > 无线连接，停留在此页等待弹窗")
                appendLog("（蓝牙+WLAN 必须同时开启；若之前输过 PIN 失败，先在手机蓝牙设置里\"忘记\"本车机再试）")
                val ble = BleAdvertiser(adapter, model)
                bleAdvertiser = ble
                ble.start({ appendLog(it) }, { ok, info ->
                    if (ok) setPhase("BLE 广播中（FDEE）…") else appendLog("BLE 状态：$info")
                })

                // 2) RFCOMM FE35/FE36 服务端
                // v0.10.5：业务信道注入——先注入 UI/默认值兜底，start() 后反射真实信道覆盖。
                val fe36Init = conn.businessChannel
                val chInitRc = HelloCarBridge.nativeSetBusinessChannel(fe36Init)
                appendLog("业务信道(FE36) 预注入：$fe36Init（nativeSetBusinessChannel rc=$chInitRc）")
                rfcommServer = RfcommServer(
                    adapter = adapter,
                    log = { appendLog(it) },
                    openChannel = { HelloCarBridge.nativeOpenChannel(it) },
                    feedChannel = { id, data -> HelloCarBridge.nativeFeed(id, data) },
                    initialChannel = { HelloCarBridge.nativeInitial(it) },
                    closeChannel = { HelloCarBridge.nativeCloseChannel(it) },
                    onConnectionState = { connected, which ->
                        if (connected) {
                            // v0.10.48: 链路恢复 → 撤销投屏页的待执行收口
                            RenderActivity.notifyPeerBack()
                            if (which == "control") setPhase("RFCOMM FE35 已连（Nearby 协商）…")
                            if (which == "business") setPhase("认证进行中（HiChain PAKE/STS，PIN=$pin）…")
                        }
                        // v0.10.50: 撤销 v0.10.48 的「蓝牙断开 → 投屏页自动退出」。
                        // HiCar 投屏建立后手机会主动关闭 RFCOMM 数据通道（数据已切到 Wi-Fi
                        // 热点），这是正常行为而非链路故障——1111(30) 行 59-60 正是手机主动
                        // 关蓝牙，而同一时刻视频/音频还在正常推流。拿它当断开去触发退出，
                        // 等于误杀正常会话。退出判定改由媒体静默（12 秒无新帧/音频）承担。
                    },
                    onBusinessChannel = { ch ->
                        fe36Channel = ch
                        val rc = HelloCarBridge.nativeSetBusinessChannel(ch)
                        appendLog("业务信道(FE36) 反射自动更新：$ch（nativeSetBusinessChannel rc=$rc）")
                    },
                )
                rfcommServer?.start()
            }
        }

        // 3) TCP 4005/4006/4007 会话服务
        tcpServer = TcpServer(
            log = { appendLog(it) },
            isAuthenticated = { currentEngine()?.optBoolean("authenticated") == true },
            openChannel = { HelloCarBridge.nativeOpenChannel(it) },
            feedChannel = { id, data -> HelloCarBridge.nativeFeed(id, data) },
            initialChannel = { HelloCarBridge.nativeInitial(it) },
            closeChannel = { HelloCarBridge.nativeCloseChannel(it) },
            onConnectionState = { connected, which -> if (connected) appendLog("TCP $which 已连接") },
            onControlOpening = { injectAudioPort() },
        )
        tcpServer?.start()

        // 4) 热点管理器（认证通过后由轮询线程触发）
        hotspotManager = HotspotManager(
            context = this,
            log = { appendLog(it) },
            onHotspotInfo = { ssid, password, bssid, owner, client, frequency, port ->
                MediaGlobals.phoneIp = client
                // v0.10.10：bssid 为热点接口真实 MAC（HotspotManager 读取）；占位 02:00:00:00:00:00 会让手机按 BSSID 匹配不到热点
                val rc = HelloCarBridge.nativeSetHotspotInfo(ssid, password, bssid, owner, client, port, frequency)
                appendLog("热点参数回填：ssid=$ssid bssid=$bssid owner=$owner client=$client freq=${frequency}MHz port=$port rc=$rc")
                if (rc == 0) setPhase("热点已建立，等待手机连接 4005…", 0xFF2E7D32.toInt())
            },
            onState = { ok, info -> appendLog("热点状态：$info") },
        )

        // 5) 状态轮询（500ms）+ DMSDP 心跳（1s）
        scheduler.scheduleWithFixedDelay({ pollStatus() }, 500, 500, TimeUnit.MILLISECONDS)
        scheduler.scheduleWithFixedDelay({ dmsdpHeartbeat() }, 1000, 1000, TimeUnit.MILLISECONDS)
        appendLog("连接链路已启动：BLE + RFCOMM(FE35/FE36) + TCP(4005-4007) 就绪")
    }

    /**
     * M2c：在 DMSDP speaker 协商前绑定本地音频 UDP 端口并注入协议核。
     * socket 存入 MediaGlobals 供 RenderActivity 的 MediaSession 复用。
     */
    private fun injectAudioPort() {
        try {
            val socket = java.net.DatagramSocket(null)
            socket.reuseAddress = true
            socket.bind(java.net.InetSocketAddress(0)) // 系统分配端口
            MediaGlobals.audioSocket = socket
            val rc = HelloCarBridge.nativeSetAudioPort(socket.localPort)
            appendLog("音频 UDP 端口注入 ${socket.localPort} rc=$rc")
        } catch (e: Exception) {
            appendLog("音频 UDP 端口绑定失败：${e.message}（音频链路不可用）")
        }
    }

    /** 轮询协议核状态：更新 UI、检测认证通过后触发热点、同步引擎日志。 */
    private fun pollStatus() {
        if (!started.get()) return
        val engine = currentEngine() ?: return
        val logArr = engine.optJSONArray("log")
        lastEngineLog = logArr?.let { arr ->
            (0 until arr.length()).map { arr.optString(it) }
        } ?: emptyList()
        // v0.10.16: 引擎日志增量落盘（nativeStatus 返回全量数组，只追加新行）。
        if (logArr != null && logArr.length() > engineLogWritten) {
            synchronized(logLock) {
                try {
                    val sb = StringBuilder()
                    for (i in engineLogWritten until logArr.length()) {
                        sb.append(logArr.optString(i)).append('\n')
                    }
                    File(filesDir, "hellocar_run.log").appendText(sb.toString(), Charsets.UTF_8)
                    engineLogWritten = logArr.length()
                } catch (_: Exception) {}
            }
        }
        uiHandler.post { renderLog() }

        val authenticated = engine.optBoolean("authenticated")
        // v0.10.31 自检修复（A3）: 认证翻转 true->false->true 时重置 renderLaunched——
        // 手机断链后重新认证、新 rtsp_port 再次出现时，投屏页才可能被自动拉起。
        // 原实现 renderLaunched 只置一次不重置，断链重连后画面不再自动弹出。
        if (authenticated && !wasAuthenticated) {
            renderLaunched.set(false)
        }
        wasAuthenticated = authenticated
        val negotiated = engine.optBoolean("negotiated")
        val credentialsSent = engine.optBoolean("credentials_sent")
        val hotspotSet = engine.optBoolean("hotspot_set")

        if (authenticated && !hotspotRequested.get()) {
            hotspotRequested.set(true)
            uiHandler.post {
                appendLog("认证通过——启动 LocalOnlyHotspot（真实参数回填）")
                setBadge("已认证", 0xFF30C48D.toInt())
                setPhase("认证通过，热点启动中…", 0xFF2E7D32.toInt())
                hotspotManager?.start()
            }
        }
        when {
            negotiated -> setPhase("DMSDP 会话已协商（等待 HiSight 端口…）", 0xFF2E7D32.toInt())
            credentialsSent -> setPhase("热点凭证已下发，等待手机连 4006…", 0xFF2E7D32.toInt())
            hotspotSet -> setPhase("热点已回填，等待手机连 4005…", 0xFF1565C0.toInt())
            authenticated -> setPhase("认证通过（HiChain），热点启动中…", 0xFF1565C0.toInt())
        }

        // M2c：DMSDP 协商完成后 HiSight RTSP 端口出现 → 自动切入全屏渲染视图。
        val rtspPort = engine.optInt("rtsp_port", -1)
        if (rtspPort > 0 && !renderLaunched.get()) {
            renderLaunched.set(true)
            // v0.10.21: 端口写入进程内全局——RenderActivity 的 MediaSession 直接读取
            // （v0.10.20 实测 Intent extra 与轮询都拿不到，改全局最可靠）。
            MediaGlobals.rtspPort = rtspPort
            // v0.10.23: 端口一出现立即后台预连 RTSP——手机在 cmd101 下发后 1~3s 内可能
            // 切媒体模式离开热点（1111(12/13) 实测 TCP+蓝牙全断、EHOSTUNREACH），
            // 预连接抢在手机离开前建立，避免 45s 重试全部落空。
            val phoneIp = MediaGlobals.phoneIp
            // v0.10.30: 预连抽成可重试函数——1111(21) 实测 RTSP ANNOUNCE 后手机直接
            // Connection reset（未回任何字节），读循环异常即退出、投屏页复用已死的
            // RTSP 会话 → 无媒体无画面。改为 reset 后自动重连并重写 ANNOUNCE
            // （手机可能在 RST 后切好媒体模式重新开放端口），最多重试 3 次。
            rtspPreconnect(rtspPort, 1)
            appendLog("HiSight RTSP 端口 $rtspPort 就绪——启动投屏渲染（M2c）")
            uiHandler.post {
                try {
                    // v0.10.20: rtsp_port 直接随 Intent 传入投屏页——MediaSession 不再依赖
                    // 轮询 nativeStatus（1111(8) 实测：MainActivity 读到 36747，但投屏页
                    // waitForPort 30s 轮询恒 -1，导致 RTSP 连接从未发起）。
                    startActivity(
                        android.content.Intent(this, RenderActivity::class.java)
                            .putExtra("rtsp_port", rtspPort)
                    )
                } catch (e: Exception) {
                    appendLog("渲染视图启动失败：${e.message}")
                }
            }
        }
    }

    /**
     * v0.10.30: HiSight RTSP 预连 + 协商第一跳，可自动重试。
     * attempt 从 1 开始；Connection reset / EOF 后关闭旧 socket 与旧 sight 会话，
     * 延迟 1s 重连并重写 ANNOUNCE（最多 3 次）。读循环打印手机首帧 hex 取证
     * （区分「手机未回任何字节直接 RST」vs「回了 200 后 RST」）。
     */
    private fun rtspPreconnect(rtspPort: Int, attempt: Int) {
        val phoneIp = MediaGlobals.phoneIp
        Thread {
            try {
                val s = java.net.Socket()
                s.tcpNoDelay = true
                s.connect(java.net.InetSocketAddress(phoneIp, rtspPort), 2000)
                MediaGlobals.preconnectedRtsp = s
                appendLog("RTSP 预连接成功：$phoneIp:$rtspPort（第 $attempt 次）")
                val sightId = HelloCarBridge.nativeOpenChannel(HelloCarBridge.CH_SIGHT)
                if (sightId < 0) {
                    appendLog("CH_SIGHT 打开失败 rc=$sightId（第 $attempt 次，投屏页会再尝试）")
                    return@Thread
                }
                val initial = HelloCarBridge.nativeInitial(sightId)
                if (initial.isEmpty()) {
                    appendLog("CH_SIGHT 初始帧为空（第 $attempt 次）")
                    return@Thread
                }
                val out = s.getOutputStream()
                out.write(initial)
                out.flush()
                appendLog("RTSP ANNOUNCE 已发出（sight=$sightId, ${initial.size}B, 第 $attempt 次）——协商启动")
                // 手机 RTSP 响应读循环：nativeFeed 解密/解析，引擎回包写回手机。
                Thread {
                    try {
                        val input = s.getInputStream()
                        val buf = ByteArray(4096)
                        var firstFrameLogged = false
                        while (!s.isClosed) {
                            val n = input.read(buf)
                            if (n < 0) break
                            if (n == 0) continue
                            if (!firstFrameLogged) {
                                firstFrameLogged = true
                                val hex = buf.copyOfRange(0, minOf(n, 16)).joinToString("") { "%02x".format(it) }
                                appendLog("RTSP 预连读循环收到首帧 ${n}B: $hex")
                            }
                            val reply = HelloCarBridge.nativeFeed(sightId, buf.copyOf(n))
                            if (reply.isNotEmpty()) {
                                // v0.10.67: 回包取证——1111(37) 首帧 307B 之后日志里
                                // 没有任何回包痕迹，无法判断 SETUP 到底有没有发出去。
                                val head = reply.copyOfRange(0, minOf(reply.size, 16)).joinToString("") { "%02x".format(it) }
                                appendLog("RTSP 预连回包 ${reply.size}B: $head")
                                val o = s.getOutputStream()
                                o.write(reply)
                                o.flush()
                            } else {
                                // v0.10.68: 通常是只收到 4 字节长度前缀、正文还在路上
                                // （HiSight 分帧有状态，引擎会等正文到齐再回包），不是错误。
                                appendLog("RTSP 预连：${n}B 已入引擎，等正文到齐（未产出回包）")
                            }
                        }
                        appendLog("RTSP 预连读循环结束（sight=$sightId, 第 $attempt 次）")
                        // v0.10.65: 先判 isClosed —— 用户点「停止」时 stopChain 可能已经把
                        // socket 关了，此时写一定失败，原来会被静默吞掉却仍打"已发送"，
                        // 日志会骗人（多轮"TEARDOWN 跳过"就是这么来的）。
                        if (!s.isClosed) {
                            runCatching {
                                val td = "TEARDOWN rtsp://${MediaGlobals.phoneIp}/hisight1.2/streamid=0 RTSP/1.0\r\n" +
                                        "CSeq: ${System.currentTimeMillis() % 60000}\r\n" +
                                        "User-Agent: HelloCar\r\n\r\n"
                                val o = s.getOutputStream()
                                o.write(td.toByteArray(Charsets.UTF_8))
                                o.flush()
                                appendLog("已向手机发送 RTSP TEARDOWN（预连会话退役）")
                            }
                        } else {
                            appendLog("RTSP socket 已被关闭，跳过 TEARDOWN（会话由停止流程负责）")
                        }
                        // v0.10.33（A2）: EOF 正常退出同样清理全局并重连——原实现只有
                        // 异常分支清理，EOF（read 返回 -1）时 rtspStarted 残留 true 骗
                        // 投屏页复用死会话（1111(21) 残留根因）。清理带 ===s 保护：
                        // 若投屏页已接管（rtspSocket 已换成投屏页会话），不清它的状态。
                        runCatching { s.close() }
                        if (MediaGlobals.preconnectedRtsp === s) MediaGlobals.preconnectedRtsp = null
                        if (MediaGlobals.rtspSocket === s) {
                            MediaGlobals.rtspSocket = null
                            MediaGlobals.rtspStarted = false
                            if (MediaGlobals.sightId == sightId) MediaGlobals.sightId = -1
                        }
                        runCatching { HelloCarBridge.nativeCloseChannel(sightId) }
                        if (attempt < 3) {
                            val taken = MediaGlobals.rtspSocket
                            if (taken != null && !taken.isClosed) {
                                appendLog("投屏页已接管 RTSP 会话，停止预连重试")
                                return@Thread
                            }
                            try { Thread.sleep(1000) } catch (ie: InterruptedException) {}
                            appendLog("RTSP 预连自动重连（第 ${attempt + 1} 次）…")
                            rtspPreconnect(rtspPort, attempt + 1)
                        } else {
                            appendLog("RTSP 预连重试耗尽（3 次）——等待投屏页 MediaSession 兜底")
                        }
                    } catch (e: Exception) {
                        appendLog("RTSP 预连读循环异常：${e.message}（sight=$sightId, 第 $attempt 次）")
                        // v0.10.30: reset/EOF 后手机可能稍后切好媒体模式重新开放端口——
                        // 关闭旧会话自动重连重写 ANNOUNCE，避免无媒体直接退出。
                        // v0.10.31（A5）: 清理全局状态——原实现 rtspStarted 残留 true 会
                        // 骗投屏页走复用分支（sight 已 close、socket 已 null），导致
                        // waitForPort 30s 超时无画面（1111(21) 无画面的直接诱因）。
                        runCatching { s.close() }
                        if (MediaGlobals.preconnectedRtsp === s) MediaGlobals.preconnectedRtsp = null
                        // v0.10.33（A2）: 清理带 ===s 保护——若投屏页已接管（rtspSocket
                        // 已换成投屏页会话），本预连会话的异常/EOF 不清投屏页状态。
                        if (MediaGlobals.rtspSocket === s) {
                            MediaGlobals.rtspSocket = null
                            MediaGlobals.rtspStarted = false
                            if (MediaGlobals.sightId == sightId) MediaGlobals.sightId = -1
                        }
                        runCatching { HelloCarBridge.nativeCloseChannel(sightId) }
                        if (attempt < 3) {
                            // v0.10.31（A5）: 重试前检查投屏页是否已接管（投屏页自身路径
                            // 建立 RTSP 会话后也写 MediaGlobals.rtspSocket）——若已接管，
                            // 停止预连重试，避免两个线程连同一端口、双 ANNOUNCE 会话分裂。
                            val taken = MediaGlobals.rtspSocket
                            if (taken != null && !taken.isClosed && taken !== s) {
                                appendLog("投屏页已接管 RTSP 会话，停止预连重试")
                                return@Thread
                            }
                            try { Thread.sleep(1000) } catch (ie: InterruptedException) {}
                            appendLog("RTSP 预连自动重连（第 ${attempt + 1} 次）…")
                            rtspPreconnect(rtspPort, attempt + 1)
                        } else {
                            appendLog("RTSP 预连重试耗尽（3 次）——等待投屏页 MediaSession 兜底")
                        }
                    }
                }.start()
                // v0.10.31（A5）: 读循环可能已异步异常退出（RST）并清理了状态——
                // 只有 socket 仍有效才置全局接管标记，避免把已死 socket 写进全局
                // 骗投屏页走复用分支（1111(21) 残留状态根因）。
                if (!s.isClosed) {
                    // v0.10.33（A1）: 置位前检查投屏页是否已接管——投屏页自身路径可能
                    // 已 open CH_SIGHT/发 ANNOUNCE 并写 MediaGlobals.rtspSocket。若已
                    // 接管，本预连会话放弃（关 socket/close sight），避免双 ANNOUNCE
                    // 双会话分裂（1111(21) 第二次 sight channel open 竞态）。
                    val taken = MediaGlobals.rtspSocket
                    if (taken != null && !taken.isClosed && taken !== s) {
                        appendLog("投屏页已接管 RTSP 会话，预连会话放弃（sight=$sightId）")
                        runCatching { s.close() }
                        if (MediaGlobals.preconnectedRtsp === s) MediaGlobals.preconnectedRtsp = null
                        runCatching { HelloCarBridge.nativeCloseChannel(sightId) }
                        return@Thread
                    }
                    MediaGlobals.rtspStarted = true
                    MediaGlobals.sightId = sightId
                    MediaGlobals.rtspSocket = s
                } else {
                    MediaGlobals.rtspStarted = false
                }
            } catch (e: Exception) {
                appendLog("RTSP 预连接失败：${e.message}（第 $attempt 次）")
                // v0.10.31（A5）: 连接失败同样清理预连状态，避免残留 rtspStarted=true
                // 骗投屏页走复用分支。注意不能引用 try 块内局部 s（Kotlin catch 作用域
                // 看不到 try 内声明）——connect 失败时 preconnectedRtsp 未被本次赋值，
                // 直接清空即可消除旧残留。
                MediaGlobals.preconnectedRtsp = null
                MediaGlobals.rtspStarted = false
                if (attempt < 3) {
                    val taken = MediaGlobals.rtspSocket
                    if (taken != null && !taken.isClosed) {
                        appendLog("投屏页已接管 RTSP 会话，停止预连重试")
                        return@Thread
                    }
                    try { Thread.sleep(1000) } catch (ie: InterruptedException) {}
                    appendLog("RTSP 预连自动重试（第 ${attempt + 1} 次）…")
                    rtspPreconnect(rtspPort, attempt + 1)
                }
            }
        }.start()
    }

    /** DMSDP 心跳：控制通道协商后每秒一次（静默，不刷日志）。 */
    private fun dmsdpHeartbeat() {
        if (!started.get()) return
        val id = tcpServer?.currentControlChannel() ?: -1
        if (id < 0) return
        val reply = HelloCarBridge.nativeHeartbeat(id)
        if (reply.isNotEmpty()) {
            tcpServer?.sendControlBytes(reply)
        }
    }

    private fun currentEngine(): JSONObject? {
        return try {
            val root = JSONObject(HelloCarBridge.nativeStatus())
            root.optJSONObject("engine")
        } catch (e: Exception) {
            null
        }
    }

    private fun stopChain() {
        if (!started.get()) {
            appendLog("链路未在运行")
            return
        }
        started.set(false)
        setBadge("未连接", 0xFF8B919E.toInt())
        hotspotRequested.set(false)
        renderLaunched.set(false)
        // v0.10.56: 先关掉投屏页。1111(34) 的关键证据是——新一轮连接发起时，
        // 上一轮的 MediaSession 还在跑（日志里视频流已收包一路涨到 1700/1800/1900），
        // 旧会话（sight=8）没退、新会话（sight=18）又开，手机侧看到同一台车机挂着
        // 两个 hisight 会话，就把新连接的蓝牙和 TCP 全部掐掉（bt socket closed /
        // TCP 4005-4007 EOF），表现为"必须移除设备才能再连"。
        // 旧会话不清，发 TEARDOWN 也没意义——TEARDOWN 只能退役当前 socket 的会话。
        runCatching {
            if (RenderActivity.closeIfActive()) {
                appendLog("关闭上一轮投屏页（清理残留媒体会话）")
            }
        }
        bleAdvertiser?.stop()
        rfcommServer?.stop()
        tcpServer?.stop()
        hotspotManager?.stop()
        // v0.10.54: 关闭 socket 之前先给手机发 RTSP TEARDOWN，让它 retire 这个
        // hisight 会话。之前退出只调 nativeStop()、一个 TEARDOWN 都不发，手机侧
        // 留着半开会话，下次连接就被判成"重复会话"而立刻断掉——1111(28)(30)(31)(32)
        // 四轮都表现为"必须先在手机里移除设备才能再连"。
        // socket 写必须在后台线程（主线程写会抛 NetworkOnMainThreadException），
        // 这里起线程后短 join，保证在 close 之前真正发出去。
        val teardownSock = MediaGlobals.rtspSocket ?: MediaGlobals.preconnectedRtsp
        if (teardownSock != null && !teardownSock.isClosed && teardownSock.isConnected) {
            val t = Thread({
                try {
                    teardownSock.soTimeout = 400
                    val out = teardownSock.getOutputStream()
                    out.write(("TEARDOWN rtsp://${MediaGlobals.phoneIp}/hisight1.2/streamid=0 RTSP/1.0\r\n" +
                            "CSeq: ${(System.currentTimeMillis() % 60000)}\r\n" +
                            "User-Agent: HelloCar\r\n\r\n").toByteArray())
                    out.flush()
                } catch (_: Exception) {
                    // 对端已断时写入必然失败，属正常情况，不阻断退出流程
                }
            }, "hellocar-teardown")
            t.start()
            try { t.join(500) } catch (_: Exception) {}
            appendLog("已发送 RTSP TEARDOWN（通知手机退役本会话）")
        } else {
            appendLog("TEARDOWN 跳过：无可用的 RTSP socket（对端可能已断开）")
        }
        MediaGlobals.audioSocket?.close()
        MediaGlobals.audioSocket = null
        // v0.10.26c: 停止时关闭 RTSP 预连 socket——读循环阻塞在 input.read，
        // 不关 socket 线程永不退出（资源泄漏）。
        runCatching { MediaGlobals.rtspSocket?.close() }
        MediaGlobals.rtspSocket = null
        runCatching { MediaGlobals.preconnectedRtsp?.close() }
        MediaGlobals.preconnectedRtsp = null
        HelloCarBridge.nativeStop()
        appendLog("链路已停止（BLE/RFCOMM/TCP/热点/协议核）")
        setPhase("已停止")
    }

    private fun selfCheck() {
        appendLog("自检：nativeInit → 回环自检 + 身份 + 引擎（与「开始」同路径）")
        startChain()
    }

    override fun onResume() {
        super.onResume()
        // v0.10.64: 从设置页返回时重读参数，让改动立刻反映到下一次连接。
        if (::statusBadge.isInitialized) loadConfigs()
        refreshPin()
        // v0.10.19: 从投屏页返回后，把投屏阶段日志（hellocar_media.log 尾部）合并进 UI 日志区，
        // 便于卡在"等待 HiSight RTSP 端口"时退出后直接看到投屏阶段到底发生了什么。
        // v0.10.66: 投屏阶段日志不再逐行灌进 kotlinLog（会把 400 条主日志挤掉，
        // 断联那几行恰恰是最早被挤掉的）。renderLog 已经直接从文件拼尾部，
        // 这里只标记一下有更新，让它下次重绘时带上新内容。
        mediaTailStamp = -1L
        renderLog()
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(bondReceiver) }
        runCatching { scheduler.shutdownNow() }
    }
}
