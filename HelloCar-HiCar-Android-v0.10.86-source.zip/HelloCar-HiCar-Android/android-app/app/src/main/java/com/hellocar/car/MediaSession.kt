package com.hellocar.car

import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * HiSight 媒体链路（M2c）：在 M2b 连接链路（DMSDP 协商完成）之上建立媒体传输。
 *
 * 链路顺序（对应 backend.rs receive_control/receive_sight）：
 *  1. 轮询 nativeStatus 等到 rtsp_port（DMSDP module5 cmd101 下发的 HiSight 服务端口）
 *     → 连手机 RTSP TCP → openChannel(CH_SIGHT) → 写 ANNOUNCE 初始帧 → 读循环 feed(7)；
 *  2. 引擎在 HiSight SETUP 响应中解析 media_port（视频 TCP）与 input_port（输入 TCP），
 *     Kotlin 轮询 status 检测到后分别连接；
 *  3. 视频：openChannel(CH_MEDIA_VIDEO)，读循环按「4B BE 长度 + RTP 记录」拆帧 feed(5)，
 *     引擎解密并回调 FrameSink（MediaRenderer → MediaCodec → Surface）；
 *  4. 音频：openChannel(CH_MEDIA_AUDIO)，MainActivity 预绑定的 DatagramSocket 收 0xAB 包
 *     直接 feed(6)，引擎解密回调 AudioSink（AudioPlayer → AudioTrack）；
 *  5. 输入：remotectl TCP 连接持有 OutputStream，触摸/按键/关键帧经
 *     nativeSendInput 打包后写入。
 *
 * 端口/对端 IP 说明：对端为手机 IP（LocalOnlyHotspot DHCP 分配，MainActivity 传入
 * guessClientIp 的值）；连接失败按 2s 间隔重试直到 running=false。
 */
class MediaSession(
    private val phoneIp: String,
    private val audioSocket: DatagramSocket?,
    private val rtspPortHint: Int = -1,
    private val log: (String) -> Unit,
    private val onState: (String) -> Unit,
    private val frameSink: HelloCarBridge.FrameSink,
    private val audioSink: HelloCarBridge.AudioSink,
) {
    private val running = AtomicBoolean(false)
    private val inputOutput = AtomicReference<OutputStream?>(null)
    // v0.10.28: 触摸通道重连用——记录 remotectl 端口，写入失败后自动重连
    // （对齐参考 live.rs：input 写失败即断、下次事件前重连）。
    private var inputPort = -1
    // v0.10.28: move 事件限速 20ms（对齐参考 queue_input delay）——防止高频触摸
    // 刷爆手机端 UIBC 队列被断开；down/up 为关键事件不丢弃。
    private val lastTouchAt = java.util.concurrent.atomic.AtomicLong(0)
    // v0.10.29: 音频 UDP 原始收包计数——区分「手机没发」vs「收到但解析失败」。
    private val audioPackets = java.util.concurrent.atomic.AtomicLong(0)
    // v0.10.41: 输入连接失败退避时间戳（3s 内不重复尝试，防触摸主线程连续阻塞）。
    private val lastInputAttemptAt = java.util.concurrent.atomic.AtomicLong(0)
    // v0.10.42: 输入连接必须在后台线程——1111(26) 实测主线程 Socket.connect 直接抛
    // NetworkOnMainThreadException（onTouchEvent 调用 ensureInput），触摸通道 100%
    // 连不上。改为后台单线程串行连接，连接成功前的事件进队列（最多 8 条）连上补发。
    private val inputExec = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "hisight-input").apply { isDaemon = true }
    }
    private val inputConnecting = java.util.concurrent.atomic.AtomicBoolean(false)
    // v0.10.49: RTCP 保活线程（单线程，随 running 结束）
    private val rtcpRunning = java.util.concurrent.atomic.AtomicBoolean(false)
    private val rtcpExec = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "hisight-rtcp").apply { isDaemon = true }
    }
    private val pendingInput = java.util.concurrent.ConcurrentLinkedQueue<ByteArray>()
    private val sockets = java.util.concurrent.CopyOnWriteArrayList<Socket>()
    private val threads = java.util.concurrent.CopyOnWriteArrayList<Thread>()

    companion object {
        private const val MAX_VIDEO_RECORD = 2 * 1024 * 1024
    }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        Thread { runChain() }.start()
    }

    /**
     * 停会话。
     *
     * @param retire true 表示真的要结束这次 hisight 会话（发 TEARDOWN、关 RTSP 长连接、
     *   复位 rtspStarted）。**只有投屏页真正退出（onDestroy）时才允许传 true。**
     *
     * v0.10.62 自检修复：原来 stop() 无条件 retire，而它被三处调用——
     * onSurfaceTextureAvailable（Surface 重建）、onPause（切后台）、onDestroy。
     * 于是在 Surface 重建或用户切一次后台时，就会给手机发 TEARDOWN 并把 RTSP 关了，
     * 手机据此退役会话；而 onPause 里 sessionRef 已被置 null，onResume 的
     * session.start() 拿不到实例、根本不会执行 —— 投屏永久死，再连往往就要求先移除设备。
     * 这三个场景只有最后一个是"真结束"，前面两个必须保持会话存活。
     */
    fun stop(retire: Boolean = false) {
        if (retire) {
            // v0.10.58: 关 socket 之前先发 RTSP TEARDOWN——这是唯一还发得出去的时机。
            sendTeardown()
        }
        running.set(false)
        if (retire) {
            // v0.10.61: RTSP 长连接不在 sockets 列表里（由 MediaGlobals 持有，见
            // startVideo 的复用分支），原来 stop() 从来没关过它 —— 投屏页退出后这条
            // TCP 仍挂在手机侧。这里补上关闭与置空，但只在真结束时做。
            runCatching { MediaGlobals.rtspSocket?.close() }
            MediaGlobals.rtspSocket = null
            // 会话已结束，标志同步复位——否则下次进投屏页会误判"主界面已接管协商"而跳过 ANNOUNCE。
            MediaGlobals.rtspStarted = false
        }
        sockets.forEach { runCatching { it.close() } }
        sockets.clear()
        inputOutput.set(null)
        threads.forEach { runCatching { it.interrupt() } }
        threads.clear()
        // v0.10.42: 释放输入连接线程池与缓存事件（否则线程泄漏 + 旧事件串到新会话）
        pendingInput.clear()
        runCatching { inputExec.shutdownNow() }
        // v0.10.51 自检修复：RTCP 线程也要收——否则每建一次投屏会话就留下一个
        // 空转的 hisight-rtcp 线程（虽然 daemon，但会在下个会话继续往旧端口发包）。
        rtcpRunning.set(false)
        runCatching { rtcpExec.shutdownNow() }
    }

    /**
     * v0.10.58: 向手机发 RTSP TEARDOWN，让它 retire 这个 hisight 会话。
     * stop() 由 RenderActivity.onDestroy/onPause 在 UI 线程调用，直接写 socket 会抛
     * NetworkOnMainThreadException（v0.10.54 就是栽在这里，包了 runCatching 之后异常
     * 被吞、只留一条日志），所以起后台线程写、短 join 保证在 close 之前真的发出去。
     */
    private fun sendTeardown() {
        val sock = MediaGlobals.rtspSocket ?: return
        val body = ("TEARDOWN rtsp://" + MediaGlobals.phoneIp + "/hisight1.2/streamid=0 RTSP/1.0\r\n" +
                "CSeq: " + (System.currentTimeMillis() % 60000) + "\r\n" +
                "User-Agent: HelloCar\r\n\r\n")
        val t = Thread({
            try {
                if (sock.isClosed || !sock.isConnected) return@Thread
                sock.soTimeout = 300
                val out = sock.getOutputStream()
                out.write(body.toByteArray())
                out.flush()
                log("已向手机发送 RTSP TEARDOWN（退役本会话）")
            } catch (e: Exception) {
                log("TEARDOWN 发送失败（对端可能已断）：${e.message}")
            }
        }, "hellocar-teardown")
        t.start()
        try { t.join(600) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ chain --

    private fun runChain() {
        onState("media:等待 HiSight RTSP 端口")
        // v0.10.24: 端口获取前打印来源值——1111(14) 实测投屏页 hint/全局均为 -1
        // 却拿不到端口，需确认哪条路失效。
        log("端口获取：rtspPortHint=$rtspPortHint global=${MediaGlobals.rtspPort}")
        // v0.10.21: 端口来源优先级：MainActivity Intent extra → 进程内全局 MediaGlobals →
        // 轮询 nativeStatus 兜底（v0.10.20 实测后两者均拿不到，全局为最可靠路径）。
        val rtspPort = when {
            rtspPortHint > 0 -> {
                log("使用 MainActivity 传入的 HiSight RTSP 端口 $rtspPortHint")
                rtspPortHint
            }
            MediaGlobals.rtspPort > 0 -> {
                log("使用全局 HiSight RTSP 端口 ${MediaGlobals.rtspPort}")
                MediaGlobals.rtspPort
            }
            else -> waitForPort("rtsp_port", 30_000) ?: run {
                onState("media:RTSP 端口超时")
                return
            }
        }
        log("HiSight RTSP 端口 $rtspPort —— 连接 $phoneIp")
        // v0.10.25: 若 MainActivity 预连线程已接管 RTSP 协商（ANNOUNCE 已发、读循环
        // 已开、sight channel 已创建），直接复用，不再重复 open/initial/读循环——
        // 手机 10s 超时窗口内 ANNOUNCE 必须已发出，投屏页启动延迟不可依赖。
        if (MediaGlobals.rtspStarted && MediaGlobals.sightId >= 0) {
            log("复用 MainActivity 已启动的 RTSP 会话（sight=${MediaGlobals.sightId}, ANNOUNCE 已发）")
            onState("media:HiSight RTSP 协商中…")
            // v0.10.70: 手机 SETUP 回的 Transport 是 `RTP/AVP/TCP;unicast;server_port=0`
            // （1111(40) 实证）——server_port=0 表示视频不走独立端口，而是以 `$` 交织帧
            // 混在同一条 RTSP 连接里。这时 media_port 永远不会有值，等 30 秒纯属白等；
            // 交织帧由引擎在 nativeFeed 里直接交给帧回调，不需要 startVideo。
            val mediaPort = waitForPort("media_port", 3_000)
            val inputPort = waitForPort("input_port", 30_000)
            if (mediaPort != null) {
                log("HiSight 媒体端口 $mediaPort —— 连接视频流")
                startVideo(phoneIp, mediaPort, MediaGlobals.sightId, MediaGlobals.rtspSocket)
            } else {
                log("无独立媒体端口（Transport server_port=0）：视频按 RTSP 交织模式由引擎直接出帧")
                onState("media:交织模式接收视频")
            }
            if (inputPort != null) {
                log("HiSight 输入端口 $inputPort —— 连接触摸通道")
                startInput(phoneIp, inputPort)
            } else {
                log("输入端口 30s 超时（无 SETUP 响应）")
            }
            // v0.10.51 自检修复：RTCP 移到视频/触摸之后，且超时 8s→2s。
            // 原实现把 waitForPort("rtcp_port", 8s) 放在 startVideo 之前——rtcp_port
            // 尚未出现在 status 里时会先干等 8 秒，画面比之前晚 8 秒才连。
            val rtcpPort = waitForPort("rtcp_port", 2_000)
            if (rtcpPort != null) {
                log("HiSight RTCP 端口 $rtcpPort —— 启动保活")
                startRtcp(phoneIp, rtcpPort)
            } else {
                log("RTCP 端口未下发（Transport 无 rtcp_port），跳过保活")
            }
            val socket = audioSocket
            if (socket != null && !socket.isClosed) {
                startAudio(socket)
            } else {
                log("音频 UDP socket 不可用，音频链路跳过")
            }
            return
        }
        // v0.10.23: 优先复用 MainActivity 预连接的 socket（端口一出现即连，抢在手机
        // 切媒体模式离开热点之前）；未连上再走自身 45s 重试。
        val pre = MediaGlobals.preconnectedRtsp
        val rtsp = if (pre != null && !pre.isClosed && pre.isConnected) {
            log("复用 MainActivity 预连接的 HiSight RTSP socket（$phoneIp:$rtspPort）")
            pre
        } else {
            // v0.10.22: RTSP 连接窗口 10s→45s（手机 cmd101 下发端口后可能尚未完成监听，
            // 1111(11) 实测 10s 内未连上即放弃）；每次失败打印原因取证。
            connect(phoneIp, rtspPort, "HiSight RTSP", 45_000)
        }
        if (rtsp == null) {
            log("HiSight RTSP 连接失败（45s 重试耗尽），投屏终止")
            onState("media:RTSP 连接失败")
            return
        }
        val sightId = HelloCarBridge.nativeOpenChannel(HelloCarBridge.CH_SIGHT)
        if (sightId < 0) {
            log("CH_SIGHT 打开失败 rc=$sightId")
            onState("media:HiSight 会话创建失败")
            return
        }
        val initial = HelloCarBridge.nativeInitial(sightId)
        if (initial.isNotEmpty()) {
            log("写入 HiSight RTSP 初始帧 ${initial.size}B")
            writeAll(rtsp, initial)
        }
        startReadLoop(rtsp, sightId) { data -> HelloCarBridge.nativeFeed(sightId, data) }
        // v0.10.31 自检修复（A5）: 投屏页自身路径成功建立 RTSP 会话后写全局状态——
        // ① MainActivity 预连重试据此判断「投屏页已接管」而停止（防双连/双 ANNOUNCE）；
        // ② stopChain 能关掉投屏页自连的 RTSP socket（此前不在 MediaGlobals 中，
        // 读循环线程阻塞在 read 永不退出——线程泄漏）。
        MediaGlobals.rtspSocket = rtsp
        MediaGlobals.rtspStarted = true
        MediaGlobals.sightId = sightId
        onState("media:HiSight RTSP 协商中…")

        // 媒体端口与输入端口由 HiSight SETUP 响应决定（引擎状态）。
        // v0.10.70: server_port=0（RTP/AVP/TCP 交织）时不会有独立媒体端口，见上文说明。
        val mediaPort = waitForPort("media_port", 3_000)
        val inputPort = waitForPort("input_port", 30_000)
        if (mediaPort != null) {
            log("HiSight 媒体端口 $mediaPort —— 连接视频流")
            startVideo(phoneIp, mediaPort, sightId, rtsp)
        } else {
            log("无独立媒体端口（Transport server_port=0）：视频按 RTSP 交织模式由引擎直接出帧")
            onState("media:交织模式接收视频")
        }
        if (inputPort != null) {
            log("HiSight 输入端口 $inputPort —— 连接触摸通道")
            startInput(phoneIp, inputPort)
        } else {
            log("输入端口 30s 超时（无 SETUP 响应）")
        }
        val socket = audioSocket
        if (socket != null && !socket.isClosed) {
            startAudio(socket)
        } else {
            log("音频 UDP socket 不可用，音频链路跳过")
        }
    }

    /** 轮询引擎状态直到指定端口出现（毫秒超时）。 */
    private fun waitForPort(field: String, timeoutMs: Long): Int? {
        val deadline = System.currentTimeMillis() + timeoutMs
        var last = -1
        while (running.get() && System.currentTimeMillis() < deadline) {
            val v = engineStatus()?.optInt(field, -1) ?: -1
            if (v > 0 && v != last) {
                log("引擎状态更新：$field=$v")
                last = v
            }
            if (v > 0) return v
            Thread.sleep(500)
        }
        return null
    }

    private fun engineStatus(): JSONObject? {
        return try {
            JSONObject(HelloCarBridge.nativeStatus()).optJSONObject("engine")
        } catch (e: Exception) {
            null
        }
    }

    /**
     * v0.10.43: 找出与对端同网段的本机 IPv4 地址（车机热点侧，通常是 192.168.43.1）。
     *
     * 背景：LocalOnlyHotspot 在 Android 上不是默认网络。普通 Socket 不 bind 时会走
     * 默认 Wi-Fi 出口，手机端看到的是「非热点网关」的源地址，于是 PLAY 200 之后
     * 不往这条连接推任何字节——这正是 1111(26) 两轮「TCP 连上、PLAY 全 200、0 帧」
     * 的形态。参考实现 live.rs 也是先 bind(local,0) 再 connect 手机的 server_port。
     */
    private fun sourceAddressFor(remoteIp: String): InetAddress? = runCatching {
        val prefix = remoteIp.substringBeforeLast('.', remoteIp)
        NetworkInterface.getNetworkInterfaces().toList().asSequence()
            .flatMap { nif -> nif.inetAddresses.toList().asSequence() }
            .filterIsInstance<java.net.Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.substringBeforeLast('.') == prefix }
    }.getOrNull()

    /**
     * 连接对端端口并返回 Socket。窗口内每 2s 重试；成功/失败/超时均落日志（v0.10.22 取证）。
     */
    private fun connect(ip: String, port: Int, tag: String, timeoutMs: Long = 45_000, singleAttempt: Boolean = false): Socket? {
        val deadline = System.currentTimeMillis() + timeoutMs
        var attempt = 0
        while (running.get() && System.currentTimeMillis() < deadline) {
            attempt++
            var socket: Socket? = null
            try {
                socket = Socket()
                // v0.10.43: 先把源地址钉在热点网段，再 connect——否则媒体连接从默认
                // Wi-Fi 出口发起，手机不认（音频 UDP 能通是因为它 bind 通配收包）。
                val src = sourceAddressFor(ip)
                if (src != null) runCatching { socket.bind(InetSocketAddress(src, 0)) }
                socket.tcpNoDelay = true
                // v0.10.41: 单次连接的超时不得超出剩余窗口——原固定 3000ms 让
                // ensureInput(500ms) 实际阻塞 3s（触摸主线程 ANR 风险）。
                val remain = (deadline - System.currentTimeMillis()).coerceAtLeast(50L)
                socket.connect(InetSocketAddress(ip, port), minOf(3000L, remain).toInt())
                sockets.add(socket)
                log("$tag 连接成功：$ip:$port（第 $attempt 次，源地址 ${socket.localAddress.hostAddress}）")
                return socket
            } catch (e: Exception) {
                runCatching { socket?.close() }
                log("$tag 连接失败：$ip:$port ${e.message ?: e.javaClass.simpleName}（第 $attempt 次）")
                if (singleAttempt) break
                // 仅当窗口还剩足够时间才 sleep，避免 500ms 窗口无谓阻塞
                if (deadline - System.currentTimeMillis() > 2200L) Thread.sleep(2000)
            }
        }
        log(if (singleAttempt) "$tag 连接失败：$ip:$port（单次尝试）"
            else "$tag 连接超时：$ip:$port（${timeoutMs / 1000}s 内未连上）")
        return null
    }

    // ------------------------------------------------------------ sub-transports --

    private fun startReadLoop(socket: Socket, channelId: Int, feed: (ByteArray) -> ByteArray) {
        val t = Thread {
            try {
                val input = socket.getInputStream()
                val buf = ByteArray(4096)
                while (running.get()) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    val reply = feed(buf.copyOf(n))
                    if (reply.isNotEmpty()) {
                        val out = socket.getOutputStream()
                        out.write(reply)
                        out.flush()
                    }
                }
            } catch (e: Exception) {
                log("RTSP 读循环结束：${e.message}")
            } finally {
                log("RTSP 通道关闭（sight=$channelId）")
                HelloCarBridge.nativeCloseChannel(channelId)
            }
        }
        t.name = "hisight-rtsp"
        threads.add(t)
        t.start()
    }

    private fun startVideo(ip: String, port: Int, sight: Int, rtsp: Socket?) {
        val videoId = HelloCarBridge.nativeOpenChannel(HelloCarBridge.CH_MEDIA_VIDEO)
        if (videoId < 0) {
            log("CH_MEDIA_VIDEO 打开失败 rc=$videoId")
            return
        }
        log("视频通道已打开 id=$videoId，开始接收 H.264 流")
        onState("media:视频流接收中…")
        // v0.10.44: 媒体连接改为可重连循环。原实现在「非法长度前缀」或分片读超时时
        // 直接 break —— 一次异常就让本次投屏永久黑屏，手机重新 SETUP 换端口后也
        // 无人察觉（1111(26) 第一轮 38747、第二轮 41129）。
        val t = Thread {
            var attempts = 0
            try {
                while (running.get() && attempts < 3) {
                    attempts++
                    // 每轮先取当前媒体端口：手机重新 SETUP 会换端口，沿用旧端口必 0 字节
                    val live = engineStatus()?.optInt("media_port", -1) ?: -1
                    val curPort = if (live > 0) live else port
                    if (attempts > 1) log("重新连接媒体端口 $curPort（第 $attempts 轮）")
                    val videoSocket = connect(ip, curPort, "HiSight 视频", 10_000)
                    if (videoSocket == null) {
                        log("视频连接失败（第 $attempts 轮）")
                        if (attempts < 3) Thread.sleep(1000)
                        continue
                    }
                    // v0.10.35: 5s 读超时——手机 0 推流时 readFully 永久阻塞，PLAY 重发
                    // 检查永不执行；超时后由读流函数检查「视频仍 0 帧」并重发 PLAY（≤3 次）。
                    videoSocket.soTimeout = 5_000
                    sockets.add(videoSocket)
                    try {
                        readVideoStream(videoSocket, videoId, sight, rtsp)
                    } finally {
                        runCatching { videoSocket.close() }
                        sockets.remove(videoSocket)
                    }
                    if (running.get() && attempts < 3) Thread.sleep(500)
                }
                log("视频接收结束（共 $attempts 轮）")
            } catch (e: Exception) {
                log("视频读循环结束：${e.message}")
            } finally {
                log("视频通道关闭（video=$videoId）")
                HelloCarBridge.nativeCloseChannel(videoId)
                // v0.10.81: 视频是被动结束（重连轮次耗尽/流 EOF）而不是用户主动 stop 时，
                // 说明这条投屏已经没有画面了；音频若继续解码播放，用户会听到"画面没了还有声音"。
                // 1111(49) 第 244 行 EOF → 3 轮重连全失败 → 音频仍在收包播放，就是这个现场。
                if (running.get()) {
                    log("视频已放弃，联动停止音频")
                    runCatching { MediaGlobals.audioStopper?.invoke() }
                }
            }
        }
        t.name = "hisight-video"
        threads.add(t)
        t.start()
    }

    /**
     * 在已连接的媒体 socket 上读 4B BE 长度前缀 + RTP 记录，直到 EOF / 非法封装 / stop()。
     * v0.10.44: 从 startVideo 拆出，返回即由外层关闭重连——不再一次性退出。
     */
    private fun readVideoStream(socket: Socket, videoId: Int, sight: Int, rtsp: Socket?) {
        val input = socket.getInputStream()
        val lenBuf = ByteArray(4)
        var rx = 0L
        var playRetries = 0
        var lenOff = 0
        // v0.10.84: RTP 序列号缺口统计。
        // 1111(49) 的包日志 head=90e0b5aa... 已证实记录体就是标准 RTP（0x90=V2/PT=0x60，
        // 第 2-3 字节是序列号）。H.264 的 P 帧参考链断一个包，后续帧会一直花到下一个
        // I 帧——这正是"滑动换页突然彩色块"的成因。此前只在解码器抛异常时才请求关键帧，
        // 而丢包不会抛异常，所以花屏只能等编码器自己出 I 帧。
        var lastSeq = -1
        var seqGaps = 0L
        var lostEst = 0L
        var lastKeyReqAt = 0L
        while (running.get()) {
            // v0.10.37: 4B 长度前缀分片读——原 readFully 在 SocketTimeoutException
            // 时丢弃已读字节、下次从头重读会跳过已读部分 → 长度前缀错位毁流。
            var eof = false
            while (lenOff < 4) {
                val r = try {
                    input.read(lenBuf, lenOff, 4 - lenOff)
                } catch (e: java.net.SocketTimeoutException) {
                    if (rx == 0L && playRetries < 3 && rtsp != null && !rtsp.isClosed) {
                        val rec = HelloCarBridge.nativeRequestPlay(sight)
                        if (rec.isNotEmpty()) {
                            writeAll(rtsp, rec)
                            playRetries++
                            log("视频 0 帧，重发 HiSight PLAY（第 $playRetries 次）")
                        }
                    }
                    continue
                }
                if (r < 0) { eof = true; break }
                lenOff += r
            }
            if (eof) {
                log("视频流 EOF（已收 $rx 包）")
                return
            }
            lenOff = 0
            val n = ((lenBuf[0].toInt() and 0xFF) shl 24) or
                ((lenBuf[1].toInt() and 0xFF) shl 16) or
                ((lenBuf[2].toInt() and 0xFF) shl 8) or
                (lenBuf[3].toInt() and 0xFF)
            if (n <= 0 || n > MAX_VIDEO_RECORD) {
                // v0.10.41: 非法长度前缀取证——若手机在媒体端口上发的是 RTP
                // （首字节 0x80）或 RTSP interleaved（首字节 0x24）而非 4B 长度
                // 前缀记录，会在此静默退出、黑屏且无线索。打印原始前缀 hex。
                // v0.10.44: 不再 break 终止，交由外层关闭重连。
                val head = lenBuf.joinToString("") { "%02x".format(it.toInt() and 0xFF) }
                log("视频长度前缀非法 n=$n（lenBuf=$head）——放弃该连接，外层重连")
                return
            }
            val payload = ByteArray(n)
            var poff = 0
            var packTimeouts = 0
            while (poff < n) {
                val r = try {
                    input.read(payload, poff, n - poff)
                } catch (e: java.net.SocketTimeoutException) {
                    // v0.10.44: 原实现无上限 continue —— 手机发半包后本线程永久卡死，
                    // 既不重发 PLAY 也不重连。3 次（≈15s）不到齐即放弃该包并重连。
                    packTimeouts++
                    if (packTimeouts >= 3) {
                        log("视频包分片读超时 3 次（$poff/$n，已收 $rx 包）——放弃该连接，外层重连")
                        return
                    }
                    continue
                }
                if (r < 0) {
                    log("视频流 EOF（半包 $poff/$n，已收 $rx 包）")
                    return
                }
                poff += r
            }
            rx++
            // v0.10.84: RTP 序列号缺口检测 —— 发现缺包立刻补一次关键帧请求，别等花屏扩散。
            // 只在 RTP 版本位为 2 时才解析（0x80 掩码取高位），非 RTP 封装直接跳过、绝不误判。
            if (payload.size >= 4 && (payload[0].toInt() and 0xC0) == 0x80) {
                val seq = ((payload[2].toInt() and 0xFF) shl 8) or (payload[3].toInt() and 0xFF)
                if (lastSeq >= 0) {
                    // 模 65536 求步进：1=连续，0=重传重复，其余为缺口。
                    val step = (seq - lastSeq + 65536) % 65536
                    // 跨度 >32768 视为流重置/乱序回卷，不算丢包，只重置基线。
                    if (step in 2..32768) {
                        seqGaps++
                        lostEst += (step - 1).toLong()
                        val now = android.os.SystemClock.uptimeMillis()
                        // 限流 2s：nativeSendInput 要抢 jni 全局锁，请求太密反而加重卡顿。
                        if (now - lastKeyReqAt > 2000L) {
                            lastKeyReqAt = now
                            HelloCarBridge.nativeSendInput(HelloCarBridge.INPUT_KEYFRAME, ByteArray(0))
                            log("视频 RTP 缺口 seq=$lastSeq→$seq（缺 ${step - 1} 包），已请求关键帧")
                        }
                    }
                }
                lastSeq = seq
            }
            if (rx <= 3 || rx % 100 == 0L) {
                val head = payload.take(16).joinToString("") { "%02x".format(it.toInt() and 0xFF) }
                log("视频流已收包 $rx（${payload.size}B head=$head 缺口 ${seqGaps}次/约丢 ${lostEst}包）")
            }
            HelloCarBridge.nativeFeed(videoId, payload)
        }
    }

    private fun startInput(ip: String, port: Int) {
        inputPort = port
        // v0.10.29: 不再提前连接——参考 live.rs 是「首次触摸/按键事件触发时才连接」
        // （feedback 触发，100ms 超时）。我们此前 SETUP 后立即连接并空闲等待，手机端
        // 对空闲 remotectl 连接超时回收（1111(20)：连接成功但用户触摸时已死，重连也
        // 拒绝）。改为事件触发：sendTouch/sendKey 时 ensureInput 连接并立即写入首事件。
        log("HiSight 输入端口 $port 已协商——触摸/按键事件触发时连接")
        onState("media:触摸通道就绪")
        // v0.10.58: 自动"点一下"。
        // 用户实测反馈是"点一下才出画面，投屏是成功的"——链路全部就绪、手机也在推流，
        // 但要手指点一下车机屏才真正显示。前面七版方案（去 elevation / 换 TextureView /
        // 每帧 postInvalidateOnAnimation / setOpaque+setDefaultBufferSize /
        // onWindowFocusChanged 强刷 / isFocusableInTouchMode+requestFocus）全在车机 UI 层
        // 打转，没有一个试过「替用户把这下点击真的发给手机」。这里在输入端口就绪后自动
        // 发一次 DOWN+UP（落在顶部中央 y=2%，避开高德侧边栏和底部 Dock），等价于用户那
        // 一下点击，用来判定推流的触发点在手机侧还是车机侧。
        Thread({
            try {
                Thread.sleep(1500)
                if (!running.get()) return@Thread
                log("自动唤醒：向手机发送一次点击（试图免去手动点屏）")
                sendTouch(0.5f, 0.02f, 0)
                Thread.sleep(80)
                sendTouch(0.5f, 0.02f, 1)
            } catch (_: Exception) {
            }
        }, "hisight-autowake").start()
    }

    // v0.10.49: RTCP 保活。手机在 SETUP 200 的 Transport 里声明 rtcp_port，车机侧
    // 从不回 RTCP 时媒体会话约 2 秒后被判超时（1111(30) 三段会话均在出画面 2~2.5
    // 秒后依次关闭 business/video/audio）。这里按 1s 周期发最小 RR（8 字节）。
    private fun startRtcp(ip: String, port: Int) {
        if (!rtcpRunning.compareAndSet(false, true)) return
        rtcpExec.execute {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket()
                sourceAddressFor(ip)?.let { src ->
                    runCatching { sock.bind(InetSocketAddress(src, 0)) }
                }
                val addr = InetSocketAddress(ip, port)
                val rr = byteArrayOf(0x80.toByte(), 0xC9.toByte(), 0x00, 0x01, 0, 0, 0, 0)
                log("RTCP 保活线程启动（$ip:$port，源=${sock.localAddress}）")
                var sent = 0
                while (running.get()) {
                    sock.send(DatagramPacket(rr, rr.size, addr))
                    if (++sent % 10 == 0) log("RTCP 已发送 $sent 个 RR（端口 $port）")
                    Thread.sleep(1000)
                }
            } catch (e: Exception) {
                log("RTCP 保活结束：${e.message ?: e.javaClass.simpleName}")
            } finally {
                runCatching { sock?.close() }
                rtcpRunning.set(false)
            }
        }
    }

    private fun startAudio(socket: DatagramSocket) {
        val audioId = HelloCarBridge.nativeOpenChannel(HelloCarBridge.CH_MEDIA_AUDIO)
        if (audioId < 0) {
            log("CH_MEDIA_AUDIO 打开失败 rc=$audioId")
            return
        }
        log("音频通道已打开 id=$audioId，UDP ${socket.localPort} 接收中…")
        val t = Thread {
            try {
                // v0.10.31 自检修复（B7）: 缓冲 2048→8192——0xAB 音频包若超过 2048B
                // 会被截断（引擎按声明长度校验会丢包）；8192 覆盖 AAC-ADTS 全尺寸。
                val buf = ByteArray(8192)
                val packet = DatagramPacket(buf, buf.size)
                while (running.get()) {
                    socket.receive(packet)
                    if (packet.length > 0) {
                        // v0.10.29: 收包计数取证——1111(20) 音频 0KB 需区分
                        // 「手机没发 speaker 音频」vs「发了但 0xAB/解密/解析失败」
                        // （后者引擎 audio frame reject 日志会打）。此处只计原始 UDP 收包。
                        val n = audioPackets.incrementAndGet()
                        if (n <= 3 || n % 50 == 0L) {
                            log("音频 UDP 已收包 $n（${packet.length}B）")
                        }
                        HelloCarBridge.nativeFeed(audioId, buf.copyOf(packet.length))
                    }
                }
            } catch (e: Exception) {
                log("音频读循环结束：${e.message}")
            } finally {
                log("音频通道关闭（audio=$audioId，共收包 ${audioPackets.get()}）")
                HelloCarBridge.nativeCloseChannel(audioId)
            }
        }
        t.name = "hisight-audio"
        threads.add(t)
        t.start()
    }

    // ------------------------------------------------------------- input events --

    /** 触摸事件：x/y 归一化 [0,1]，action 0=按下/1=抬起/2=移动。 */
    fun sendTouch(x: Float, y: Float, action: Int) {
        // v0.10.28: move 限速 20ms（对齐参考 queue_input delay=20ms）——快速滑动时
        // 高频 move 直接丢弃（坐标连续、影响小），down/up 关键事件必发。
        if (action == 2) {
            val now = System.currentTimeMillis()
            val last = lastTouchAt.get()
            if (now - last < 20) return
            lastTouchAt.set(now)
        }
        val payload = ByteArray(9)
        ByteBuffer.wrap(payload).putFloat(x).putFloat(y).put(action.toByte())
        writeInput(HelloCarBridge.nativeSendInput(HelloCarBridge.INPUT_TOUCH, payload))
    }

    /** 按键事件：code 见 HelloCarBridge INPUT_KEY 注释（0 home … 9 previous）。 */
    fun sendKey(code: Int) {
        writeInput(HelloCarBridge.nativeSendInput(HelloCarBridge.INPUT_KEY, byteArrayOf(code.toByte())))
    }

    /** 关键帧请求：引擎置 wait_key，等待手机下一个 IDR。 */
    fun requestKeyframe() {
        HelloCarBridge.nativeSendInput(HelloCarBridge.INPUT_KEYFRAME, ByteArray(0))
    }

    // v0.10.29: 事件触发式输入连接。发送前无连接则尝试连接（500ms 短超时），
    // 成功立即由调用方写入当前事件——手机端对「连接后立即有数据」的连接不回收。
    // v0.10.42: 本函数只在后台线程（inputExec）执行——主线程调用 Socket.connect
    // 会被 Android 直接拒绝（NetworkOnMainThreadException）。
    private fun ensureInput() {
        if (inputOutput.get() != null) return
        if (inputPort <= 0) return
        // v0.10.41: 失败后 3s 退避——连续失败时不能每次都发起连接。
        val now = System.currentTimeMillis()
        val last = lastInputAttemptAt.get()
        if (now - last < 3000L) return
        lastInputAttemptAt.set(now)
        val socket = connect(phoneIp, inputPort, "HiSight 输入", 500, singleAttempt = true)
        if (socket == null) {
            log("输入通道连接失败（事件触发，下次触摸重试）")
            return
        }
        try {
            val out = socket.getOutputStream()
            inputOutput.set(out)
            log("输入通道已连接（remotectl $inputPort，事件触发）")
            // v0.10.42: 补发连接期间缓存的事件（按序，最多 8 条）
            var sent = 0
            while (true) {
                val w = pendingInput.poll() ?: break
                try { out.write(w); out.flush(); sent++ } catch (e: Exception) { inputOutput.set(null); break }
            }
            if (sent > 0) log("输入通道已连接并补发缓存事件 $sent 条")
        } catch (e: Exception) {
            log("输入通道输出流错误：${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** 后台发起输入连接（单线程、防重入）。 */
    private fun ensureInputAsync() {
        if (inputOutput.get() != null) return
        if (!inputConnecting.compareAndSet(false, true)) return
        try {
            inputExec.execute {
                try { ensureInput() } finally { inputConnecting.set(false) }
            }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // v0.10.51: 会话已 stop（inputExec 被 shutdownNow）之后仍有触摸到达时，
            // execute 会抛 RejectedExecutionException 并一路抛到 onTouchEvent 崩界面。
            inputConnecting.set(false)
        }
    }

    private fun writeInput(wire: ByteArray) {
        if (wire.isEmpty()) return
        // v0.10.47: 所有 socket 写必须离开主线程。sendTouch 由 RenderActivity 的
        // onTouchEvent（主线程）调用，原实现在调用线程直接 out.write()，连上之后
        // 每条触摸都抛 NetworkOnMainThreadException 并把 inputOutput 置空
        // （1111(29) 实测：输入通道已连接→补发 8 条→之后全部写入失败）。
        try {
            inputExec.execute { writeInputNow(wire) }
        } catch (_: java.util.concurrent.RejectedExecutionException) {
            // v0.10.51: 会话停止后 inputExec 已关闭，此时触摸不能把异常抛到主线程。
        }
    }

    /** 在 inputExec 线程内真正写入；失败则入队并就地重连（同线程，不会再撞主线程限制）。 */
    private fun writeInputNow(wire: ByteArray) {
        val out = inputOutput.get()
        if (out != null) {
            try {
                out.write(wire)
                out.flush()
                return
            } catch (e: Exception) {
                log("输入通道写入失败：${e.message ?: e.javaClass.simpleName}")
                inputOutput.set(null)
            }
        }
        if (pendingInput.size < 8) pendingInput.offer(wire)
        ensureInput()
    }

    private fun writeAll(socket: Socket, data: ByteArray) {
        try {
            val out = socket.getOutputStream()
            out.write(data)
            out.flush()
        } catch (e: Exception) {
            log("写入失败：${e.message}")
        }
    }

    private fun readFully(input: InputStream, target: ByteArray): Boolean {
        var offset = 0
        while (offset < target.size) {
            val n = input.read(target, offset, target.size - offset)
            if (n < 0) return false
            offset += n
        }
        return true
    }
}
