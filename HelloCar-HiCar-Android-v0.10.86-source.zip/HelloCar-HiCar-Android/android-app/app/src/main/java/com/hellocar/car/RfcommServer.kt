package com.hellocar.car

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.os.ParcelUuid
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * RFCOMM 服务端：注册 FE35（NearbyServerSocket）与 FE36（NearbyBusinessSocket）。
 *
 * 对应 radio.rs:10-11/386-387：Android 系统自动完成 SDP 注册与信道分配，手机按
 * SDP 查询 FE35/FE36 定位信道 —— 与原实现的动态 SDP 发现天然兼容（协议解析 §2.2）。
 * 连接建立后把字节流喂给协议核通道：
 *   FE35 → nativeOpenChannel(CH_NEARBY_RFCOMM)（含初始协商帧）
 *   FE36 → nativeOpenChannel(CH_BUSINESS)（认证信封流）
 * 每个连接一个读线程；回复经 nativeFeed 返回后写回 socket。
 *
 * 风险（v0.7.0）：原实现 RequireAuthentication=false；Android
 * listenUsingRfcommWithServiceRecord 默认要求链路层安全（secure），华为官方
 * 无线流程是「手机扫描到 BLE 广播 → 弹窗 → 主动发起 BR 连接」，未加密发起时
 * secure socket 会拒接 —— 当时切换为 insecure。
 *
 * v0.10.2 关键修正：实测证明配对完成后（bondState=12）手机连 FE35 仍零字节
 * 立即关闭（read -1）。根因：insecure listener 建立的链路不要求/不保证加密，
 * 手机 HiCar 服务连上后校验链路安全级别失败 → 判定不安全 → 立即关闭。
 * 配对已完成（v0.10.1 createBond 打通），手机发起的 BR 连接是加密认证的，
 * 改回 secure listener（listenUsingRfcommWithServiceRecord）使链路加密，
 * 匹配手机端安全要求。createBond 主动配对逻辑保留（配对未完成时仍会触发）。
 */
class RfcommServer(
    private val adapter: BluetoothAdapter,
    private val log: (String) -> Unit,
    private val openChannel: (kind: Int) -> Int,
    private val feedChannel: (id: Int, data: ByteArray) -> ByteArray,
    private val initialChannel: (id: Int) -> ByteArray,
    private val closeChannel: (id: Int) -> Unit,
    private val onConnectionState: (connected: Boolean, which: String) -> Unit,
    private val onBusinessChannel: (Int) -> Unit,
) {
    private val running = AtomicBoolean(false)
    private var server35: BluetoothServerSocket? = null
    private var server36: BluetoothServerSocket? = null
    private val sockets = mutableListOf<BluetoothSocket>()
    // v0.10.57: 每类信道同时只保留一个活跃 socket。
    // 1111(35) 暴露的问题：手机断开后我们的 read 还没感知（bt socket closed 要 5s 超时），
    // accept 又收进来一条新连接，于是同一个信道上有两条 handleConnection 同时在喂
    // nativeFeed；再加上日志里出现过另一台设备（business 首帧 version 13.2.0.400，
    // 而 Magic7 Pro 是 14.2.0.325）也在连，三条流互相踩，native 侧会话状态被搅乱，
    // 表现就是"再次连接失败、比之前慢"。新连接进来时主动关掉同类旧 socket。
    @Volatile private var activeControl: BluetoothSocket? = null
    @Volatile private var activeBusiness: BluetoothSocket? = null

    companion object {
        val FE35 = UUID.fromString("0000fe35-0000-1000-8000-00805f9b34fb")
        val FE36 = UUID.fromString("0000fe36-0000-1000-8000-00805f9b34fb")
        private const val READ_TIMEOUT_MS = 5000
    }

    fun start() {
        if (running.get()) return
        running.set(true)
        val s35 = try {
            adapter.listenUsingRfcommWithServiceRecord("NearbyServerSocket", FE35)
        } catch (e: SecurityException) {
            log("FE35 注册失败（缺 BLUETOOTH_CONNECT 权限）：${e.message}"); null
        } catch (e: IOException) {
            log("FE35 注册失败：${e.message}"); null
        }
        val s36 = try {
            // v0.10.7：优先用指定信道 24 注册 FE36（对齐原版 radio.rs FE36=24，且 kind2 响应回 24）。
            // v0.10.5/0.10.6 实测本 ROM 的 BluetoothServerSocket.mChannel 恒为 -1（反射/轮询均拿不到），
            // SDP 动态分配的信道未知，kind2 响应回 24 与 SDP 信道不一致 → 手机连 FE36 失败。
            // listenUsingRfcommOn(24) 指定信道 24 = 响应值，手机按响应信道直连即可命中。
            // compileSdk=34 下该方法已从 SDK 移除（Android 14+ 强制 SDP），故反射调用；
            // 车机系统（比亚迪 DiLink，API<34）运行时存在该方法。无 SDP 记录的风险：
            // 若手机对 FE36 走 SDP 发现则回退失败——本轮实测区分机制。
            val m = BluetoothAdapter::class.java.getMethod("listenUsingRfcommOn", Int::class.javaPrimitiveType)
            (m.invoke(adapter, 24) as BluetoothServerSocket).also {
                log("FE36 已用指定信道 24 注册（listenUsingRfcommOn，与 kind2 响应信道一致）")
            }
        } catch (e: Throwable) {
            log("FE36 指定信道 24 注册失败（${e.javaClass.simpleName}：${e.message}），回退 SDP 动态注册")
            try {
                adapter.listenUsingRfcommWithServiceRecord("NearbyBusinessSocket", FE36).also {
                    log("FE36 SDP 动态注册成功（回退路径，信道由系统分配）")
                }
            } catch (e2: Throwable) {
                log("FE36 SDP 回退注册失败：${e2.message}")
                null
            }
        }
        server35 = s35
        server36 = s36
        if (s35 == null && s36 == null) {
            running.set(false)
            log("RFCOMM 服务注册全部失败——检查蓝牙权限/蓝牙已开启/车机蓝牙栈约束")
            return
        }
        log("RFCOMM 服务已注册：FE35(control)${if (s35 != null) "✓" else "✗"} FE36(business)${if (s36 != null) "✓" else "✗"}，等待手机连接")
        // v0.10.6：反射读取 FE36 真实 RFCOMM 信道号（listenUsingRfcommWithServiceRecord 由系统分配）。
        // v0.10.5 实测：listen 返回时 mChannel 仍为 -1（蓝牙栈异步分配信道），必须轮询等待分配完成，
        // 否则 kind2 响应回错信道，手机直连 FE36 失败弹"连接失败，请重试"。
        if (s36 != null) {
            val channel = readRfcommChannel(s36)
            if (channel != null && channel in 1..30) {
                log("FE36 实际 RFCOMM 信道: $channel（反射读取，kind2 响应将回此值）")
                onBusinessChannel(channel)
            } else {
                log("FE36 信道尚未分配（mChannel=${channel ?: "null"}），轮询等待…")
                Thread {
                    var ch = readRfcommChannel(s36)
                    var tries = 0
                    while ((ch == null || ch !in 1..30) && tries < 20) {
                        Thread.sleep(200)
                        ch = readRfcommChannel(s36)
                        tries++
                    }
                    if (ch != null && ch in 1..30) {
                        log("FE36 实际 RFCOMM 信道: $ch（反射轮询第 ${tries + 1} 次，kind2 响应将回此值）")
                        onBusinessChannel(ch)
                    } else {
                        // v0.10.6 兜底：Android 蓝牙栈顺序分配 RFCOMM 信道（FE35 先注册），
                        // FE36 通常紧邻 FE35+1。读 FE35 的信道号推测 FE36（标注"推测"）。
                        val ch35 = s35?.let { readRfcommChannel(it) }
                        val guessed = if (ch35 != null && ch35 in 1..29) ch35 + 1 else null
                        if (guessed != null) {
                            log("FE36 信道反射失败，按 FE35=${ch35} 推测 FE36=$guessed（系统顺序分配），kind2 响应将回此值")
                            onBusinessChannel(guessed)
                        } else {
                            log("FE36 信道反射轮询失败（${ch ?: "null"}），回退 UI/默认值")
                        }
                    }
                }.start()
            }
        }
        if (s35 != null) Thread { acceptLoop(s35, "control") }.start()
        if (s36 != null) Thread { acceptLoop(s36, "business") }.start()
    }

    /// 反射读取 BluetoothServerSocket 私有字段 mChannel（第三方应用可读）。
    private fun readRfcommChannel(socket: BluetoothServerSocket): Int? {
        return try {
            val field = BluetoothServerSocket::class.java.getDeclaredField("mChannel")
            field.isAccessible = true
            field.getInt(socket)
        } catch (e: Throwable) {
            log("FE36 信道反射读取异常：${e.javaClass.simpleName}: ${e.message}")
            null
        }
    }

    private fun acceptLoop(server: BluetoothServerSocket, which: String) {
        while (running.get()) {
            val socket = try {
                server.accept()
            } catch (e: IOException) {
                if (running.get()) log("$which accept 中断：${e.message}")
                break
            }
            log("RFCOMM $which 连接建立：${socket.remoteDevice.name}（${socket.remoteDevice.address}）")
            // v0.10.57: 同类信道只留一个活跃 socket——新连接进来先掐掉旧的，
            // 避免两条 handleConnection 并存互相覆盖 native 侧会话（1111(35)）。
            val prev = if (which == "control") activeControl else activeBusiness
            if (prev != null && prev !== socket) {
                log("RFCOMM $which 已有旧连接未退，主动关闭旧 socket（防双流并存）")
                runCatching { prev.close() }
            }
            if (which == "control") activeControl = socket else activeBusiness = socket
            // v0.10.7 诊断：accept 返回的 BluetoothSocket.mChannel = 实际连接信道。
            // 用于验证系统信道分配规律（FE35=?, FE36=?）与指定信道 24 是否命中。
            try {
                val f = BluetoothSocket::class.java.getDeclaredField("mChannel")
                f.isAccessible = true
                val mc = f.getInt(socket)
                log("$which accept socket mChannel=$mc（诊断：实际连接信道）")
            } catch (t: Throwable) {
                log("$which accept socket mChannel 读取失败：${t.javaClass.simpleName}")
            }
            onConnectionState(true, which)
            sockets.add(socket)
            // v0.10.1：BR/EDR 配对检查与主动配对。
            // 原实现时序：② BR/EDR 配对（Agent NoInputNoOutput 自动确认）→ ③ 手机连 FE35。
            // Android 普通 App 无法注册系统配对 Agent，若设备未配对，手机 HiCar 服务
            // 在连接建立后校验 bond 状态失败会立即关闭连接（v0.10.0 实测 read -1 零字节）。
            // 这里对手机 MAC 主动 createBond() 触发系统配对流程，配对完成后再重试连接。
            try {
                val dev = socket.remoteDevice
                val state = try { dev.bondState } catch (e: SecurityException) { -1 }
                log("$which 配对状态：bondState=$state（10=无 11=配对中 12=已配对 13=解除中）")
                if (state != BluetoothDevice.BOND_BONDED) {
                    val ok = try {
                        dev.createBond()
                    } catch (e: SecurityException) {
                        log("$which createBond 失败（缺 BLUETOOTH_CONNECT 权限）：${e.message}")
                        false
                    }
                    log("$which 主动配对已发起：$ok（请在车机/手机端完成配对确认；蓝牙配对 PIN 由车机系统蓝牙设置决定，与 HelloCar 的 HiCar 连接码无关）")
                }
            } catch (e: Exception) {
                log("$which 配对检查异常：${e.message}")
            }
            Thread { handleConnection(socket, which) }.start()
        }
    }

    private fun handleConnection(socket: BluetoothSocket, which: String) {
        val kind = if (which == "control") HelloCarBridge.CH_NEARBY_RFCOMM else HelloCarBridge.CH_BUSINESS
        val channelId = openChannel(kind)
        if (channelId < 0) {
            log("$which 通道打开失败 rc=$channelId，关闭连接")
            runCatching { socket.close() }
            return
        }
        // 协议核初始帧（FE35 的 Nearby 协商起始帧）。
        // v0.10.0: FE35 改为被动协商——手机是 initiator，首个协商帧由手机发出，
        // 车机不再抢发 initial（原实现 radio.rs rfcomm 事件恒 initiator=false）。
        val initial = initialChannel(channelId)
        val input: InputStream
        val output: OutputStream
        try {
            input = socket.inputStream
            output = socket.outputStream
            if (initial.isNotEmpty()) {
                output.write(initial)
                output.flush()
            }
        } catch (e: IOException) {
            log("$which 流错误：${e.message}")
            closeChannel(channelId)
            runCatching { socket.close() }
            return
        }
        val buf = ByteArray(4096)
        try {
            while (running.get()) {
                val n = input.read(buf)
                if (n < 0) {
                    log("$which 连接 EOF")
                    break
                }
                if (n == 0) continue
                log("$which 收到 ${n} 字节首帧: ${buf.copyOf(n).joinToString("") { "%02x".format(it) }.take(64)}")
                val reply = feedChannel(channelId, buf.copyOf(n))
                if (reply.isNotEmpty()) {
                    output.write(reply)
                    output.flush()
                }
            }
        } catch (e: IOException) {
            log("$which 读取异常：${e.message}")
        } finally {
            closeChannel(channelId)
            onConnectionState(false, which)
            runCatching { socket.close() }
            sockets.remove(socket)
        }
    }

    fun stop() {
        running.set(false)
        runCatching { server35?.close() }
        runCatching { server36?.close() }
        sockets.forEach { runCatching { it.close() } }
        sockets.clear()
        server35 = null
        server36 = null
        // v0.10.61 自检修复：单流引用也要清——否则下一轮 start() 后第一次 accept 会把
        // 上一轮那条早已断开的对象当成"活跃连接"去 close，日志里会出现一条误导性的
        // "已有旧连接未退"，排查时容易误判真的双流并存。
        activeControl = null
        activeBusiness = null
        log("RFCOMM 服务已停止")
    }
}
