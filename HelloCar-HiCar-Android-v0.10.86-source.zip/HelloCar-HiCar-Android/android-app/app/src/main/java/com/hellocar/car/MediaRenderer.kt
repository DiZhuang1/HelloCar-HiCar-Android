package com.hellocar.car

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.util.concurrent.atomic.AtomicLong

/**
 * H.264 渲染器（M2c）：引擎回调的 H.264 Annex-B 访问单元 → MediaCodec 硬解 → Surface。
 *
 * 设计（移植设计 §2.6）：
 *  - 每个 buffer 提交一个完整访问单元（引擎已按关键帧拼接 SPS/PPS）；
 *  - 关键帧前丢弃非关键帧（引擎 wait_key 已处理，此处双保险：解码器未启动时丢弃）；
 *  - 解码器错误/输出卡死 → 请求关键帧（nativeSendInput INPUT_KEYFRAME）+ 重启解码器；
 *  - 分辨率保持 800×480 信号，Surface 显示层拉伸（M5 再改协商分辨率）。
 *
 * 线程模型：onFrame 由 JNI feed 调用线程（视频读线程）回调，本类经 HandlerThread
 * 串行提交到 MediaCodec（queueInputBuffer 本身线程安全，但保持单线程更稳）。
 */
class MediaRenderer(
    private val surface: Surface,
    // v0.10.38: 解码器失败取证日志——一旦手机推流但解码器起不来，必须可见原因
    // （此前 catch 静默 return，手机推流后仍黑屏且无任何日志）。
    private val log: (String) -> Unit = {},
    // v0.10.47: 每渲染一帧回调一次——TextureView 需一次绘制才 updateTexImage，
    // 车机窗口在无输入/无动画时不主动合成，导致"画面停住、点一下才刷新"。
    private val onFrameRendered: (() -> Unit)? = null,
    // v0.10.61: 解码尺寸跟随协商值（设置面板可改 800×480 / 1024×600 / 1280×720），
    // 不再写死。写死时用户在面板换档，手机按新尺寸推流而解码器仍按旧尺寸配置，
    // 轻则拉伸变形、重则 configure 直接被拒。
    private val width: Int = 1280,
    private val height: Int = 720,
    /** v0.10.64: 解码器报告的真实输出尺寸（走 INFO_OUTPUT_FORMAT_CHANGED）。 */
    private val onVideoSize: ((Int, Int) -> Unit)? = null,
) : HelloCarBridge.FrameSink {

    private val thread = HandlerThread("h264-render").apply { start() }
    private val handler = Handler(thread.looper)
    private val codecRef = java.util.concurrent.atomic.AtomicReference<MediaCodec?>(null)
    private val resetting = java.util.concurrent.atomic.AtomicBoolean(false)
    private val framesDecoded = AtomicLong(0)

    fun start() {
        handler.post { configureCodec() }
    }

    fun stop() {
        handler.post {
            runCatching { codecRef.get()?.stop() }
            runCatching { codecRef.get()?.release() }
            codecRef.set(null)
        }
        thread.quitSafely()
    }

    // v0.10.75: 流畅性取证——队列积压深度 + 解码帧率。
    // 此前"卡"完全不可观测，只能靠主观感受；这两项能把"解码跟不上"（fps 低且积压涨）
    // 和"网络来帧就慢"（fps 低但积压为 0）分开。
    private val pending = java.util.concurrent.atomic.AtomicInteger(0)
    private var lastRateAt = 0L
    private var lastRateFrames = 0L

    override fun onFrame(key: Boolean, pts: Long, data: ByteArray) {
        // 30fps 下每条 post 开销可接受；避免在 JNI 线程直接操作 MediaCodec。
        pending.incrementAndGet()
        handler.post {
            try {
                feed(key, pts, data)
            } finally {
                pending.decrementAndGet()
            }
        }
        val now = android.os.SystemClock.uptimeMillis()
        if (lastRateAt == 0L) {
            lastRateAt = now
            lastRateFrames = framesDecoded.get()
        } else if (now - lastRateAt >= 5000L) {
            val f = framesDecoded.get()
            val fps = (f - lastRateFrames) * 1000.0 / (now - lastRateAt).toDouble()
            val backlog = pending.get()
            if (fps < 20.0 || backlog > 3) {
                log("MediaRenderer: 解码 ${"%.1f".format(fps)}fps，队列积压 $backlog（源 30fps）——已落后")
            } else {
                log("MediaRenderer: 解码 ${"%.1f".format(fps)}fps，队列积压 $backlog")
            }
            lastRateAt = now
            lastRateFrames = f
        }
    }

    private fun configureCodec() {
        // v0.10.61: 尺寸来自构造参数（与 hisight.rs 协商值一致）
        // v0.10.84: 先试带低延迟参数的配置，被拒就原样回退 —— 绝不让解码器因为
        // 一个可选的调优参数起不来（那会直接黑屏，比"不够流畅"严重得多）。
        //
        // 1111(49) 实测解码输出 23~29fps 抖动而队列积压恒为 1：积压为 1 说明 feed 一侧
        // 完全跟得上，抖动来自解码器自身按通用默认节奏出帧。operating-rate 告诉解码器
        // "我要 30fps 的节拍"，priority=0 让它优先拿算力，latency=1 打开低延迟输出
        // （后者不是所有芯片都认，所以放在 runCatching 里单独试）。
        val codec = createWithTuning() ?: createFallback() ?: return
        codecRef.set(codec)
        log("MediaRenderer: MediaCodec 视频解码器已就绪（${width}x$height Surface）")
    }

    /** 带低延迟参数的解码器；任何一步被拒都返回 null，交给 [createFallback]。 */
    private fun createWithTuning(): MediaCodec? = try {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        fmt.setInteger(MediaFormat.KEY_OPERATING_RATE, 30)
        fmt.setInteger(MediaFormat.KEY_PRIORITY, 0)
        // "latency" 即 MediaFormat.KEY_LATENCY，API 30 才有常量；用字符串避免低版本编译问题。
        runCatching { fmt.setInteger("latency", 1) }
        MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
            try {
                configure(fmt, surface, null, 0)
                start()
            } catch (e: Exception) {
                runCatching { release() }
                throw e
            }
        }.also {
            log("MediaRenderer: 低延迟参数已生效（operating-rate=30 priority=0）")
        }
    } catch (e: Exception) {
        log("MediaRenderer: 低延迟参数被解码器拒绝（${e.message}），回退默认配置")
        null
    }

    /** 原始配置（v0.10.61 行为），保证调优失败时解码器仍能起来。 */
    private fun createFallback(): MediaCodec? = try {
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
        // 不预置 csd-0/csd-1：引擎保证每个关键帧携带完整 SPS/PPS（Annex-B）。
        // 颜色格式由 Surface 决定（COLOR_FormatSurface）。
        MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
            configure(format, surface, null, 0)
            start()
        }
    } catch (e: Exception) {
        log("MediaRenderer: MediaCodec 初始化失败（${e.message}）——视频将黑屏")
        null
    }

    private var nullFrameCount = 0
    // v0.10.41: 重建次数限流——原实现 codecRef 恒 null 时每 10 帧重建一次、且
    // catch 里每帧都 requestKeyframeAndReset，解码器起不来就无限重建刷屏+抢关键帧。
    private var rebuildCount = 0

    private fun feed(key: Boolean, pts: Long, data: ByteArray) {
        val codec = codecRef.get() ?: run {
            // v0.10.40: 恢复路径——configureCodec 一次性失败后 codecRef 恒 null 会
            // 永久黑屏（此前无任何重建入口）。每 10 帧尝试一次重建（resetting 防重入）。
            nullFrameCount++
            if (nullFrameCount % 10 == 0) {
                if (rebuildCount >= 10) {
                    if (rebuildCount == 10) log("MediaRenderer: 重建失败 10 次——停用视频解码器重建（避免死循环）")
                    rebuildCount++
                    return
                }
                rebuildCount++
                log("MediaRenderer: 解码器缺失，尝试重建（第 $nullFrameCount 帧，重建#$rebuildCount）")
                requestKeyframeAndReset()
            }
            return
        }
        try {
            // v0.10.74: 10ms 太长——30fps 每帧预算 33ms，一次 dequeueInputBuffer 阻塞
            // 10ms 就吃掉近 1/3 帧预算，积压时表现为滑动跟不上手指。
            val index = codec.dequeueInputBuffer(2_000)
            if (index >= 0) {
                val buffer = codec.getInputBuffer(index) ?: return
                buffer.clear()
                buffer.put(data)
                val flags = if (key) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                codec.queueInputBuffer(index, 0, data.size, pts, flags)
            }
            drain(codec)
        } catch (e: Exception) {
            // 解码器异常（格式变化/驱动问题）→ 请求关键帧并重启解码器。
            // v0.10.41: 限流——异常连续 11 次多为「输入格式与解码器不匹配」的死循环，
            // 无限重建只会刷屏并反复抢关键帧，与音频侧 restartCount 同策略。
            rebuildCount++
            if (rebuildCount <= 10) {
                requestKeyframeAndReset()
            } else if (rebuildCount == 11) {
                log("MediaRenderer: 解码异常连续 11 次（${e.javaClass.simpleName}: ${e.message}）——停用重建")
            }
        }
    }

    private fun drain(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var frames = 0
        while (true) {
            when (val index = codec.dequeueOutputBuffer(info, 0)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> break
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // v0.10.45: 打印真实解码尺寸——配 800×480 Surface 时若手机实际推
                    // 更高分辨率（或更低），画面会被拉伸/压缩，是「画质差」的首要判据。
                    runCatching {
                        val f = codec.outputFormat
                        val w = f.getInteger(MediaFormat.KEY_WIDTH)
                        val h = f.getInteger(MediaFormat.KEY_HEIGHT)
                        log("MediaRenderer: 解码输出格式变更（${w}x$h）")
                        // v0.10.64: 把真实尺寸交出去——TextureView 默认把画面拉伸铺满，
                        // 车机屏是超宽比例而手机推的是 16:9，横向会被拉长（字变宽变扁），
                        // 必须由渲染层按真实比例做变换。见 RenderActivity.applyVideoAspect。
                        onVideoSize?.invoke(w, h)
                    }
                }
                MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {}
                else -> {
                    if (info.size > 0) framesDecoded.incrementAndGet()
                    codec.releaseOutputBuffer(index, true) // 渲染到 Surface
                    frames++
                    // v0.10.47: 每帧都请求一次重绘，保证 TextureView 持续 updateTexImage
                    onFrameRendered?.invoke()
                    if (frames > 16) break // 防死循环
                }
            }
        }
    }

    private fun requestKeyframeAndReset() {
        if (!resetting.compareAndSet(false, true)) return
        try {
            runCatching { codecRef.get()?.stop() }
            runCatching { codecRef.get()?.release() }
            codecRef.set(null)
            HelloCarBridge.nativeSendInput(HelloCarBridge.INPUT_KEYFRAME, ByteArray(0))
            configureCodec()
        } finally {
            resetting.set(false)
        }
    }

    fun decodedFrames(): Long = framesDecoded.get()
}
