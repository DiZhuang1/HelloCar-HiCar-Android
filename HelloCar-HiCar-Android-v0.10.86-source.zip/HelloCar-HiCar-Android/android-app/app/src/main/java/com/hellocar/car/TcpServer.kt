package com.hellocar.car

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * TCP 会话服务端：监听 4005（Nearby/Resource）/ 4006（Data）/ 4007（Control）。
 *
 * 对应 backend.rs 的 listeners（base=4005, base+1, base+2）。认证通过后才 accept；
 * 连接建立后按通道类型开协议核通道并转发字节流：
 *   4005 → nativeOpenChannel(CH_NEARBY_TCP)
 *   4006 → nativeOpenChannel(CH_DATA)
 *   4007 → nativeOpenChannel(CH_CONTROL)（协议核产出 DMSDP OPTIONS 初始帧）
 *
 * peer IP 校验说明：Linux backend 校验对端 IP == 凭证 client_ip（防未认证连接）。
 * Android LocalOnlyHotspot 天然隔离外部网络（仅已连热点的手机可达），且 4005
 * 仅在 authenticated 后 accept —— 因此本实现只校验认证状态，不校验对端 IP
 * （HotspotManager.guessClientIp 的 client_ip 由 DHCP 决定，无法预先固定）。
 * 此为与 Linux 行为的差异点，真机验证时观察 4005/4006/4007 连接是否正常建立。
 */
class TcpServer(
    private val log: (String) -> Unit,
    private val isAuthenticated: () -> Boolean,
    private val openChannel: (kind: Int) -> Int,
    private val feedChannel: (id: Int, data: ByteArray) -> ByteArray,
    private val initialChannel: (id: Int) -> ByteArray,
    private val closeChannel: (id: Int) -> Unit,
    private val onConnectionState: (connected: Boolean, which: String) -> Unit,
    /** M2c：打开 4007 控制通道前回调（MainActivity 在此注入音频 UDP 端口）。 */
    private val onControlOpening: () -> Unit = {},
) {
    private val running = AtomicBoolean(false)
    private val servers = mutableListOf<ServerSocket>()
    private val sockets = mutableListOf<Socket>()
    private val controlChannelId = AtomicReference<Int>(-1)
    private val controlOutput = AtomicReference<OutputStream?>(null)
    /** v0.10.31 自检修复（A4）: 控制通道写锁——读循环回复与 MainActivity dmsdpHeartbeat
     * 共用同一把锁，防止双线程交错 write+flush 写半帧损坏 DMSDP 帧。 */
    private val controlWriteLock = Any()

    companion object {
        private const val BASE = 4005
    }

    fun start() {
        if (running.get()) return
        running.set(true)
        for (offset in 0..2) {
            try {
                // v0.10.38: 先无参构造再 bind——`ServerSocket(port)` 构造时已 bind，
                // 之后设 reuseAddress=true 无效（1111(23) 启动即 EADDRINUSE 的真根因：
                // 上次会话端口 TIME_WAIT，重开 bind 被拒）。reuseAddress 必须在 bind 前设。
                val server = ServerSocket()
                server.reuseAddress = true
                server.bind(java.net.InetSocketAddress(BASE + offset))
                servers.add(server)
                Thread { acceptLoop(server, offset) }.start()
            } catch (e: IOException) {
                log("TCP ${BASE + offset} 监听失败（端口被占用？）：${e.message}")
            }
        }
        if (servers.isEmpty()) {
            running.set(false)
            return
        }
        log("TCP 会话服务已监听：${servers.joinToString { it.localPort.toString() }}（认证通过后开放）")
    }

    private fun acceptLoop(server: ServerSocket, offset: Int) {
        while (running.get()) {
            val socket = try {
                server.accept()
            } catch (e: IOException) {
                if (running.get()) log("TCP ${server.localPort} accept 中断：${e.message}")
                break
            }
            if (!isAuthenticated()) {
                log("TCP ${server.localPort} 收到连接但未认证，拒绝")
                runCatching { socket.close() }
                continue
            }
            log("TCP ${server.localPort} 连接建立：${socket.inetAddress.hostAddress}")
            onConnectionState(true, "tcp:${server.localPort}")
            sockets.add(socket)
            Thread { handleConnection(socket, offset) }.start()
        }
    }

    private fun handleConnection(socket: Socket, offset: Int) {
        val kind = when (offset) {
            0 -> HelloCarBridge.CH_NEARBY_TCP
            1 -> HelloCarBridge.CH_DATA
            else -> HelloCarBridge.CH_CONTROL
        }
        if (kind == HelloCarBridge.CH_CONTROL) {
            // M2c：DMSDP speaker 协商前必须注入本地音频 UDP 端口。
            onControlOpening()
        }
        val channelId = openChannel(kind)
        if (channelId < 0) {
            log("TCP ${BASE + offset} 通道打开失败 rc=$channelId，关闭连接")
            runCatching { socket.close() }
            return
        }
        if (kind == HelloCarBridge.CH_CONTROL) {
            controlChannelId.set(channelId)
        }
        val initial = initialChannel(channelId)
        val input: InputStream
        val output: OutputStream
        try {
            input = socket.getInputStream()
            output = socket.getOutputStream()
            if (kind == HelloCarBridge.CH_CONTROL) controlOutput.set(output)
            if (initial.isNotEmpty()) {
                output.write(initial)
                output.flush()
            }
        } catch (e: IOException) {
            log("TCP ${BASE + offset} 流错误：${e.message}")
            closeChannel(channelId)
            runCatching { socket.close() }
            return
        }
        val buf = ByteArray(4096)
        try {
            while (running.get()) {
                val n = input.read(buf)
                if (n < 0) {
                    log("TCP ${BASE + offset} 连接 EOF")
                    break
                }
                if (n == 0) continue
                val reply = feedChannel(channelId, buf.copyOf(n))
                if (reply.isNotEmpty()) {
                    // v0.10.31 自检修复（A4）: 控制通道的读循环回复与 dmsdpHeartbeat
                    // 写同一 OutputStream，必须互斥——否则双线程交错 write+flush
                    // 可能写半帧，损坏 DMSDP 帧（帧是 4B 长度前缀+负载结构）。
                    if (kind == HelloCarBridge.CH_CONTROL) {
                        synchronized(controlWriteLock) {
                            output.write(reply)
                            output.flush()
                        }
                    } else {
                        output.write(reply)
                        output.flush()
                    }
                }
            }
        } catch (e: IOException) {
            log("TCP ${BASE + offset} 读取异常：${e.message}")
        } finally {
            closeChannel(channelId)
            if (kind == HelloCarBridge.CH_CONTROL) {
                controlChannelId.set(-1)
                controlOutput.set(null)
            }
            onConnectionState(false, "tcp:${BASE + offset}")
            runCatching { socket.close() }
            sockets.remove(socket)
        }
    }

    /** 当前控制通道 id（-1 表示无）。 */
    fun currentControlChannel(): Int = controlChannelId.get()

    /** 向 4007 控制通道写外部产生的字节（如 DMSDP 心跳帧）。 */
    fun sendControlBytes(bytes: ByteArray) {
        val out = controlOutput.get() ?: return
        try {
            // v0.10.31 自检修复（A4）: 与读循环回复共用 controlWriteLock，防交错写半帧。
            synchronized(controlWriteLock) {
                out.write(bytes)
                out.flush()
            }
        } catch (e: IOException) {
            log("控制通道写入失败：${e.message}")
        }
    }

    fun stop() {
        running.set(false)
        servers.forEach { runCatching { it.close() } }
        servers.clear()
        sockets.forEach { runCatching { it.close() } }
        sockets.clear()
        log("TCP 会话服务已停止")
    }
}
