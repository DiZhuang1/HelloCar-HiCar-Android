package com.hellocar.car

import java.net.DatagramSocket

/**
 * M2c 全局媒体状态：MainActivity 预绑定的音频 UDP socket 与手机 IP，
 * 供 RenderActivity 的 MediaSession 复用（Activity 间无法直接传 socket 对象）。
 */
object MediaGlobals {
    /** MainActivity 在打开 4007 前 bind 的音频 UDP socket（同时用于 nativeSetAudioPort 注入）。 */
    @Volatile
    var audioSocket: DatagramSocket? = null

    /** 手机在热点中的 IP（LocalOnlyHotspot DHCP 猜测值，见 HotspotManager.guessClientIp）。 */
    @Volatile
    var phoneIp: String = "192.168.43.2"

    /**
     * v0.10.21: DMSDP cmd101 下发的 HiSight RTSP 端口。
     * MainActivity 在 nativeStatus 检测到后写入；RenderActivity 的 MediaSession 直接读取。
     * （v0.10.20 实测：Intent extra 与 30s 轮询 nativeStatus 都拿不到，改用进程内全局最可靠。）
     */
    @Volatile
    var rtspPort: Int = -1

    /**
     * v0.10.23: MainActivity 在 rtsp_port 一出现即后台预连的 RTSP socket。
     * 手机在 cmd101 下发后 1~3s 内可能切媒体模式离开热点，预连抢时间窗；
     * MediaSession 优先复用此 socket，未连上再走自身 45s 重试。
     */
    @Volatile
    var preconnectedRtsp: java.net.Socket? = null

    /**
     * v0.10.25: MainActivity 预连成功后直接接管 RTSP 协商（打开 CH_SIGHT、
     * 发出 ANNOUNCE、启动读循环 feed）。投屏页 MediaSession 检测到已启动即跳过
     * 重复协商，只做媒体端口连接。避免依赖投屏页 Activity 生命周期导致
     * ANNOUNCE 迟迟不发、手机 10s 超时主动断开（1111(15)）。
     */
    @Volatile
    var rtspStarted: Boolean = false

    @Volatile
    var sightId: Int = -1

    @Volatile
    var rtspSocket: java.net.Socket? = null

    /**
     * v0.10.61: 当前协商的画面尺寸，由主界面设置面板写入，投屏页读取。
     *
     * 这里修的是一个真 bug：主界面允许把分辨率切到 1024×600 甚至 800×480，
     * 但 RenderActivity 的 setDefaultBufferSize 和 MediaRenderer 的 createVideoFormat
     * 原来写死 1280×720。用户在面板上换了档，手机就按新尺寸推流，解码器却仍按
     * 1280×720 配置 —— 结果要么被 MediaCodec 拒绝、要么画面被拉伸变形，而日志上
     * 什么异常都看不到。分辨率这个参数必须一处定义、三处共读。
     */
    @Volatile
    var videoW: Int = 1280

    @Volatile
    var videoH: Int = 720

    /**
     * v0.10.81: 视频通道彻底放弃时联动停音频。
     * 1111(49) 实测：视频三轮重连全失败、通道已关闭（"视频通道关闭（video=9）"），
     * 但音频 UDP 仍在收包、AudioPlayer 仍在解码播放——用户看到的是"画面没了声音还在响"。
     * 投屏页创建播放器时注册这个回调，MediaSession 在视频被动结束时调用。
     */
    @Volatile
    var audioStopper: (() -> Unit)? = null
}
