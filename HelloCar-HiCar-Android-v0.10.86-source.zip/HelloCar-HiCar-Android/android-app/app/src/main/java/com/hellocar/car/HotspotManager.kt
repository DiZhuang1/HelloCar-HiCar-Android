package com.hellocar.car

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * 本地热点管理器：认证通过后启动 LocalOnlyHotspot 并回填真实参数。
 *
 * 设计（移植设计 §2.5）：第三方 App 无法配置热点（SSID/密码/信道/子网随机），
 * 启动成功后读取 SoftApConfiguration/WifiConfiguration 得到 SSID 与密码；
 * 网关 IP 从热点网络接口地址读取；频点按信道查表（API 33+ getBand 仅给频段）。
 * 之后调用 nativeSetHotspotInfo 回填，ResourceManager 凭证即携带真实值。
 *
 * 待实测点：
 *  - 手机是否强校验凭证中的 5745MHz / 192.168.49.x / BSSID（R2/R4）
 *  - API 33+ NEARBY_WIFI_DEVICES 权限缺失时 getPassphrase() 抛异常
 *  - 车机 Wi-Fi 芯片 AP/STA 并发限制（R10）
 */
class HotspotManager(
    private val context: Context,
    private val log: (String) -> Unit,
    private val onHotspotInfo: (ssid: String, password: String, bssid: String, ownerIp: String, clientIp: String, frequency: Int, port: Int) -> Unit,
    private val onState: (started: Boolean, info: String) -> Unit,
) {
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    companion object {
        private const val BASE_PORT = 4005
    }

    fun start() {
        if (reservation != null) {
            log("热点已在运行，忽略重复启动")
            return
        }
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        // v0.10.73: WiFi 并发能力探测。LocalOnlyHotspot 是单射频语义——开 AP 必须断 STA，
        // 车机原来连的 WiFi 会被关掉（车机断网，导航路况/在线音乐/OTA 全失效）。
        // Android 11+ 若支持 STA+AP 并发，可让 AP 走 5GHz、STA 留 2.4GHz 共存。
        // 这里只读不写，把结论打进日志，供判断「能不能两全」还是「只能让车机走蜂窝」。
        runCatching {
            val cls = wifi.javaClass
            val staAp = cls.getMethod("isStaApConcurrencySupported").invoke(wifi) as? Boolean
            val softAp = cls.getMethod("isSoftApSupported").invoke(wifi) as? Boolean
            log("WiFi 并发能力：SDK=${Build.VERSION.SDK_INT} staApConcurrency=${staAp ?: "未知"} softApSupported=${softAp ?: "未知"}")
        }.onFailure { log("WiFi 并发能力探测失败（隐藏 API 被挡）：${it.message}") }
        val mainHandler = Handler(Looper.getMainLooper())
        val callback = object : WifiManager.LocalOnlyHotspotCallback() {
            override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                reservation = res
                log("LocalOnlyHotspot 已启动")
                onState(true, "hotspot_started")
                try {
                    readConfig(wifi, res)
                } catch (e: Exception) {
                    log("热点参数读取失败：${e.message}")
                }
            }

            override fun onStopped() {
                reservation = null
                log("LocalOnlyHotspot 已停止")
                onState(false, "hotspot_stopped")
            }

            override fun onFailed(code: Int) {
                reservation = null
                // 注：compileSdk 34 的 android.jar 为精简 stub，LOCAL_ONLY_HOTSPOT_REQUEST_FAILED_*
                // 常量不可见（javap 实测），用数字 + 通用文案兜底。
                val reason = when (code) {
                    1 -> "设备不支持 AP 模式（车机 Wi-Fi 芯片限制，R10）"
                    2 -> "热点被占用（其他应用/系统服务，如 CarLife）"
                    0 -> "通用失败（硬件/驱动）"
                    else -> "未知错误($code)"
                }
                log("LocalOnlyHotspot 启动失败：$reason")
                onState(false, "hotspot_failed:$code")
            }
        }
        try {
            wifi.startLocalOnlyHotspot(callback, mainHandler)
        } catch (e: SecurityException) {
            log("启动热点失败（缺 NEARBY_WIFI_DEVICES/CHANGE_WIFI_STATE 权限）：${e.message}")
        } catch (e: Exception) {
            log("启动热点异常：${e.message}")
        }
    }

    private fun readConfig(wifi: WifiManager, res: WifiManager.LocalOnlyHotspotReservation) {
        var ssid: String? = null
        var password: String? = null
        if (Build.VERSION.SDK_INT >= 30) {
            val config = res.softApConfiguration
            ssid = config.ssid
            password = runCatching { config.passphrase }.getOrElse {
                log("读取热点密码失败（Android 13+ 需 NEARBY_WIFI_DEVICES 权限）：${it.message}")
                null
            }
        } else {
            // API 26-29：WifiConfiguration 带引号
            val cfg = res.wifiConfiguration
            ssid = cfg?.SSID?.trim('"')
            password = cfg?.preSharedKey?.trim('"')
        }
        if (ssid.isNullOrEmpty() || password.isNullOrEmpty()) {
            log("热点 SSID/密码为空——无法回填，凭证将使用占位值")
            return
        }
        // 频点：compileSdk 34 的 android.jar 为精简 stub（无 getBand/getChannel，javap 实测），
        // 无法读取真实信道/频段 —— 保持与协议核 placeholder 一致的 5745MHz。
        // 待实测：手机是否强校验凭证中的 5745MHz 字段（R2）。
        val frequency = 5745
        // 网关 IP：遍历网络接口找热点网段（192.168.x.1）
        val ownerIp = findHotspotGatewayIp() ?: "192.168.43.1"
        val clientIp = guessClientIp(ownerIp)
        // v0.10.10：BSSID 用热点网络接口的真实 MAC（LocalOnlyHotspot 软 AP 的 BSSID = 接口 MAC）。
        // 此前回填占位 02:00:00:00:00:00，手机按凭证 BSSID 匹配热点失败（转圈不连热点）。
        val bssid = findHotspotBssid() ?: "02:00:00:00:00:00"
        log("热点参数：ssid=$ssid bssid=$bssid password=$password freq=${frequency}MHz owner=$ownerIp client=$clientIp")
        onHotspotInfo(ssid, password, bssid, ownerIp, clientIp, frequency, BASE_PORT)
    }

    /** 遍历 NetworkInterface 找本地热点网关（形如 192.168.x.1 的 IPv4）。 */
    private fun findHotspotGatewayIp(): String? {
        return runCatching {
            java.net.NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .mapNotNull { it as? java.net.Inet4Address }
                .map { it.hostAddress }
                .firstOrNull { addr ->
                    addr.startsWith("192.168.") && addr.endsWith(".1") &&
                        addr != "192.168.1.1" // 排除常见家用路由器网关
                }
        }.getOrNull()
    }

    /**
     * v0.10.10：热点接口真实 MAC（LocalOnlyHotspot 软 AP 的 BSSID）。
     * 复用网关探测逻辑——拥有 192.168.x.1 地址的接口即热点接口，其 hardwareAddress 即 BSSID。
     */
    private fun findHotspotBssid(): String? {
        return runCatching {
            java.net.NetworkInterface.getNetworkInterfaces().toList()
                .firstOrNull { ni ->
                    ni.inetAddresses.toList().any { it is java.net.Inet4Address &&
                        it.hostAddress.startsWith("192.168.") && it.hostAddress.endsWith(".1") &&
                        it.hostAddress != "192.168.1.1" }
                }
                ?.hardwareAddress
                ?.joinToString(":") { String.format("%02x", it) }
        }.getOrNull()
    }

    private fun guessClientIp(owner: String): String {
        // LocalOnlyHotspot DHCP 通常从 .2 起分配；手机实际 IP 由 DHCP 决定。
        // Android 侧 TCP 4005/4006/4007 不做 peer IP 校验（见 TcpServer 注释），
        // 该值仅用于凭证字符串与 device_info 展示 —— 待实测手机是否按此值配置自身。
        return runCatching {
            val octets = owner.split(".")
            if (octets.size == 4) "${octets[0]}.${octets[1]}.${octets[2]}.2" else "192.168.43.2"
        }.getOrDefault("192.168.43.2")
    }

    fun stop() {
        reservation?.close()
        reservation = null
        log("热点已关闭")
    }
}
