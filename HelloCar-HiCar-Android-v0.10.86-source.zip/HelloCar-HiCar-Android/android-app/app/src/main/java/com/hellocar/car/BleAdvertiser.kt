package com.hellocar.car

import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.os.ParcelUuid
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * BLE 广播器：按 HiCar 发现层格式发布 FDEE ServiceData 广播。
 *
 * 载荷格式（HiCar 协议解析.md §1.1，radio.rs:38）：
 *   ServiceData[FDEE] = [1,1,1,3, b0,b1,b2, 4, b3, 16, sequence]  （11 字节）
 *   b0..b3 = model（8 位 hex）解码的 4 字节；sequence 每次广播自增。
 *
 * v0.8.0：修复 seq 恒为 1 的问题 —— 原实现（radio.rs/backend.rs）中 seq 是防重放
 * 计数器、每次广播自增；Android 的 startAdvertising 一旦启动广播载荷固定，无法在
 * 单个会话内改 seq，因此改为每 ADV_REFRESH_MS 重启一次广播并递增 seq，模拟原实现
 * "每次广播自增"行为。华为官方要求广播事件为 ADV_IND（可连接非定向），
 * setConnectable(true) 已满足。
 *
 * LocalName：Android 第三方应用无法改写蓝牙适配器名，setIncludeDeviceName(true)
 * 会带上系统设备名而非 "HelloCar" —— 发现以 FDEE ServiceData 为准，显示名差异为
 * 已知限制（待实测 MagicOS 11 是否以 LocalName 匹配）。
 */
class BleAdvertiser(private val adapter: BluetoothAdapter, private val model: String) {

    private var advertiser: BluetoothLeAdvertiser? = null
    private var scheduler: ScheduledExecutorService? = null
    private val sequence = AtomicInteger(1)
    private val failCount = AtomicInteger(0)
    @Volatile private var running = false

    companion object {
        /** FDEE 128-bit UUID（HiCar Nearby 服务）。 */
        val FDEE = ParcelUuid.fromString("0000fdee-0000-1000-8000-00805f9b34fb")
        /** 广播周期刷新间隔：每 3s 重启广播并递增 seq。
         *  v0.8.0 用 2s；v0.9.0 放宽到 3s —— 比亚迪车机蓝牙栈对频繁 stop/start 较敏感，
         *  2s 周期在实车上曾出现"广播启动失败/栈不稳定"（与 v0.8.1 手机不再弹窗高度相关）。 */
        private const val ADV_REFRESH_MS = 3000L
        /** 连续失败超过该次数后重建广播器（栈句柄可能失效，自愈）。 */
        private const val MAX_CONSECUTIVE_FAILS = 5
    }

    /** 按 model 构造 11 字节 beacon 载荷。model 必须是 8 位 hex。 */
    fun buildBeacon(model: String, seq: Int): ByteArray? {
        if (model.length != 8 || !model.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
        val raw = (0 until 8 step 2).map { model.substring(it, it + 2).toInt(16).toByte() }
        return byteArrayOf(
            1, 1, 1, 3,
            raw[0], raw[1], raw[2],
            4, raw[3],
            16, (seq and 0xFF).toByte(),
        )
    }

    fun start(onLog: (String) -> Unit, onState: (Boolean, String) -> Unit) {
        stop()
        running = true
        val le = try {
            adapter.bluetoothLeAdvertiser
        } catch (e: SecurityException) {
            onLog("BLE 广播器访问被拒（缺 BLUETOOTH_ADVERTISE 权限）：${e.message}")
            onState(false, "ble_no_permission")
            return
        }
        if (le == null) {
            onLog("BLE 广播器不可用（车机蓝牙栈不支持/被占用）——回退：仅依赖 BR/EDR 配对发现")
            onState(false, "ble_unavailable")
            return
        }
        advertiser = le
        startAdvertisingOnce(le, onLog, onState, silent = false)

        // 周期重启广播，seq 递增（防重放；每次重启即一次新的广播包）
        scheduler = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleAtFixedRate({
                if (!running) return@scheduleAtFixedRate
                val adv = advertiser ?: return@scheduleAtFixedRate
                try {
                    // v0.9.0 自愈：若已连续失败超过阈值，先重建广播器句柄再重启
                    if (failCount.get() >= MAX_CONSECUTIVE_FAILS) {
                        onLog("BLE 广播连续失败 ${failCount.get()} 次，重建广播器并重启…")
                        val fresh = try { adapter.bluetoothLeAdvertiser } catch (e: SecurityException) { null }
                        if (fresh != null) {
                            advertiser = fresh
                            sequence.incrementAndGet()
                            failCount.set(0)
                            startAdvertisingOnce(fresh, onLog, onState, silent = false)
                            return@scheduleAtFixedRate
                        }
                    }
                    adv.stopAdvertising(object : AdvertiseCallback() {
                        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                            // stop 成功 → seq+1 再重新广播（防重放计数递增）
                            sequence.incrementAndGet()
                            failCount.set(0)
                            if (running) startAdvertisingOnce(le, onLog, onState, silent = true)
                        }

                        override fun onStartFailure(errorCode: Int) {
                            // 停止失败：直接重启（大概率是栈尚未释放，下一周期再试）
                            sequence.incrementAndGet()
                            if (running) startAdvertisingOnce(le, onLog, onState, silent = true)
                        }
                    })
                } catch (e: Exception) {
                    onLog("BLE 广播刷新异常：${e.javaClass.simpleName}: ${e.message}")
                }
            }, ADV_REFRESH_MS, ADV_REFRESH_MS, TimeUnit.MILLISECONDS)
        }
    }

    /** 启动一次广播。silent=true 时不重复输出"已启动"日志（避免每 2s 刷屏）。 */
    private fun startAdvertisingOnce(
        le: BluetoothLeAdvertiser,
        onLog: (String) -> Unit,
        onState: (Boolean, String) -> Unit,
        silent: Boolean,
    ) {
        val beacon = buildBeacon(model, sequence.get()) ?: run {
            onLog("model 非法，无法构造 beacon")
            onState(false, "bad_model")
            return
        }
        val data = AdvertiseData.Builder()
            // v0.8.0：ServiceData + ServiceUuid 双条目 + seq 周期递增
            // Android 会把 128-bit FDEE 优化成 16-bit 短 UUID 条目（2 字节），
            // 总载荷 = flags(3) + ServiceUuid 16bit(3) + ServiceData 16bit(2+11) ≈ 21 字节 < 31 ✓
            .addServiceUuid(FDEE)
            .addServiceData(FDEE, beacon)
            .build()
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(true)   // ADV_IND：HiCar 要求可连接非定向广播
            .build()
        try {
            le.startAdvertising(settings, data, null, object : AdvertiseCallback() {
                override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                    val s = sequence.get()
                    if (!silent) onLog("BLE 广播已启动（FDEE ServiceData，11 字节 beacon，seq=$s，ADV_IND 可连接）")
                    else if (s % 10 == 0) onLog("BLE 广播周期刷新：seq=$s（每3s递增，模拟原实现防重放）")
                    // v0.9.0：每次成功都回传状态，保证 UI 状态行持续显示"广播中"
                    onState(true, "ble_active")
                }

                override fun onStartFailure(errorCode: Int) {
                    // 注意：不置 advertiser=null —— 周期任务靠它重试；仅首次失败/每5次失败输出一次日志
                    val fails = failCount.incrementAndGet()
                    val reason = when (errorCode) {
                        AdvertiseCallback.ADVERTISE_FAILED_DATA_TOO_LARGE -> "数据超限"
                        AdvertiseCallback.ADVERTISE_FAILED_TOO_MANY_ADVERTISERS -> "广播者过多（蓝牙栈被占用）"
                        AdvertiseCallback.ADVERTISE_FAILED_ALREADY_STARTED -> "已启动"
                        AdvertiseCallback.ADVERTISE_FAILED_INTERNAL_ERROR -> "内部错误"
                        AdvertiseCallback.ADVERTISE_FAILED_FEATURE_UNSUPPORTED -> "该设备不支持此广播特性"
                        else -> "未知错误($errorCode)"
                    }
                    if (fails <= 1 || fails % 5 == 0) {
                        onLog("BLE 广播启动失败：$reason（已尝试 $fails 次，自动重试中）")
                    }
                    onState(false, "ble_failed:$errorCode")
                }
            })
        } catch (e: SecurityException) {
            onLog("BLE 广播启动被拒（缺 BLUETOOTH_ADVERTISE 权限）：${e.message}")
            onState(false, "ble_no_permission")
        } catch (e: Exception) {
            onLog("BLE 广播启动异常：${e.javaClass.simpleName}: ${e.message}")
            onState(false, "ble_exception")
        }
    }

    fun stop() {
        running = false
        scheduler?.shutdownNow()
        scheduler = null
        advertiser?.stopAdvertising(object : AdvertiseCallback() {})
        advertiser = null
    }

    fun bumpSequence() {
        sequence.incrementAndGet()
    }
}
