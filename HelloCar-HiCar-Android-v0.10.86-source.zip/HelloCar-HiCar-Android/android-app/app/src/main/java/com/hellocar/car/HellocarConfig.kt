package com.hellocar.car

import android.content.Context

/**
 * HelloCar 集中配置与扩展点（v0.10.61）。
 *
 * 为什么要有这个文件：这几十轮迭代下来，默认 model、热点网段、端口号、超时毫秒、
 * 画面尺寸、日志行数上限……散落在 MainActivity / MediaSession / RenderActivity /
 * RfcommServer / HotspotManager 里，改一个值要 grep 三个文件、还得担心漏改另一处。
 * 上一版分辨率从写死改成可调时就踩过这个坑（面板改了 1024×600，解码器仍按
 * 1280×720 配置）。所以把「会变的」和「约定」的东西收到这里：
 *   - 后续要新增功能，先在这里加开关/常量，再去实现，代码改动面可控；
 *   - 要和 Rust 侧对齐的值（分辨率/码率/帧率）只从 VideoProfile 出，一处定义三处共读。
 *
 * 注意：这里只放「跨文件共享」的常量和数据类。单个类内部只用一次的常量留在原处，
 * 不要把所有字面量都搬进来，否则反而增加阅读跳转。
 */
object HellocarConfig {

    // ---------------------------------------------------------------- 版本 --

    const val VERSION = "v0.10.86"

    // ------------------------------------------------------------ 身份默认 --

    const val DEFAULT_MODEL = "00040A00"
    const val DEFAULT_BT_MAC = "02:00:00:00:00:00"
    /** Nearby 协商 tag2（CCMP 版本）：实测必须回 2，回 4 手机只发 flags 帧即终止。 */
    const val DEFAULT_CCMP = 2
    /** Nearby 协商 tag6（加密偏好）：实测回 0 手机才推进 kind=2 业务端点。 */
    const val DEFAULT_ENC_PREF = 0
    /** FE36 业务端点 RFCOMM 信道兜底值（真实值靠反射读 mChannel 回填）。 */
    const val DEFAULT_BUSINESS_CHANNEL = 24

    // -------------------------------------------------------------- 热点 ==

    const val HOTSPOT_OWNER_IP = "192.168.43.1"
    const val HOTSPOT_CLIENT_IP = "192.168.43.2"
    const val HOTSPOT_FREQ_MHZ = 5745

    // -------------------------------------------------------- TCP 会话端口 --

    const val TCP_PORT_AUTH = 4005
    const val TCP_PORT_BUSINESS = 4006
    const val TCP_PORT_DATA = 4007

    // ------------------------------------------------------------ 画面参数 --

    /** 面板可选的三个档位。顺序即 UI 展示顺序。 */
    val RESOLUTIONS = listOf(800 to 480, 1024 to 600, 1280 to 720, 1920 to 1080)

    const val DEFAULT_VIDEO_W = 1280
    const val DEFAULT_VIDEO_H = 720
    // v0.10.77: 码率上调。1111(47) 实测声明 6Mbps 时手机只编到约 1Mbps，
    // 换页/滑动等大运动画面直接块效应（用户描述"彩色二维码"）。
    // 5GHz 直连带宽充裕，把声明值与 VBR 上限抬高，给手机更大编码预算。
    const val DEFAULT_BITRATE = 8_000_000
    const val MIN_BITRATE = 3_000_000
    const val MAX_BITRATE = 20_000_000
    const val DEFAULT_FPS = 30
    const val MIN_FPS = 15
    const val MAX_FPS = 30

    // ---------------------------------------------------------------- 超时 --
    // 统一单位毫秒。调时序只改这里，不要在调用点再写魔法数字。

    /** RTSP 预连接单次超时（手机在 cmd101 下发后 1~3s 会切媒体模式，窗口很短）。 */
    const val RTSP_CONNECT_TIMEOUT_MS = 2_000
    /** 视频流单轮重连次数上限。 */
    const val VIDEO_RECONNECT_ROUNDS = 3
    /** 视频连接超时。 */
    const val VIDEO_CONNECT_TIMEOUT_MS = 10_000
    /** 视频读 soTimeout：0 推流时 readFully 会永久阻塞，靠它触发 PLAY 重发。 */
    const val VIDEO_READ_TIMEOUT_MS = 5_000
    /** RFCOMM 读超时。 */
    const val RFCOMM_READ_TIMEOUT_MS = 5_000
    /** RTCP 保活周期（手机约 2s 判超时，1s 回一次 RR 留足余量）。 */
    const val RTCP_INTERVAL_MS = 1_000L
    /** 投屏页看门狗：从未出媒体时多久退出。 */
    const val WATCHDOG_NO_MEDIA_MS = 120_000L
    /** 投屏页看门狗：出过媒体后多久无新增就退出。 */
    const val WATCHDOG_IDLE_MS = 12_000L

    // ---------------------------------------------------------------- 日志 --

    /** 投屏页浮层保留行数。 */
    const val OVERLAY_LOG_LINES = 8
    /** 投屏页浮层刷新最小间隔（热路径日志 25 次/秒，不限速会把 UI 线程打满）。 */
    const val OVERLAY_REFRESH_INTERVAL_MS = 600L
    /** 投屏页日志批量落盘周期。 */
    const val MEDIA_LOG_FLUSH_INTERVAL_MS = 800L

    // ------------------------------------------------------------ 功能开关 --
    // 后续功能先在这里登记，实现时按开关分流，避免改主流程。

    object Feature {
        /** 语音助手：麦克风上行协议已通（v0.10.45 修好 Transport），缺 UI 与 ASR 接线。 */
        const val VOICE_ASSISTANT = false
        /** 方控键映射：方向盘按键 → HiCar key 事件（sendKey 已有 code 0~9 映射）。 */
        const val STEERING_KEY_MAP = false
        /** 触控板模式：车机屏当触控板，显示触点轨迹（对齐 CarPlay/CarWith 的手势模式）。 */
        const val TOUCHPAD_MODE = false
        /** 自适应码率：按 RTCP RR 的丢包/时延动态调 bitrate（当前固定值）。 */
        const val ADAPTIVE_BITRATE = false
        /** 多屏输出：副驾/后排屏独立协商（当前单屏）。 */
        const val MULTI_DISPLAY = false
        /** 自动重连：断开后无需手动点启动。 */
        const val AUTO_RECONNECT = false
        /** 深色主题：false 时用于强光环境的高对比浅色方案。 */
        const val DARK_THEME = true

        /**
         * v0.10.65: 扩展点真正可读。
         *
         * 上面这些常量只是"默认值"，原先没有任何地方读它们 —— 占位是死代码，
         * 加功能时仍要改代码。这里补一个读取入口：默认走常量，用户在设置页
         * 打开开关后走 SharedPreferences，功能接线处只需要写
         * `if (Feature.isEnabled(this, Feature.AUTO_RECONNECT)) { ... }`，
         * 不必再改签名或传布尔参数。
         */
        private const val PREF = "hellocar_feature"

        fun isEnabled(ctx: android.content.Context, key: String, default: Boolean = false): Boolean {
            val sp = ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE)
            return sp.getBoolean(key, default)
        }

        fun set(ctx: android.content.Context, key: String, on: Boolean) {
            ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE)
                .edit().putBoolean(key, on).apply()
        }
    }

    /**
     * v0.10.85: 显示布局参数。
     *
     * 车机底部那排常驻导航栏（返回/主页/多任务/空调/温度）是车厂自己画的窗口，
     * 不是 Android 的 navigation bar —— `applyImmersive()` 里的 SYSTEM_UI_FLAG 对它无效，
     * 它会实实在在地盖住 HiCar 画面底部（1111(50) 第二张实拍可见音乐卡的播放按钮被压住）。
     * 这里把「要给底栏留多高」做成可见参数，投屏页按它给 TextureView 加下边距。
     */
    object Display {
        private const val PREF = "hellocar_display"
        private const val KEY_NAV_INSET = "nav_inset_dp"

        /** 0 表示不留白（保持原来的全屏铺满）。上限 160dp，覆盖绝大多数车机底栏高度。 */
        const val MAX_NAV_INSET = 160

        fun navInsetDp(ctx: android.content.Context): Int =
            ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE)
                .getInt(KEY_NAV_INSET, 0).coerceIn(0, MAX_NAV_INSET)

        fun saveNavInset(ctx: android.content.Context, dp: Int) {
            ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE).edit()
                .putInt(KEY_NAV_INSET, dp.coerceIn(0, MAX_NAV_INSET)).apply()
        }
    }

    // -------------------------------------------------------- 连接参数对象 --

    /**
     * 身份与协商参数。原来这五个 EditText 摆在前台主界面，占掉整屏三分之一，
     * 而这些值在真机上基本一辈子不改。v0.10.64 移到设置页，主界面只留 PIN 与开关。
     */
    data class ConnConfig(
        val model: String = DEFAULT_MODEL,
        val btMac: String = DEFAULT_BT_MAC,
        val ccmpVersion: Int = DEFAULT_CCMP,
        val encPref: Int = DEFAULT_ENC_PREF,
        val businessChannel: Int = DEFAULT_BUSINESS_CHANNEL,
    ) {
        companion object {
            private const val PREF = "hellocar_conn"

            fun load(ctx: Context): ConnConfig {
                val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                return ConnConfig(
                    model = sp.getString("model", DEFAULT_MODEL)?.takeIf { it.isNotBlank() } ?: DEFAULT_MODEL,
                    btMac = sp.getString("btMac", DEFAULT_BT_MAC)?.takeIf { it.isNotBlank() } ?: DEFAULT_BT_MAC,
                    ccmpVersion = sp.getInt("ccmp", DEFAULT_CCMP),
                    encPref = sp.getInt("enc", DEFAULT_ENC_PREF),
                    businessChannel = sp.getInt("channel", DEFAULT_BUSINESS_CHANNEL),
                )
            }

            fun save(ctx: Context, c: ConnConfig) {
                ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putString("model", c.model)
                    .putString("btMac", c.btMac)
                    .putInt("ccmp", c.ccmpVersion)
                    .putInt("enc", c.encPref)
                    .putInt("channel", c.businessChannel)
                    .apply()
            }
        }
    }

    // -------------------------------------------------------- 画面参数对象 --

    /**
     * 一次"画面档位"的完整描述。这是 Kotlin 与 Rust 之间的唯一约定：
     * 分辨率/码率/帧率/GOP 只从这里出，[apply] 写进 Rust 原子量，
     * [applyToGlobals] 写进 MediaGlobals 供投屏页/解码器读取。
     *
     * 后续要加"自动/手动"两套档位、或按场景切换（导航/视频/游戏），
     * 都在这一层扩，不用碰协商和渲染代码。
     */
    data class VideoProfile(
        val w: Int,
        val h: Int,
        val bitrate: Int,
        val fps: Int,
        /** 0 表示跟随 fps（GOP = 1 秒关键帧间隔）。 */
        val gop: Int = 0,
    ) {
        val gopValue: Int get() = if (gop > 0) gop else fps
        val vbrMin: Int get() = bitrate / 2
        // v0.10.65 自检：码率滑到 15Mbps 时 bitrate*3/2 = 22.5M，超过了 nativeSetVideoParams
        // 的 20M 夹取上限，vbr-max 会被手机侧当作非法能力值忽略（甚至整体协商失败）。
        // 这里先夹到同一个上限，保证传下去的三元组自洽。
        val vbrMax: Int get() = minOf(bitrate * 3 / 2, MAX_BITRATE)
        val mbps: Double get() = bitrate / 1_000_000.0

        /** 写进 Rust 协商参数。返回 native 的 rc（-999 表示 JNI 未加载）。 */
        fun apply(): Int = runCatching {
            HelloCarBridge.nativeSetVideoParams(w, h, bitrate, vbrMin, vbrMax, fps, gopValue)
        }.getOrElse { -999 }

        /** 写进进程内媒体全局，投屏页与 MediaRenderer 读这组值定尺寸。 */
        fun applyToGlobals() {
            MediaGlobals.videoW = w
            MediaGlobals.videoH = h
        }

        fun describe(): String = "${w}×${h} ${String.format("%.1f", mbps)}Mbps ${fps}fps"

        companion object {
            val DEFAULT = VideoProfile(DEFAULT_VIDEO_W, DEFAULT_VIDEO_H, DEFAULT_BITRATE, DEFAULT_FPS)

            private const val PREF = "hellocar_video"

            fun load(ctx: Context): VideoProfile {
                val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                // v0.10.77: 一次性迁移旧码率。
                // 1111(47) 实测：声明 6Mbps 时手机实际只编到约 1Mbps（I 帧最大 3.2KB），
                // 滑动换页这类大运动画面直接糊成块效应。6Mbps 这个默认值来自更早版本，
                // 已经写进了 SharedPreferences，只改常量对装过旧版的机器无效，这里补一次迁移。
                if (!sp.getBoolean("bitrate_migrated_1077", false)) {
                    val cur = sp.getInt("bitrate", DEFAULT_BITRATE)
                    val ed = sp.edit().putBoolean("bitrate_migrated_1077", true)
                    if (cur <= 6_000_000) ed.putInt("bitrate", DEFAULT_BITRATE)
                    ed.apply()
                }
                // 夹取：SharedPreferences 里的值可能来自旧版本或被人为改坏，
                // 直接喂给 MediaFormat.createVideoFormat 时 0 或负数会让 MediaCodec 崩掉。
                // v0.10.80 自检：旧写法把 w/h 各自夹在 320..1920 / 240..1080，能拼出
                // 1920×720、800×1080 这种手机端不会接受的组合；而 RESOLUTIONS 这张表
                // 此前是死代码——设置页没有分辨率入口，全工程没人引用过它。
                // 这里改成"必须成对命中档位表"，非法组合回落到默认 1280×720。
                val rawW = sp.getInt("w", DEFAULT_VIDEO_W)
                val rawH = sp.getInt("h", DEFAULT_VIDEO_H)
                val (w, h) = if (RESOLUTIONS.any { it.first == rawW && it.second == rawH }) {
                    rawW to rawH
                } else {
                    DEFAULT_VIDEO_W to DEFAULT_VIDEO_H
                }
                val br = sp.getInt("bitrate", DEFAULT_BITRATE).coerceIn(MIN_BITRATE, MAX_BITRATE)
                val fps = sp.getInt("fps", DEFAULT_FPS).coerceIn(MIN_FPS, MAX_FPS)
                return VideoProfile(w, h, br, fps)
            }

            fun save(ctx: Context, p: VideoProfile) {
                ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                    .putInt("w", p.w).putInt("h", p.h)
                    .putInt("bitrate", p.bitrate).putInt("fps", p.fps)
                    .apply()
            }
        }
    }
}
