package com.hellocar.car

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread

/**
 * 音频播放器（M2c 下行）：引擎回调的 AAC-ADTS 帧 → MediaCodec 解码 → PCM → AudioTrack。
 *
 * 设计（移植设计 §2.7）：替代 live.rs 的 ffmpeg 子进程解码。
 *  - ADTS 帧直接提交 MediaCodec（"audio/mp4a-latm" 从 ADTS 头解析采样率/声道）；
 *  - 解码器输出 PCM 采样率/声道可能随源变化（44100/48000、1/2ch），输出格式变化时
 *    重建 AudioTrack（默认 44100/2，见 HiSight 能力协商 his_audio_codecs=1）；
 *  - 双流（speaker1/modemSpeaker）混合在引擎侧未做（Android 首版单流直通，M4 补 mix）；
 *  - 上行麦克风（AudioRecord→AAC→SSRC 1100）M2c 留占位，未实现。
 *
 * 线程模型：onAudio 由 JNI feed 调用线程（音频 UDP 线程）回调，经 HandlerThread 串行处理。
 */
class AudioPlayer(
    // v0.10.35: 取证日志回调——判断「引擎→AudioPlayer→MediaCodec→AudioTrack」
    // 哪环断（23 轮音频 1413 包无 reject 却 pcmBytes=0，断点不明）。
    private val log: (String) -> Unit = {},
) : HelloCarBridge.AudioSink {

    private val thread = HandlerThread("aac-play").apply { start() }
    private val handler = Handler(thread.looper)
    private val codecRef = java.util.concurrent.atomic.AtomicReference<MediaCodec?>(null)
    private val trackRef = java.util.concurrent.atomic.AtomicReference<AudioTrack?>(null)
    private val bytesWritten = java.util.concurrent.atomic.AtomicLong(0)
    private val onAudioCount = java.util.concurrent.atomic.AtomicLong(0)
    private val feedCount = java.util.concurrent.atomic.AtomicLong(0)
    private val decodedChunks = java.util.concurrent.atomic.AtomicLong(0)
    private val droppedChunks = java.util.concurrent.atomic.AtomicLong(0)

    /** 期望输出格式（对齐 1111(25) 实测解码输出：48000Hz stereo 4096B/chunk）。
     * v0.10.41: 原 44100 与解码 48000 错位——AudioTrack 以 44100 回放 48000 PCM
     * 相当于 1.088 倍速，正是「有声音但卡顿、音质差」的根因。 */
    private var expectedSampleRate = 48000
    private var expectedChannels = 2

    // v0.10.39: 从首帧 ADTS 头解析的真实流参数——1111(24) 实测 head=fff94c806b…
    // 解码为 MPEG-2 ADTS / AAC-LC / 48000Hz / 1ch，而旧 configure 固定 44100/2
    // 且无 csd-0、无 KEY_AAC_PROFILE——vendor 解码器参数不匹配时每次 feed 抛
    // IllegalStateException(null)（11 次重试全败、PCM 恒 0 的根因）。
    private var adtsParsed = false
    private var parsedRate = 0
    private var parsedChannels = 0
    private var parsedAsc: ByteArray? = null

    private companion object {
        val ADTS_RATES = intArrayOf(96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350)
    }

    /** 解析 ADTS 头 → (采样率Hz, 声道数, AudioSpecificConfig 2B)；非法返回 null。 */
    private fun parseAdts(data: ByteArray): Triple<Int, Int, ByteArray>? {
        if (data.size < 7) return null
        val b0 = data[0].toInt() and 0xFF
        val b1 = data[1].toInt() and 0xFF
        if (b0 != 0xFF || (b1 and 0xF0) != 0xF0) return null
        val profile = (data[2].toInt() ushr 6) and 0x03   // ADTS profile = audioObjectType-1
        val aot = profile + 1                              // 2 = AAC-LC
        val sfIndex = (data[2].toInt() ushr 2) and 0x0F
        if (sfIndex >= ADTS_RATES.size) return null
        val rate = ADTS_RATES[sfIndex]
        val chanCfg = ((data[2].toInt() and 0x01) shl 2) or ((data[3].toInt() ushr 6) and 0x03)
        val channels = if (chanCfg == 0) 2 else chanCfg
        // AudioSpecificConfig (2B): audioObjectType(5) | samplingFrequencyIndex(4) | channelConfiguration(4)
        // v0.10.41: channelConfiguration 固定写 2——1111(25) 实测 head=fff94c… 头声明 mono，
        // 但解码输出恒 4096B/chunk（1024×2ch×2B = stereo）：csd-0 若按头写 1 会与
        // configure(channels=2) 冲突（部分 vendor 解码器按 csd 输出 1ch，stereo PCM
        // 灌进 mono 轨道 = 音调变高/变快，正是「音质差」）。
        val asc = byteArrayOf(
            (((aot and 0x1F) shl 3) or (sfIndex ushr 1)).toByte(),
            (((sfIndex and 0x01) shl 7) or (2 shl 3)).toByte(),
        )
        return Triple(rate, channels, asc)
    }

    fun start() {
        handler.post {
            configureCodec()
            rebuildTrack(expectedSampleRate, expectedChannels)
        }
    }

    fun stop() {
        // v0.10.37: 会话结束重置异常计数——上一轮投屏的 feed 异常若不重置，
        // 新会话 configureCodec 也会被 restartCount>10 误停（音频永久静默）。
        restartCount = 0
        handler.post {
            runCatching { codecRef.get()?.stop() }
            runCatching { codecRef.get()?.release() }
            codecRef.set(null)
            runCatching { trackRef.get()?.stop() }
            runCatching { trackRef.get()?.release() }
            trackRef.set(null)
        }
        thread.quitSafely()
    }

    override fun onAudio(pts: Long, data: ByteArray) {
        val n = onAudioCount.incrementAndGet()
        if (n <= 3 || n % 100 == 0L) {
            log("AudioPlayer: onAudio 到达 $n（${data.size}B pts=$pts）")
        }
        handler.post { feed(data, pts) }
    }

    private fun configureCodec(sampleRate: Int = 48000, channels: Int = 2, asc: ByteArray? = null) {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels)
        // ADTS 流：解码器从帧头解析；部分解码器要求 is-adts=true。
        format.setInteger(MediaFormat.KEY_IS_ADTS, 1)
        // v0.10.39: vendor 解码器常要求显式 profile + csd-0（AudioSpecificConfig），
        // 缺省时 configure 成功但 queueInputBuffer 抛 IllegalStateException。
        format.setInteger(MediaFormat.KEY_AAC_PROFILE, android.media.MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        if (asc != null && asc.size >= 2) {
            format.setByteBuffer("csd-0", java.nio.ByteBuffer.wrap(asc))
        }
        val codec = try {
            MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
                configure(format, null, null, 0)
                start()
            }
        } catch (e: Exception) {
            log("AudioPlayer: MediaCodec 初始化失败（${e.message}）——音频将静默")
            return
        }
        codecRef.set(codec)
        // v0.10.36: 重启循环时不再刷"已就绪"——首次与重启均取证，但只有首次打
        // 完整日志（1111(35) 该行刷屏 30 次淹没音频证据）。
        if (restartCount == 0) log("AudioPlayer: MediaCodec 解码器已就绪（${sampleRate}Hz/${channels}ch, ADTS${if (asc != null) "+csd0" else ""}）")
    }

    private fun rebuildTrack(sampleRate: Int, channels: Int) {
        if (trackRef.get() != null) {
            runCatching { trackRef.get()?.stop() }
            runCatching { trackRef.get()?.release() }
            trackRef.set(null)
        }
        val channelMask = if (channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .build()
                )
                .setBufferSizeInBytes(sampleRate * channelCount(channels) * 2 * 5 / 10) // ~500ms，抗 UDP 突发欠载卡顿
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
                .apply { play() }
        } catch (e: Exception) {
            log("AudioPlayer: AudioTrack 创建失败（${e.message}）——PCM 无法播放")
            return
        }
        trackRef.set(track)
        log("AudioPlayer: AudioTrack 已就绪（${sampleRate}Hz/$channels ch）")
    }

    private fun channelCount(channels: Int): Int = if (channels == 1) 1 else 2

    // v0.10.36: 连续异常计数——>10 次停用解码器，防"feed 异常→重启→再异常"死循环刷屏
    private var restartCount = 0
    // v0.10.75: AudioTrack 写入失败计数——路由切换（360 影像）时设备会短暂失效
    private var writeFailCount = 0
    // v0.10.80: 音频焦点让路标志。车机切 360 全景/原车媒体会拿走焦点，
    // 这时继续往 AudioTrack 里塞数据等于和系统抢通道，通常被判成抢占并被长期压制。
    // 这里只做"暂停写入"，解码器照常跑，焦点回来从当前帧继续——不重建轨道、不丢解码状态。
    @Volatile private var focusSuppressed = false

    /** 焦点被其它应用接管：暂停写入并让出硬件通道，但不销毁轨道。 */
    fun onFocusLost() {
        focusSuppressed = true
        // AudioTrack 的方法不是线程安全的，而 drain 的 write 跑在 aac-play 线程上。
        // 主线程直接 pause 会和正在阻塞的 write 撞车（可能返回异常码或状态机错乱），
        // 必须投回同一个 Handler 串行执行。
        handler.post { runCatching { trackRef.get()?.pause() } }
    }

    /** 焦点归还：恢复写入，并清掉暂停期间残留的 buffer 尾部。 */
    fun onFocusGained() {
        focusSuppressed = false
        handler.post {
            runCatching { trackRef.get()?.flush() }
            runCatching { trackRef.get()?.play() }
        }
    }

    private fun feed(data: ByteArray, pts: Long) {
        // v0.10.39: 首帧按 ADTS 头校准解码器/轨道——流声明 48000/1，而初始
        // configure 是 44100/2，vendor 解码器会拒收参数不匹配的帧。
        if (!adtsParsed) {
            val p = parseAdts(data)
            if (p != null) {
                adtsParsed = true
                parsedRate = p.first
                parsedChannels = p.second
                parsedAsc = p.third
                // v0.10.40: 同步期望格式——drain 的 INFO_OUTPUT_FORMAT_CHANGED 若按
                // 旧 44100/2 比较会做一次无意义重建（抖动）。
                expectedSampleRate = p.first
                expectedChannels = p.second
                log("AudioPlayer: ADTS 头 ${p.first}Hz/${p.second}ch asc=${p.third.joinToString("") { "%02x".format(it.toInt() and 0xFF) }}——按流参数重建解码器/轨道")
                runCatching { codecRef.get()?.stop() }
                runCatching { codecRef.get()?.release() }
                codecRef.set(null)
                restartCount = 0
                // v0.10.41: 声道固定 2——1111(25) 实测解码输出 4096B/chunk
                // （1024 samples × 2ch × 2B），ADTS 头 chanCfg=1 与手机实际混音
                // 不符；按头重建 1ch 轨道会导致 stereo PCM 按 mono 解释（音质崩）。
                configureCodec(p.first, 2, p.third)
                rebuildTrack(p.first, 2)
            }
        }
        val codec = codecRef.get() ?: run {
            val n = feedCount.incrementAndGet()
            if (n <= 3 || n % 100 == 0L) log("AudioPlayer: 解码器未就绪，ADTS 丢弃 $n")
            // v0.10.40: 恢复路径——configureCodec 一次性失败后 codecRef 恒 null 会
            // 永久丢帧（无任何重建入口）。每 10 次丢包尝试一次按真实流参数重建，
            // restartCount 限流防死循环刷屏。
            if (parsedRate > 0 && n % 10 == 0L) {
                restartCount++
                if (restartCount > 10) {
                    log("AudioPlayer: 重建失败 $restartCount 次——停用音频解码器（避免死循环）")
                } else {
                    configureCodec(parsedRate, 2, parsedAsc)
                }
            }
            return
        }
        val n = feedCount.incrementAndGet()
        if (n <= 3 || n % 100 == 0L) log("AudioPlayer: feed ADTS $n（${data.size}B pts=$pts）")
        try {
            // v0.10.75: 10ms 对 20ms/帧的音频流占比过半，缩到 2ms 让出时间给 drain。
            val index = codec.dequeueInputBuffer(2_000)
            if (index >= 0) {
                val buffer = codec.getInputBuffer(index)
                if (buffer == null) {
                    log("AudioPlayer: getInputBuffer($index) 返回 null——重启 codec")
                    restartCodec()
                    return
                }
                // v0.10.36: 输入缓冲容量取证——ADTS 帧超过 capacity 即 BufferOverflow 根因
                if (data.size > buffer.capacity()) {
                    log("AudioPlayer: ADTS ${data.size}B 超过输入缓冲 ${buffer.capacity()}B！")
                }
                buffer.clear()
                buffer.put(data)
                // v0.10.36: pts 用引擎递增时间戳（此前恒 0，部分 codec 对 pts 要求递增）
                codec.queueInputBuffer(index, 0, data.size, pts, 0)
            }
            drain(codec)
        } catch (e: Exception) {
            // v0.10.36: 异常详情取证——1111(35) 该 catch 静默重启 30 次，失败点完全不可见
            restartCount++
            val head = data.take(8).joinToString("") { "%02x".format(it.toInt() and 0xFF) }
            log("AudioPlayer: feed 异常 ${e.javaClass.simpleName}: ${e.message}（head=$head 重试#$restartCount）")
            restartCodec()
        }
    }

    private fun restartCodec() {
        val codec = codecRef.get()
        runCatching { codec?.stop() }
        runCatching { codec?.release() }
        codecRef.set(null)
        if (restartCount > 10) {
            log("AudioPlayer: 连续异常 $restartCount 次——停用音频解码器（避免死循环）")
            return
        }
        // v0.10.39: 重启沿用首帧解析出的真实流参数（不再回落到 44100/2 不匹配组合）。
        if (parsedRate > 0) configureCodec(parsedRate, 2, parsedAsc) else configureCodec()
    }

    private fun drain(codec: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var chunks = 0
        while (true) {
            when (val index = codec.dequeueOutputBuffer(info, 0)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> break
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val fmt = codec.outputFormat
                    val rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    // v0.10.41: 声道恒取 2——vendor 按 csd-0/ADTS 头可能上报 1ch，
                    // 但实测每 chunk 4096B（1024 帧 × 2ch × 2B）恒 stereo；按上报的
                    // 1ch 重建轨道会让 stereo PCM 被当 mono 播放（音质崩/卡顿）。
                    val ch = 2
                    if (rate != expectedSampleRate || ch != expectedChannels) {
                        expectedSampleRate = rate
                        expectedChannels = ch
                        rebuildTrack(rate, ch)
                    }
                }
                MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {}
                else -> {
                    val buffer = codec.getOutputBuffer(index)
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        val pcm = ByteArray(info.size)
                        buffer.get(pcm)
                        val track = trackRef.get()
                        if (track == null) {
                            val d = droppedChunks.incrementAndGet()
                            if (d <= 3 || d % 100 == 0L) log("AudioPlayer: 轨道未就绪，PCM 丢弃 $d（${pcm.size}B）")
                        } else {
                            // v0.10.77: 恢复播放前必须 flush。
                            // 1111(47) 用户报"连接后声音有时加快播放"：旧逻辑只 play() 复原，
                            // 而 pause 之前写进 buffer 的残留 PCM 还在，恢复后先把这批旧数据
                            // 放一遍，再叠上新到达的数据 —— 听感就是忽快忽慢/重复。
                            // flush 清空未播放残留，恢复后从当前这帧重新计时。
                            if (focusSuppressed) {
                                // v0.10.80: 焦点被系统拿走（360 全景/原车媒体），本帧直接丢。
                                // 不重建轨道、不动解码器，焦点回来继续从当前帧写。
                                val d = droppedChunks.incrementAndGet()
                                if (d <= 3 || d % 100 == 0L) log("AudioPlayer: 焦点让路，PCM 暂停 $d（${pcm.size}B）")
                            } else if (track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                                runCatching { track.flush() }
                                runCatching { track.play() }
                            }
                            if (!focusSuppressed && track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                                // v0.10.77: 阻塞模式也可能只写进去一部分（buffer 将满/路由抖动），
                                // 旧逻辑丢弃剩余部分会让音频"跳帧加速"。这里写入直到写完。
                                var offset = 0
                                var written = 0
                                while (offset < pcm.size) {
                                    val w = track.write(pcm, offset, pcm.size - offset)
                                    // v0.10.79: 三种返回值要分开处理。
                                    // 旧写法把 w==0 也归进 w<=0 并 written=w，等于把已经写进去的
                                    // offset 字节从统计里抹掉；而且 w==0 并不是失败（MODE_STREAM
                                    // 在 buffer 临界时可能返回 0），走失败分支去重建 AudioTrack 是错的。
                                    if (w < 0) { written = w; break }
                                    if (w == 0) { written = offset; break }
                                    offset += w
                                    written = offset
                                }
                                if (written < 0) {
                                    writeFailCount++
                                    if (writeFailCount <= 3 || writeFailCount % 20 == 0) {
                                        log("AudioPlayer: AudioTrack 写入失败 code=$written（第 $writeFailCount 次）")
                                    }
                                    if (writeFailCount <= 3) {
                                        log("AudioPlayer: 重建 AudioTrack（路由已变更）")
                                        runCatching { trackRef.set(null) }
                                        runCatching { track.pause() }
                                        runCatching { track.flush() }
                                        runCatching { track.release() }
                                        rebuildTrack(expectedSampleRate, expectedChannels)
                                    }
                                } else {
                                    writeFailCount = 0
                                    if (written != pcm.size) {
                                        val d = droppedChunks.incrementAndGet()
                                        if (d <= 3 || d % 100 == 0L) log("AudioPlayer: PCM 部分写入 $written/${pcm.size}B（第 $d 次）")
                                    }
                                    bytesWritten.addAndGet(written.toLong())
                                    val out = decodedChunks.incrementAndGet()
                                    if (out <= 3 || out % 100 == 0L) log("AudioPlayer: 解码输出 $out（${pcm.size}B，累计 ${bytesWritten.get()}B）")
                                }
                            } else {
                                val d = droppedChunks.incrementAndGet()
                                if (d <= 3 || d % 100 == 0L) log("AudioPlayer: 轨道未就绪/未播放，PCM 丢弃 $d（${pcm.size}B）")
                            }
                        }
                    }
                    codec.releaseOutputBuffer(index, false)
                    chunks++
                    if (chunks > 32) break
                }
            }
        }
    }

    fun pcmBytes(): Long = bytesWritten.get()
}
