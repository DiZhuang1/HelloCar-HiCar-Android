plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hellocar.car"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hellocar.car"
        // minSdk 24：与 libhellocar_android.so 的编译平台 aarch64-linux-android24 对齐
        minSdk = 24
        // targetSdk 28：规避车机 ROM（比亚迪 DiLink）运行时权限弹窗兼容问题。
        // Android 12+ 车机上 BLUETOOTH_SCAN/CONNECT/ADVERTISE 对 targetSdk<=30 自动授予；
        // Android 10/11 车机走 BLUETOOTH/BLUETOOTH_ADMIN 旧权限（normal 级，安装即授予）。
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"

        // 仅打包 arm64-v8a（目标车机骁龙8155；jniLibs 目录也只有 arm64-v8a）
        ndk {
            abiFilters.add("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
