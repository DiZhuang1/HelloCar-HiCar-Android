//! Stateful encrypted HiSight RTSP. Network/media IO stays in the adapter.
use super::{Result,crypto::{Crypto,wipe},wire::Messages,hex,unhex};
use serde_json::{Value,json};
use std::{collections::BTreeMap,io::Read,sync::atomic::{AtomicU32,Ordering}};

/// v0.10.61：画面参数参数化。
/// 这些值原来写死在 GET_PARAMETER 的能力表字符串里，改一次分辨率就得重编 .so、重发一个包，
/// 车机上根本没法调。改成进程内原子量后，设置面板可以实时改协商参数：能力表用 format! 现拼，
/// 触摸坐标换算（android_engine.rs）和 media::touch 的边界校验读同一组值，只改一处。
pub static VIDEO_W:AtomicU32=AtomicU32::new(1280);
pub static VIDEO_H:AtomicU32=AtomicU32::new(720);
pub static VIDEO_BITRATE:AtomicU32=AtomicU32::new(8_000_000);
pub static VIDEO_VBR_MIN:AtomicU32=AtomicU32::new(4_000_000);
pub static VIDEO_VBR_MAX:AtomicU32=AtomicU32::new(20_000_000);
pub static VIDEO_FPS:AtomicU32=AtomicU32::new(30);
pub static VIDEO_GOP:AtomicU32=AtomicU32::new(30);

const LIMIT:usize=65000;
fn sequence(s:&str)->Result<()>{if s.is_empty()||s.len()>9||!s.bytes().all(|b|b.is_ascii_digit()){Err("invalid HiSight sequence".into())}else{Ok(())}}
fn message(start:&str,seq:&str,body:&[u8],headers:&[(&str,String)])->Result<Vec<u8>>{
    sequence(seq)?;let mut out=format!("{start}\r\nCSeq: {seq}\r\n");
    for (name,value) in headers{if !value.is_ascii()||value.bytes().any(|b|matches!(b,0|10|13)){return Err("invalid HiSight header".into());}out.push_str(&format!("{name}: {value}\r\n"));}
    if !body.is_empty(){out.push_str(&format!("Content-Type: text/parameters\r\nContent-Length: {}\r\n",body.len()));}
    out.push_str("\r\n");let mut bytes=out.into_bytes();bytes.extend(body);Ok(bytes)
}
fn metadata(m:&super::wire::Message)->Value{
    let mut out=json!({"method":m.start.split(' ').next().unwrap_or(""),"header_names":m.headers.keys().collect::<Vec<_>>(),"body_bytes":m.body.len()});
    for name in ["cseq","cryptover","cryptoability","cryptoswitch","udpka","lowdelay"]{
        if let Some(v)=m.headers.get(name).filter(|v|sequence(v).is_ok()){out[name]=v.parse::<u32>().unwrap().into();}
    }out
}
fn record_message(payload:&[u8])->Result<super::wire::Message>{
    let split=payload.windows(4).position(|p|p==b"\r\n\r\n");
    let (head,body)=match split{Some(n)=>(&payload[..n],&payload[n+4..]),None=>{
        let mut end=payload.len();while end>0&&matches!(payload[end-1],b'\r'|b'\n'){end-=1;}(&payload[..end],&[][..])
    }};
    if head.len()>8192||!head.is_ascii(){return Err("invalid HiSight header".into());}
    // The observed source omits ANNOUNCE Content-Length and miscounts SETUP
    // Transport as body. Only this explicitly length-delimited protocol uses
    // the outer record's body boundary; DMSDP retains strict Content-Length.
    let text=std::str::from_utf8(head).map_err(|_|"invalid HiSight text")?;
    let mut normalized=String::new();
    for row in text.split("\r\n").filter(|s|!s.is_empty()&&!s.to_ascii_lowercase().starts_with("content-length:")){normalized.push_str(row);normalized.push_str("\r\n");}
    normalized.push_str(&format!("Content-Length: {}\r\n\r\n",body.len()));
    let mut bytes=normalized.into_bytes();bytes.extend(body);let mut parser=Messages::new("RTSP");
    let mut messages=parser.feed(&bytes)?;parser.finish()?;
    if messages.len()!=1{return Err("invalid HiSight message count".into());}Ok(messages.remove(0))
}
fn port(transport:&str,name:&str)->Option<u16>{transport.split(';').find_map(|field|{
    let (key,value)=field.split_once('=')?;
    if key!=name||value.is_empty()||!value.bytes().all(|b|b.is_ascii_digit()){return None;}
    value.parse::<u16>().ok().filter(|p|*p!=0)
})}

pub struct Session{
    key:Vec<u8>,crypto:Crypto,buffer:Vec<u8>,failed:bool,pending:Vec<Vec<u8>>,
    encrypted:bool,options_sent:bool,target:String,peer_url:Option<String>,sequence:u32,setup:Option<u32>,play:Option<u32>,
    media:Option<u16>,input:Option<u16>,rtcp:Option<u16>,setup_ok:bool,peer_teardown:bool,teardown:Option<u32>,acknowledged:bool,
}
impl Drop for Session{fn drop(&mut self){wipe(&mut self.key);wipe(&mut self.buffer);}}
impl Session{
    pub fn new(key:&[u8])->Result<Self>{
        if !matches!(key.len(),16|32){return Err("invalid authenticated HiSight key".into());}
        Ok(Self{key:key[..16].to_vec(),crypto:Crypto::load()?,buffer:vec![],failed:false,pending:vec![],encrypted:false,options_sent:false,target:"*".into(),peer_url:None,sequence:2,setup:None,play:None,media:None,input:None,rtcp:None,setup_ok:false,peer_teardown:false,teardown:None,acknowledged:false})
    }
    fn pack(&self,data:&[u8],plain:bool)->Result<Vec<u8>>{
        if self.failed{return Err("HiSight session requires reset".into());}
        let payload=if self.encrypted&&!plain{
            let mut iv=[0u8;16];std::fs::File::open("/dev/urandom").and_then(|mut f|f.read_exact(&mut iv)).map_err(|_|"cannot obtain HiSight IV")?;
            let mut payload=iv.to_vec();payload.extend(self.crypto.transform(&self.key,&iv,data)?);payload
        }else{data.to_vec()};
        if payload.is_empty()||payload.len()>LIMIT{return Err("HiSight record exceeds limit".into());}
        let mut out=(payload.len() as u32).to_be_bytes().to_vec();out.extend(payload);Ok(out)
    }
    pub fn initial(&self)->Result<Vec<u8>>{self.pack(&message("ANNOUNCE * RTSP/1.0","1",b"encrypt_description: encrypt_list=aes128ctr;version=1\r\n",&[])?,true)}
    /// v0.10.27: 废弃——1111(18) 实测荣耀手机在 ANNOUNCE 后回明文 200/ANNOUNCE/
    /// SET_PARAMETER，加密切换点晚于参考脚本假设；提前置位会把明文当密文解密。
    /// 加密切换已由 receive 自适应维护（先试明文、失败再解密并置位），引擎不再调用。
    pub fn activate(&mut self){self.encrypted=true;}
    fn queue(&mut self,data:Vec<u8>,plain:bool)->Result<()>{
        if self.pending.len()>=64{return Err("HiSight response queue exceeds limit".into());}
        self.pending.push(self.pack(&data,plain)?);Ok(())
    }
    pub fn request(&mut self,method:&str)->Result<u32>{
        // v0.10.27: 去掉 !encrypted 要求——明文态也可发 SETUP/PLAY，打包自动跟随
        // 当前态（encrypted=false 走明文、true 走密文），无需前置条件。
        if self.peer_teardown||!matches!(method,"SETUP"|"PLAY"){return Err("invalid HiSight request state".into());}
        self.sequence=self.sequence.checked_add(1).filter(|n|*n<=999999999).ok_or("HiSight sequence exhausted")?;
        self.queue(message(&format!("{method} {} RTSP/1.0",self.target),&self.sequence.to_string(),&[],&[("Transport","RTP/AVP/UDP;unicast;client_port=0".into())])?,false)?;
        // v0.10.32: 记录 PLAY 序号供 receive 匹配 PLAY 200（H1 取证：手机是否接受 PLAY）。
        if method=="PLAY"{self.play=Some(self.sequence);}
        Ok(self.sequence)
    }
    pub fn teardown(&mut self)->Result<Option<Vec<u8>>>{
        if !self.encrypted||self.media.is_none()||self.peer_teardown||self.teardown.is_some()||self.failed{return Ok(None);}
        self.sequence=self.sequence.checked_add(1).filter(|n|*n<=999999999).ok_or("HiSight sequence exhausted")?;
        self.teardown=Some(self.sequence);self.pack(&message(&format!("TEARDOWN {} RTSP/1.0",self.target),&self.sequence.to_string(),&[],&[])?,false).map(Some)
    }
    pub fn state(&self)->Value{json!({"encrypted":self.encrypted,"setup_ok":self.setup_ok,"media_endpoint":self.media,"input_endpoint":self.input,"rtcp_endpoint":self.rtcp,"setup_sequence":self.setup,"peer_teardown":self.peer_teardown,"teardown_acknowledged":self.acknowledged})}

    /// v0.10.72: SETUP 是否已收到 200——交织模式下 media_endpoint 为空但 PLAY 仍必须发。
    pub fn setup_ok(&self)->bool{self.setup_ok}
    pub fn pending(&mut self)->Vec<Vec<u8>>{std::mem::take(&mut self.pending)}
    pub fn receive(&mut self,data:&[u8],capture:bool)->Result<(Vec<Value>,Vec<Vec<u8>>,Vec<(u8,Vec<u8>)>)>{
        if self.failed{return Err("HiSight session requires reset".into());}
        if data.len()>65536{return Err("HiSight input chunk exceeds limit".into());}
        let result=self.receive_inner(data,capture);
        if result.is_err(){self.failed=true;wipe(&mut self.buffer);self.buffer.clear();self.pending.clear();self.media=None;self.input=None;self.rtcp=None;}
        result
    }
    fn receive_inner(&mut self,data:&[u8],capture:bool)->Result<(Vec<Value>,Vec<Vec<u8>>,Vec<(u8,Vec<u8>)>)>{
        let mut events=vec![];let mut plaintexts=vec![];let mut interleaved:Vec<(u8,Vec<u8>)>=vec![];let mut count=0;
        for chunk in data.chunks(4096){self.buffer.extend(chunk);
            loop{
                if self.buffer.is_empty(){break;}
                // v0.10.70: RTSP 交织（RFC2326 §10.12）。1111(40) 实证手机 SETUP 回的
                // Transport 是 `RTP/AVP/TCP;unicast;rtcp_port=…;server_port=0;…`——
                // server_port=0 表示手机不做 RTP 服务端，视频不走独立端口，而是以
                // `0x24 <channel> <len:u16> <payload>` 的形式混在同一条 RTSP 连接里。
                // 原来这里一律按 4 字节大端长度分帧，0x24 被当成长度高位 → 直接
                // `invalid HiSight record length` 把整条会话判死，这也正是「SETUP 成功
                // 却拿不到画面、随即断链」的真正原因。
                if self.buffer[0]==0x24{
                    if self.buffer.len()<4{break;}
                    let channel=self.buffer[1];
                    let len=u16::from_be_bytes([self.buffer[2],self.buffer[3]]) as usize;
                    if self.buffer.len()<4+len{break;}
                    let payload=self.buffer[4..4+len].to_vec();
                    self.buffer.drain(..4+len);
                    if interleaved.len()<256{interleaved.push((channel,payload));}
                    continue;
                }
                if self.buffer.len()<4{break;}
                let size=u32::from_be_bytes(self.buffer[..4].try_into().unwrap()) as usize;
                if size==0||size>LIMIT{return Err("invalid HiSight record length".into());}
                if self.buffer.len()<size+4{break;}
                count+=1;if count>64{return Err("too many HiSight records".into());}
                let payload=if self.encrypted{
                    if size<=16{return Err("invalid encrypted HiSight record".into());}
                    self.crypto.transform(&self.key,&self.buffer[4..20],&self.buffer[20..size+4])?
                }else{
                    // v0.10.27: 自适应明文/密文。荣耀实机（1111(18) 取证）在车机明文
                    // ANNOUNCE 后回「明文 200 OK + 明文 ANNOUNCE + 明文 SET_PARAMETER」，
                    // 加密切换点晚于参考脚本（test-hicar-rust-hisight.py）假设——脚本
                    // 语义"announce 后手机全加密、无明文 200"在 HiCar 14.2.0.325 上不成立。
                    // 先按明文解析（ASCII 头），失败再尝试 AES-CTR 解密；解密成功即切
                    // 加密态——无论手机何时（或不）切加密都能自动跟上，不再依赖 activate。
                    let raw=&self.buffer[4..size+4];
                    if record_message(raw).is_ok(){raw.to_vec()}
                    else{
                        if size<=16{return Err("invalid HiSight record".into());}
                        let dec=self.crypto.transform(&self.key,&self.buffer[4..20],&self.buffer[20..size+4])?;
                        record_message(&dec)?;
                        self.encrypted=true;events.push(json!({"hisight_encryption":true}));
                        dec
                    }
                };
                self.buffer.drain(..size+4);let m=record_message(&payload)?;
                if capture{plaintexts.push(payload);}events.push(metadata(&m));
                let seq=m.headers.get("cseq").ok_or("missing HiSight sequence")?;sequence(seq)?;
                let method=m.start.split(' ').next().unwrap_or("");
                match method{
                    "ANNOUNCE"=>{
                        // v0.10.27: 1111(18) 实测——车机发明文 ANNOUNCE 后手机回
                        // 「明文 200 + 明文 ANNOUNCE」（双向对等声明），后续才切加密。
                        // 回 200 跟随当前态；不在此切加密（由 receive 自适应维护）；
                        // 不强制 body 含 aes128ctr（手机 ANNOUNCE 内容未知，不预设）。
                        // v0.10.34: 记录手机 ANNOUNCE 的 request-URI（peer_url）——
                        // 1111(22) 实测手机 SET_PARAMETER 只带 his_trigger_method 不带
                        // his_presentation_url，PLAY target 保持 "*" 手机不推流。
                        // 手机 ANNOUNCE 的 URL 是其声明的会话标识，可作 PLAY target 兜底。
                        if let Some(url)=m.start.split_whitespace().nth(1){
                            if !url.is_empty()&&url.len()<=256{
                                self.peer_url=Some(url.to_string());
                                // v0.10.69: SETUP/PLAY 的 request-URI 直接用手机 ANNOUNCE 的 URL。
                                // 之前只有 SET_PARAMETER 分支会改 target，ANNOUNCE 分支仍保持 "*"，
                                // 于是主动 SETUP 打出去是 `SETUP * RTSP/1.0`——手机回 200 但
                                // Transport 里没有 server_port（1111(38) 实证），会话被判死。
                                if url!="*"{self.target=url.to_string();}
                            }
                        }
                        self.queue(message("RTSP/1.0 200 OK",seq,&[],&[])?,self.encrypted)?;
                        events.push(json!({"peer_announce_replied":true,"peer_url":self.peer_url.clone()}));
                        // v0.10.72: 撤销 v0.10.68 的「ANNOUNCE 后主动补发 SETUP」。
                        // 11-11 复测 v0.10.63 仍能出画面，而 .67 之后连续 5 版全废，
                        // 两者唯一的差别就是我们抢在手机之前发了 SETUP。手机在收到
                        // 主动 SETUP 时会用 `server_port=0` 的 TCP 交织来兜（1111(40)/(41)
                        // 实证），等于把我们逼进一条它原本不必走的路。
                        // 回到 .63 的时序：SETUP 只等手机 SET_PARAMETER 带
                        // his_trigger_method=SETUP 时再发（见 SET_PARAMETER 分支）。
                        // 若手机这一轮坚持走交织，交织解析与 PLAY 仍在，两条路都能通。
                    },
                    // v0.10.27: 移除「明文态禁止 OPTIONS/GET_PARAMETER/SET_PARAMETER/
                    // TEARDOWN」守卫——1111(18) 实机在加密前就发明文 SET_PARAMETER
                    // （rtsp://localhost/hisight1.2），旧守卫会误判 Err。明文态下
                    // 任意方法均走对应分支处理（打包自动跟随当前态）。
                    "OPTIONS"=>{
                        self.queue(message("RTSP/1.0 200 OK",seq,&[],&[("Public","hisight1.0, GET_PARAMETER, SET_PARAMETER".into())])?,false)?;
                        if !self.options_sent{self.queue(message("OPTIONS * RTSP/1.0","2",&[],&[("Require","hisight1.0".into())])?,false)?;self.options_sent=true;}
                    },
                    "GET_PARAMETER"=>{
                        let body=std::str::from_utf8(&m.body).map_err(|_|"invalid HiSight capability request")?;
                        if !body.is_ascii(){return Err("invalid HiSight capability request".into());}
                        let requested:std::collections::BTreeSet<_>=body.lines().filter(|l|!l.trim().is_empty()).map(|l|l.split(':').next().unwrap().trim()).collect();
                        // v0.10.61: 能力表现场拼——分辨率/码率/帧率/GOP 全部来自
                        // VIDEO_* 原子量，设置面板改了就生效，不必重编 .so。
                        let (w,h)=(VIDEO_W.load(Ordering::Relaxed),VIDEO_H.load(Ordering::Relaxed));
                        let (br,vmin,vmax)=(VIDEO_BITRATE.load(Ordering::Relaxed),VIDEO_VBR_MIN.load(Ordering::Relaxed),VIDEO_VBR_MAX.load(Ordering::Relaxed));
                        let (fps,gop)=(VIDEO_FPS.load(Ordering::Relaxed),VIDEO_GOP.load(Ordering::Relaxed));
                        let video=format!("codecs 1;fps {fps};gop {gop};bitrate {br};vbr-min {vmin};vbr-max {vmax};dpi 160;scr-w {w};scr-h {h};width {w};height {h}");
                        let capabilities=[("his_version","1.0".to_string()),("his_video_formats",video.clone()),("his_audio_codecs","1".to_string()),("his_device_type","device_type 4;subtype 0;".to_string()),("his_uibc_capability","input_category_list=GENERIC;generic_cap_list=left_point_down, left_point_up, left_move, left_key_down, left_key_up;".to_string())];
                        let body=capabilities.iter().filter(|(k,_)|requested.contains(k)).map(|(k,v)|format!("{k}: {v}\r\n") ).collect::<String>();
                        // v0.10.77: 把实际回给手机的能力表原文打进日志。
                        // 1111(47) 的投屏段完全没有 GET_PARAMETER 痕迹，无法判断是手机没请求、
                        // 还是请求了我们没回——只有打出声明值才能对账（也是"清晰度不高"的取证前提）。
                        let replied:Vec<String>=capabilities.iter().filter(|(k,_)|requested.contains(k)).map(|(k,v)|format!("{k}: {v}") ).collect();
                        self.queue(message("RTSP/1.0 200 OK",seq,body.as_bytes(),&[])?,false)?;
                        // v0.10.77: 必须等 queue 成功后才 push「已回复」事件。
                        // 反过来的话，队列满/打包失败时日志仍显示 capabilities_replied=true，
                        // 等于向下一轮取证提供假阳性。
                        events.push(json!({"capabilities_replied":true,"requested":requested,"declared":replied}));
                    },
                    "SET_PARAMETER"=>{
                        let body=std::str::from_utf8(&m.body).map_err(|_|"invalid HiSight parameters")?;
                        if !body.is_ascii(){return Err("invalid HiSight parameters".into());}
                        let parameters:BTreeMap<_,_>=body.lines().filter_map(|l|l.split_once(':')).map(|(k,v)|(k.trim().to_ascii_lowercase(),v.trim())).collect();
                        events.push(json!({"parameter_names":parameters.keys().collect::<Vec<_>>()}));
                        self.queue(message("RTSP/1.0 200 OK",seq,&[],&[])?,false)?;
                        if let Some(value)=parameters.get("his_presentation_url"){
                            let target=value.split_whitespace().next().ok_or("invalid HiSight presentation URL")?;
                            let suffix=target.strip_prefix("rtsp://").ok_or("invalid HiSight presentation URL")?;
                            if suffix.is_empty()||suffix.len()>256||!suffix.bytes().all(|b|b.is_ascii_alphanumeric()||b".:/_?=&%-".contains(&b)){return Err("invalid HiSight presentation URL".into());}
                            self.target=target.into();
                        } else if let Some(peer)=self.peer_url.clone(){
                            // v0.10.34: 手机未下发 his_presentation_url（1111(22) 实测
                            // parameter_names=["his_trigger_method"]）时，用手机 ANNOUNCE
                            // 的 request-URI 作为 PLAY target——target 保持 "*" 时手机
                            // 接受 SETUP 但不回 PLAY 200、不推视频流。
                            if peer!="*"{self.target=peer;}
                        }
                        // v0.10.67: 只在还没有 SETUP 时才依 trigger 发，避免与
                        // ANNOUNCE 200 后的主动 SETUP 撞成两次。
                        if self.setup.is_none() && parameters.get("his_trigger_method")==Some(&"SETUP"){self.setup=Some(self.request("SETUP")?);}
                        else if parameters.get("his_trigger_method")==Some(&"TEARDOWN"){self.peer_teardown=true;}
                        // v0.10.35: 输出最终 PLAY target（H1 验证——手机不带
                        // his_presentation_url 时是否用了手机 ANNOUNCE URL 兜底）。
                        events.push(json!({"play_target":self.target.clone()}));
                    },
                    "TEARDOWN"=>{self.queue(message("RTSP/1.0 200 OK",seq,&[],&[])?,false)?;self.peer_teardown=true;},
                    "RTSP/1.0"=>{
                        // v0.10.27: 不再「见 200 就置加密」。1111(18) 取证：手机对车机
                        // 明文 ANNOUNCE 回明文 200 OK（Date/Server/CSeq 头）——旧逻辑
                        // 在此置 encrypted=true 会把后续明文 ANNOUNCE/SET_PARAMETER 当
                        // 密文解密 → invalid HiSight header。加密切换已由 receive 自适应维护。
                        // v0.10.67: 手机对 ANNOUNCE 回 200（CSeq:1）后，部分版本不再下发
                        // his_trigger_method=SETUP，只是等车机发 SETUP。
                        // v0.10.68: 但 200 到达时 peer_url 往往还为空（手机的 ANNOUNCE
                        // 可能稍后才到），此时 SETUP 的 target 只能是 "*"。1111(38) 实测：
                        // `SETUP * RTSP/1.0` 手机回了 200，Transport 却没有 server_port，
                        // 直接判 `missing HiSight media port` 把会话钉死。所以这里只在
                        // 已经拿到手机 ANNOUNCE 的 URL 时才补发；没拿到就等 ANNOUNCE 分支。
                        // v0.10.72: 撤销 v0.10.67 的「收到首个 200 就补发 SETUP」——
                        // 同上，主动 SETUP 会把手机推向交织模式。SETUP 只由手机
                        // SET_PARAMETER 的 his_trigger_method 触发。
                        // （原条件 seq=="1" && peer_url.is_some() && !peer_teardown）
                        if self.teardown.is_some_and(|n|seq==&n.to_string()){self.acknowledged=m.start.starts_with("RTSP/1.0 200 ");}
                        else if self.setup.is_some_and(|n|seq==&n.to_string()){
                            if !m.start.starts_with("RTSP/1.0 200 "){return Err("HiSight setup refused".into());}
                            let transport=m.headers.get("transport").cloned().unwrap_or_default();
                            // v0.10.41: 取证——SETUP 200 的 Transport 原文，判断手机媒体
                            // 传输形态（server_port 拉流 vs interleaved 交织）及 remotectl_port。
                            events.push(json!({"setup_transport":transport.clone()}));
                            // v0.10.70: 只要 SETUP 回了 200 就算协商完成——交织模式
                            // （server_port=0）也必须发 PLAY，否则手机不会往 RTSP 连接里
                            // 推交织帧。1111(41) 实证：setup_transport 已到、48B 200 已回，
                            // 但没有 PLAY，43ms 后手机就把 sight channel 关了。
                            self.setup_ok=true;
                            // 交织模式下 Transport 仍带 remotectl_port / rtcp_port，
                            // 触摸与 RTCP 保活必须靠这两个端口（server_port 才是 0）。
                            self.input=port(&transport,"remotectl_port");
                            self.rtcp=port(&transport,"rtcp_port");
                            match port(&transport,"server_port"){
                                Some(p)=>{
                                    self.media=Some(p);
                                    self.input=port(&transport,"remotectl_port");
                                    // v0.10.49: 手机回的 Transport 带 rtcp_port——RTCP 通道
                                    // 若长期缺位，媒体会话约 2 秒后被判超时。导出给 Kotlin。
                                    self.rtcp=port(&transport,"rtcp_port");
                                    events.push(json!({"media_port":p}));
                                }
                                None=>{
                                    // v0.10.68: 手机对 SETUP 回了 200，但 Transport 里没有
                                    // server_port（1111(38)：我们发的是 `SETUP * RTSP/1.0`，
                                    // target 还是 "*"，手机只回了不带端口的 200）。
                                    // 原来这里直接 Err("missing HiSight media port")，
                                    // 会把 session 置 failed → 整条链路被判死，BT/TCP 立刻
                                    // 全断。缺端口本身不是协议错误，这里只记录、不判死，
                                    // 让 Kotlin 的重试与后续协商还有机会。
                                    events.push(json!({"setup_no_server_port":true}));
                                }
                            }
                        }
                        else if self.play.is_some_and(|n|seq==&n.to_string()){
                            // v0.10.32: 取证——手机是否回 PLAY 200（H1：target/会话 URL 协商后手机是否接受并起播）
                            let ok=m.start.starts_with("RTSP/1.0 200 ");
                            // v0.10.41: PLAY 200 的 Session 头 + 响应行——判断手机是否真的
                            // 建立了投影会话（此前只知"接受 PLAY"，不知会话是否绑定成功）。
                            let session_id=m.headers.get("session").map(|s|s.to_string()).unwrap_or_default();
                            events.push(json!({"play_acknowledged":ok,"play_session":session_id}));
                        }
                    },other=>{
                        // v0.10.69: 手机发来我们没实现的方法（SETUP/PLAY/PING 等）原来落到
                        // `_=>{}` 静默丢弃，手机等不到响应就把整条链路判死（1111(39) 的第 5
                        // 个包之后 BT+TCP 全断）。这里先原样记录请求头取证，再按 RTSP 惯例
                        // 回 200，至少不主动把链路拖死。
                        events.push(json!({"unhandled_request":other,"url":m.start.split_whitespace().nth(1),"headers":m.headers.iter().map(|(k,v)|format!("{k}={v}")).collect::<Vec<_>>()}));
                        if !other.is_empty(){self.queue(message("RTSP/1.0 200 OK",seq,&[],&[])?,self.encrypted)?;}
                    },
                }
            }
        }Ok((events,plaintexts,interleaved))
    }
}

pub fn differential(v:&Value)->Result<Value>{
    let key=unhex(v["key"].as_str().ok_or("missing synthetic key")?)?;let mut session=Session::new(&key)?;
    let steps=v["steps"].as_array().filter(|v|v.len()<=256).ok_or("invalid HiSight transcript")?;let mut out=vec![];
    for step in steps{
        let mut events=vec![];let mut plaintexts=vec![];let mut interleaved=vec![];
        if let Some(data)=step.get("receive"){let (e,p,i)=session.receive(&unhex(data.as_str().ok_or("invalid HiSight transcript bytes")?)?,true)?;events=e;plaintexts=p;interleaved=i;}
        let teardown=if step["teardown"]==true{session.teardown()?}else{None};
        if step["play"]==true{session.request("PLAY")?;}
        out.push(json!({"events":events,"plaintexts":plaintexts.iter().map(|v|hex(v)).collect::<Vec<_>>(),"pending":session.pending().iter().map(|v|hex(v)).collect::<Vec<_>>(),"teardown":teardown.map(|v|hex(&v)),"state":session.state()}));
    }Ok(json!({"steps":out}))
}
