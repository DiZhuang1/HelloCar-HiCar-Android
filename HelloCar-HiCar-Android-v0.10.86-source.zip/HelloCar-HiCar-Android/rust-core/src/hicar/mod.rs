//! Wireless HiCar discovery, authentication, session transport and media.
//!
//! Android cross-compile variant (rust-core): the pure protocol core
//! (wire/json/media/crypto/identity/session/hisight/dmsdp + radio contract)
//! compiles on every platform; the Linux platform workers (BlueZ D-Bus/HCI,
//! ffmpeg subprocess, multi-process private IPC, HiChain native adapter)
//! are gated to `all(unix, not(target_os = "android"))` and replaced on
//! Android by the Kotlin/JNI layer (see `crate::jni`).
pub mod wire;
pub mod json;
pub mod media;
pub mod crypto;
pub mod identity;
pub mod session;
pub mod hisight;
pub mod dmsdp;
// Linux-only platform workers: BlueZ radio, ffmpeg media pipeline, multi-process IPC.
#[cfg(all(unix, not(target_os = "android")))]
pub mod live;
#[cfg(all(unix, not(target_os = "android")))]
pub mod uplink;
#[cfg(all(unix, not(target_os = "android")))]
pub mod backend;
// HiChain native adapter: pure libloading + file callbacks, compiles on bionic too.
pub mod native;
// Android session engine (channel-oriented backend replacement).
#[cfg(target_os = "android")]
pub mod android_engine;
#[cfg(all(unix, not(target_os = "android")))]
mod cli;
// Radio pure protocol contract is portable; the BlueZ `linux` sub-module is
// gated inside radio.rs.
pub mod radio;

pub type Result<T> = std::result::Result<T, String>;
pub fn run(args: &[String]) -> Result<()> {
    #[cfg(all(unix, not(target_os = "android")))]
    { cli::run(args) }
    #[cfg(not(all(unix, not(target_os = "android"))))]
    {
        let _ = args;
        Err("HelloCar protocol core: Android orchestration lives in the JNI/Kotlin layer (crate::jni), not the Linux CLI".into())
    }
}

pub fn hex(data: &[u8]) -> String { data.iter().map(|b|format!("{b:02x}")).collect() }
pub fn unhex(text: &str) -> Result<Vec<u8>> {
    if text.len()%2!=0 || text.len()>4*1024*1024 || !text.is_ascii() {
        return Err("invalid bounded hex input".into());
    }
    (0..text.len()).step_by(2).map(|i|u8::from_str_radix(&text[i..i+2],16)
        .map_err(|_|"invalid hex byte".into())).collect()
}
