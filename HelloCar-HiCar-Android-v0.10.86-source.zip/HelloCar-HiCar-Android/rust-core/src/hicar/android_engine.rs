//! Android session engine (M2b + M2c): channel-oriented replacement for the
//! Linux multi-process backend. The Kotlin platform layer owns every transport
//! (RFCOMM FE35/FE36 and TCP 4005/4006/4007, HiSight RTSP/media TCP, input TCP,
//! audio UDP) and feeds byte streams through JNI; this engine owns the protocol
//! state machines — Nearby/CCMP negotiation (session::Negotiator), the business
//! JSON envelope + HiChain authentication (native::Session), the ResourceManager
//! (session::Resource), the DMSDP control session (dmsdp::Session) and the
//! HiSight RTSP session (hisight::Session). Media (H.264 AU + AAC-ADTS frames)
//! is decrypted here and handed to Kotlin through the `take_media` output queue;
//! touch/key input is packed here with `send_input`.
//!
//! Channel kinds (mirrors backend.rs Kind):
//!   0 NearbyRfcomm — RFCOMM FE35 (business endpoint offer 24, sends initial)
//!   1 NearbyTcp   — TCP 4005 (passive negotiator, no initial)
//!   2 Business    — RFCOMM FE36 (auth envelope stream)
//!   3 Data        — TCP 4006 (module frame, replies with control port)
//!   4 Control     — TCP 4007 (DMSDP)
//!   5 MediaVideo  — HiSight media TCP (4B BE len + RTP record -> H.264 AU)
//!   6 MediaAudio  — HiSight audio UDP (0xAB + len + IV + AES-CTR(RTP))
//!   7 Sight       — HiSight RTSP TCP (media_endpoint/input_endpoint discovery)
//!
//! Hotspot parameters are injected with `set_hotspot` after the Android
//! local-only hotspot is up; the credentials string then carries the real
//! SSID/password/subnet/frequency instead of the fixed 192.168.49.x/5745.
//! Audio UDP local port is injected with `set_audio_port` before the DMSDP
//! speaker negotiation consumes it.

#![cfg(target_os = "android")]

use super::{Result, wire::{Frame, Format, Decoder}, json};
use super::session::{Offer, Resource, Negotiator};
use super::native::{Runtime, Session as AuthSession};
use super::identity::Identity;
use super::crypto::Crypto;
use super::{media, hisight};
use serde_json::{Value, json as value};
use std::collections::{BTreeMap, VecDeque};

const CHANNEL_LIMIT: usize = 8;
// v0.10.31 自检修复：200 → 600。v0.10.29 全量 DMSDP events 日志后 keepalive 每秒刷屏，
// 200 条环形窗口会在几分钟内把早期宣告链证据（service_request_mask/service_announced/
// binary）挤出（1111(21) 尾部 30 行无宣告证据的根因）。配合 keepalive 降频，
// 600 条窗口可覆盖整个会话早期阶段。
const LOG_LIMIT: usize = 600;
const MAX_REPLY: usize = 256 * 1024;
const MAX_VIDEO: usize = 512 * 1024;
const MEDIA_QUEUE: usize = 128;

fn now_us() -> u64 {
    let mut t = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut t); }
    t.tv_sec as u64 * 1_000_000 + t.tv_nsec as u64 / 1000
}

fn log_line(log: &mut VecDeque<String>, s: &str) {
    if log.len() >= LOG_LIMIT { log.pop_front(); }
    log.push_back(format!("[{}] {}", crate::monotonic_millis(), s));
}

/// Media frames decrypted by the engine and handed to Kotlin through JNI.
/// Video carries one complete H.264 Annex-B access unit (SPS/PPS prepended on
/// key frames); audio carries one raw AAC-ADTS frame (Kotlin decodes with
/// MediaCodec -> PCM 44100 stereo -> AudioTrack).
#[derive(Debug)]
pub enum MediaEvent {
    Video { data: Vec<u8>, key: bool, pts: u64 },
    Audio { data: Vec<u8>, rate: u32, channels: u8, pts: u64 },
}

/// Default placeholder offer, replaced by `set_hotspot` once the Android
/// local-only hotspot is ready (credentials are only served after
/// authentication, by which time the real parameters are in place).
fn placeholder_offer() -> Offer {
    Offer::parse(&value!({
        "ssid": "HelloCar",
        "bssid": "02:00:00:00:00:01",
        "password": "0000000000000000",
        "owner_ip": "192.168.49.1",
        "client_ip": "192.168.49.2",
        "frequency": 5745,
        "port": 4005,
    })).expect("placeholder offer must parse")
}

/// Load (or reuse) the single-process HiChain runtime. The process-lifetime
/// leak avoids a self-referential `Session<'static>` borrow of the runtime.
fn ensure_runtime(runtime: &mut Option<&'static Runtime>, auth_library: &str,
                  store_path: &str, device_id: &str) -> Result<&'static Runtime> {
    if let Some(r) = runtime.as_ref() { return Ok(*r); }
    // v0.10.15: Runtime::open 已返回进程级单例（&'static），无需再次 Box::leak。
    let rt = Runtime::open(std::path::Path::new(auth_library), std::path::Path::new(store_path), device_id)
        .map_err(|e| format!("HiChain runtime: {e}"))?;
    *runtime = Some(rt);
    Ok(rt)
}

fn nal_units(data: &[u8]) -> Option<Vec<&[u8]>> {
    // Annex-B start codes: 00 00 01 or 00 00 00 01.
    let mut starts = Vec::new();
    let mut i = 0;
    while i + 3 < data.len() {
        if data[i] == 0 && data[i + 1] == 0 {
            let (code, len) = if data[i + 2] == 1 { (3, 3) } else if data[i + 2] == 0 && i + 3 < data.len() && data[i + 3] == 1 { (4, 4) } else { (0, 0) };
            if code != 0 { starts.push((i, len)); i += len; continue; }
        }
        i += 1;
    }
    if starts.is_empty() { return None; }
    let mut units = Vec::new();
    for w in starts.windows(2) {
        let (start, len) = w[0];
        units.push(&data[start + len..w[1].0]);
    }
    let (start, len) = *starts.last().unwrap();
    units.push(&data[start + len..]);
    if units.iter().any(|u| u.is_empty()) { return None; }
    Some(units)
}

fn encrypt(crypto: &Crypto, key: &[u8], plain: &[u8]) -> Result<Vec<u8>> {
    let mut iv = [0u8; 16];
    std::fs::File::open("/dev/urandom").and_then(|mut f| std::io::Read::read_exact(&mut f, &mut iv))
        .map_err(|_| "media IV unavailable".to_string())?;
    let mut out = iv.to_vec();
    out.extend(crypto.transform(key, &iv, plain)?);
    Ok(out)
}

fn decrypt(crypto: &Crypto, key: &[u8], record: &[u8]) -> Result<Vec<u8>> {
    if record.len() <= 16 { return Err("truncated encrypted media record".into()); }
    crypto.transform(key, &record[..16], &record[16..])
}

struct NearbyChannel {
    id: u32,
    decoder: Decoder,
    negotiator: Negotiator,
}

struct BusinessChannel {
    id: u32,
    generation: u32,
    stream: json::Stream,
    session: Option<AuthSession<'static>>,
    peer_seen: bool,
}

struct ControlChannel {
    id: u32,
    session: super::dmsdp::Session,
    negotiated: bool,
}

struct SightChannel {
    id: u32,
    session: hisight::Session,
}

struct VideoDecoder {
    decoder: media::Video,
    wait_key: bool,
    parameters: [Option<Vec<u8>>; 2],
}

pub struct Engine {
    identity: Identity,
    own: String,
    model: String,
    address: String,
    auth_library: String,
    store_path: String,
    resource: Resource,
    hotspot_set: bool,
    runtime: Option<&'static Runtime>,
    crypto: Crypto,
    session_key: Option<Vec<u8>>,
    next_id: u32,
    nearby: BTreeMap<u32, NearbyChannel>,
    business: Option<BusinessChannel>,
    data_id: Option<u32>,
    data_port_sent: bool,
    control: Option<ControlChannel>,
    sight: Option<SightChannel>,
    // v0.10.26: video/audio 解码器结构无 id 字段，通道 id 记录在引擎层——
    // receive 分发按 video_id/audio_id 精确匹配，避免音频帧被 video 兜底劫持
    // （音频当 RTP 解析污染视频解码器）。
    video_id: Option<u32>,
    audio_id: Option<u32>,
    video: Option<VideoDecoder>,
    audio: Option<media::Audio>,
    media_out: VecDeque<MediaEvent>,
    rtsp_port: Option<u16>,
    media_port: Option<u16>,
    input_port: Option<u16>,
    rtcp_port: Option<u16>,
    audio_port: Option<u16>,
    peer_teardown: bool,
    media_play_queued: bool,
    video_frames: u64,
    key_frames: u64,
    audio_frames: u64,
    /// v0.10.72: RTSP 交织帧（`$` + channel + len）累计数。手机回的 Transport
    /// 是 `RTP/AVP/TCP;unicast;server_port=0` 时视频只从这里来，用它判断
    /// 「PLAY 后手机到底有没有开始推流」。
    interleaved_frames: u64,
    /// v0.10.32: 视频 RTP payload type≠96 累计数（H3 取证——手机若推非 96 类型会被
    /// 静默丢弃造成黑屏且无报错，此前该静默路径无日志）。
    video_non96: u64,
    invalid: u64,
    phase: String,
    log: VecDeque<String>,
    /// v0.10.3: Nearby 协商响应参数（CCMP 版本 tag2 / 加密偏好 tag6），
    /// 由 Kotlin 在 openChannel 前经 nativeSetNegotiateParams 注入。
    ccmp_version: u8,
    enc_pref: u8,
    /// v0.10.5: FE36 业务端点 RFCOMM 信道号（kind2 响应 uint(channel)），
    /// 由 Kotlin 反射读取真实信道后经 nativeSetBusinessChannel 注入。
    business_channel: u16,
    /// v0.10.28: 触摸事件时间戳起点（对齐 live.rs：elapsed 从 input 会话开始累计）。
    /// 参考实现传 input_start.elapsed()，我们此前固定 0——手机端 UIBC 事件排序/丢帧
    /// 检测依赖时间戳，全 0 可能被手机拒收（1111(19) 输入通道写入失败候选根因之一）。
    input_start_us: Option<u64>,
    /// v0.10.28: 音频失败诊断计数——0xab 前缀/长度/解密/解析失败前 5 次打取证日志
    /// （含首包 hex），之后静默，避免刷屏淹没日志。
    audio_diag: u32,
    /// v0.10.31 自检修复（B8）: audio_diag 上次取证时间（单调毫秒，u128 与
    /// crate::monotonic_millis() 返回值类型一致）。
    audio_diag_last_ms: u128,
    /// v0.10.31 自检修复（A1）: keepalive_received 事件累计数——每秒 1 条刷屏
    /// 会挤掉宣告链证据，每 20 次才落 1 条日志。
    keepalive_seen: u64,
}

impl Engine {
    pub fn new(
        identity: Identity, model: String, address: String,
        auth_library: String, store_path: String,
    ) -> Result<Self> {
        if model.len() != 8 || !model.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err("invalid model for engine".into());
        }
        let crypto = Crypto::load().map_err(|e| format!("crypto: {e}"))?;
        let own = identity.wire_id(&model, &address, &crypto)?;
        let mut resource = Resource::new(placeholder_offer());
        resource.data_port = Some(resource.offer().port + 1);
        let mut engine = Self {
            identity, own, model, address, auth_library, store_path, resource,
            hotspot_set: false, runtime: None, crypto, session_key: None, next_id: 1,
            nearby: BTreeMap::new(), business: None, data_id: None, data_port_sent: false,
            control: None, sight: None, video_id: None, audio_id: None, video: None, audio: None, media_out: VecDeque::new(),
            rtsp_port: None, media_port: None, input_port: None, rtcp_port: None, audio_port: None,
            peer_teardown: false, media_play_queued: false, video_frames: 0, key_frames: 0, audio_frames: 0, interleaved_frames: 0, video_non96: 0, invalid: 0,
            phase: "ready".into(), log: VecDeque::new(),
            ccmp_version: 2, enc_pref: 0, business_channel: 24,
            input_start_us: None, audio_diag: 0, audio_diag_last_ms: 0u128, keepalive_seen: 0,
        };
        log_line(&mut engine.log, "engine ready (M2c media path)");
        Ok(engine)
    }

    /// Hotspot parameter back-fill: real SSID/password/subnet/frequency/port.
    pub fn set_hotspot(&mut self, ssid: &str, password: &str, bssid: &str,
                       owner: &str, client: &str, frequency: u32, port: u32) -> Result<()> {
        let offer = value!({
            "ssid": ssid, "bssid": bssid, "password": password,
            "owner_ip": owner, "client_ip": client, "frequency": frequency, "port": port,
        });
        self.resource.set_hotspot(&offer)?;
        self.hotspot_set = true;
        log_line(&mut self.log, &format!("hotspot back-filled ssid={ssid} owner={owner} client={client} freq={frequency} port={port}"));
        Ok(())
    }

    /// Local audio UDP port, bound by Kotlin before DMSDP speaker negotiation.
    pub fn set_audio_port(&mut self, port: u16) -> Result<()> {
        if port == 0 { return Err("invalid audio port".into()); }
        if let Some(c) = self.control.as_mut() {
            c.session.set_audio_ports((port, -1))?;
        }
        self.audio_port = Some(port);
        log_line(&mut self.log, &format!("audio udp port set {port}"));
        Ok(())
    }

    /// v0.10.3: Nearby 协商响应参数（须在 openChannel 前调用，只影响其后创建的 Negotiator）。
    /// ccmp_version: tag2 回值（CCMP 版本，0 视为保持默认 2）；enc_pref: tag6 回值（加密偏好，0..=2）。
    /// 手机实测 tag1=[4]、tag5=[2]，原固定回 [2]/[0] 可能被手机拒绝——参数化用于实车对照。
    pub fn set_negotiate(&mut self, ccmp_version: u8, enc_pref: u8) {
        self.ccmp_version = if ccmp_version == 0 { 2 } else { ccmp_version };
        self.enc_pref = if enc_pref > 2 { 2 } else { enc_pref };
        log_line(&mut self.log, &format!("negotiate params set: ccmp_version={} enc_pref={}", self.ccmp_version, self.enc_pref));
    }

    /// v0.10.5：FE36 业务端点 RFCOMM 信道号（kind2 响应 uint(channel)）。
    /// Android listenUsingRfcommWithServiceRecord 的信道由系统分配（反射读取 mChannel），
    /// 原实现固定 24 仅在 BlueZ 静态注册下成立；须在 openChannel(FE35 accept) 前注入。
    /// channel==0 视为未设置（保持默认 24）；>30 视为 24。
    pub fn set_business_channel(&mut self, channel: u16) {
        self.business_channel = if channel == 0 || channel > 30 { 24 } else { channel };
        log_line(&mut self.log, &format!("business channel set: {}", self.business_channel));
    }

    /// Open a channel. Returns (id, initial bytes) — initial is None for
    /// passive channels (NearbyTcp/Data/MediaVideo/MediaAudio) and Some for
    /// NearbyRfcomm/Control/Sight.
    pub fn open(&mut self, kind: u32) -> Result<(u32, Option<Vec<u8>>)> {
        if self.nearby.len() + usize::from(self.business.is_some()) + usize::from(self.control.is_some()) + usize::from(self.sight.is_some()) >= CHANNEL_LIMIT {
            return Err("channel limit".into());
        }
        let id = self.next_id; self.next_id = self.next_id.checked_add(1).ok_or("channel id exhausted")?;
        match kind {
            0 => {
                // RFCOMM FE35 control: phone-initiated accept — PASSIVE Nearby
                // negotiation. radio.rs rfcomm events always carry
                // initiator=false, and backend.rs:260 only sends the initial
                // frame when initiator==true. The phone (initiator) must send
                // its first CCMP/identity frame before we respond; sending our
                // own initial frame first makes the phone close immediately
                // (observed: RFCOMM connects then read -1 / channel open-close
                // loop). No initial bytes are emitted here.
                let mut n = Negotiator::new(self.own.as_bytes().to_vec(), Some(24))?;
                n.set_params(self.ccmp_version, self.enc_pref);
                n.set_channel(self.business_channel);
                self.nearby.insert(id, NearbyChannel { id, decoder: Decoder::new(Format::Nearby), negotiator: n });
                log_line(&mut self.log, "nearby(rfcomm FE35) channel open (passive, wait phone frame)");
                Ok((id, None))
            }
            1 => {
                // TCP 4005 passive negotiator (no business endpoint offer).
                // v0.10.11: 手机继承 FE35 协商结果，连上后直接发 (33,1) 业务帧，不再重新协商。
                // v0.10.13: 实测手机连 4005 后等车机 initial（5s 超时→发 (33,5)→0.5s 放弃→重试），
                // 被动等待导致手机反复重试转圈。主动发 kind0 协商发起帧让手机继续。
                let mut n = Negotiator::new(self.own.as_bytes().to_vec(), None)?;
                n.set_params(self.ccmp_version, self.enc_pref);
                n.assume_complete();
                let initial = n.initial_payload()?;
                self.nearby.insert(id, NearbyChannel { id, decoder: Decoder::new(Format::Nearby), negotiator: n });
                log_line(&mut self.log, "nearby(tcp 4005) channel open (inherits FE35 negotiation, sending kind0 initial)");
                Ok((id, Some(Frame { kind: 0, flags: 0, options: vec![], payload: initial }.encode(Format::Nearby)?)))
            }
            2 => {
                // Business auth: revoke previous auth and reset the resource
                // (mirrors backend auth-open semantics).
                self.business = Some(BusinessChannel {
                    id, generation: 0, stream: json::Stream::new(), session: None, peer_seen: false,
                });
                self.resource.reset();
                // v0.10.18: 新认证会话复位热点标记——上一会话的热点可能已停止，
                // 残留 true 会导致认证后发 REAL 凭证指向已停热点（v0.10.16 实测 1111(6)）。
                self.hotspot_set = false;
                self.data_port_sent = false;
                self.session_key = None;
                // v0.10.21: 新认证会话整体丢弃旧媒体/DMSDP 会话（1111(9) 实测：手机断链后
                // 重连 nearby 请求新凭证，但旧 control 仍挂着 failed 的 DMSDP 会话，
                // requires reset 刷屏导致手机永远无法恢复）。重连 = 从零开始。
                self.control = None;
                self.sight = None;
                self.video_id = None;
                self.audio_id = None;
                self.video = None;
                self.audio = None;
                self.rtsp_port = None;
                self.media_port = None;
                self.input_port = None;
                // v0.10.51 自检修复：复位时漏清 rtcp_port——上一轮会话的 RTCP 端口会
                // 残留到新会话，Kotlin 端 status 里一读就有值，于是立刻往旧端口发包。
                self.rtcp_port = None;
                self.phase = "authenticating".into();
                log_line(&mut self.log, "business(authentication FE36) channel open (reset old sessions)");
                Ok((id, None))
            }
            3 => {
                self.data_id = Some(id);
                log_line(&mut self.log, "data(tcp 4006) channel open");
                Ok((id, None))
            }
            4 => {
                if self.business.is_none() { return Err("authentication channel required".into()); }
                let key = self.business.as_ref()
                    .and_then(|b| b.session.as_ref())
                    .and_then(|s| s.key_for_bridge())
                    .ok_or("authenticated session key missing")?;
                self.session_key = Some(key.clone());
                let info = self.device_info();
                let mut session = super::dmsdp::Session::new(&key, info, true)
                    .map_err(|e| format!("DMSDP session: {e}"))?;
                // v0.10.24: Kotlin 在 4007 打开前就注入音频 UDP 端口（1111(14) 实测
                // set_audio_port 时 control=None 被跳过，speaker.ports 未配置 → 手机请求
                // speaker 端口报 "speaker ports are not configured" → DMSDP requires reset
                // → 手机断链离开热点 → RTSP 连接 EHOSTUNREACH）。control 创建后必须补设。
                if let Some(ap) = self.audio_port {
                    session.set_audio_ports((ap, -1))?;
                    log_line(&mut self.log, &format!("audio ports back-filled into control session: {ap}"));
                }
                let initial = session.initial()?;
                self.control = Some(ControlChannel { id, session, negotiated: false });
                self.phase = "dmsdp_negotiating".into();
                log_line(&mut self.log, "control(tcp 4007) DMSDP open");
                Ok((id, Some(initial)))
            }
            5 => {
                // HiSight media TCP: video RTP records (4B BE len + payload).
                if self.media_port.is_none() { return Err("HiSight media endpoint unknown".into()); }
                self.video_id = Some(id);
                self.video = Some(VideoDecoder { decoder: media::Video::new(), wait_key: true, parameters: [None, None] });
                log_line(&mut self.log, "media(video tcp) channel open");
                Ok((id, None))
            }
            6 => {
                // HiSight audio UDP: 0xAB + u16 len + IV + AES-CTR(RTP).
                if self.audio_port.is_none() { return Err("audio endpoint unknown".into()); }
                self.audio_id = Some(id);
                self.audio = Some(media::Audio::new());
                log_line(&mut self.log, "media(audio udp) channel open");
                Ok((id, None))
            }
            7 => {
                // HiSight RTSP control TCP (port from DMSDP module 5 cmd 101).
                if self.rtsp_port.is_none() { return Err("HiSight RTSP endpoint unknown".into()); }
                let key = self.session_key.clone().ok_or("session key missing")?;
                let mut session = hisight::Session::new(&key).map_err(|e| format!("HiSight session: {e}"))?;
                // v0.10.27: 撤销 activate 提前置位——1111(18) 取证：手机对车机明文
                // ANNOUNCE 回「明文 200 OK + 明文 ANNOUNCE + 明文 SET_PARAMETER」，
                // 加密切换点晚于参考脚本假设；hisight::receive 已改自适应明文/密文
                // （先试明文、失败再 AES-CTR 解密并置位），无需、也不能提前切态。
                let initial = session.initial()?;
                self.sight = Some(SightChannel { id, session });
                self.phase = "hisight_negotiating".into();
                log_line(&mut self.log, "sight(hisight rtsp) channel open");
                Ok((id, Some(initial)))
            }
            _ => Err("unknown channel kind".into()),
        }
    }

    fn device_info(&self) -> Value {
        let offer = self.resource.offer();
        value!({
            "deviceId": self.own,
            "deviceName": "HelloCar",
            "deviceType": 4,
            "bluetoothMac": self.address,
            "btName": "HelloCar",
            "localIp": offer.owner(),
            "remoteIp": offer.client(),
            "port": 0,
            "properties": { "2003": self.model, "5002": true, "5003": true, "5004": true, "5014": false },
        })
    }

    /// Request a video key frame. Mirrors live.rs link.recover(): drop queued
    /// video, re-arm wait_key, discard everything until the next IDR. No
    /// explicit FIR/PLI is sent — the phone repeats IDRs every gop (30 frames).
    pub fn request_keyframe(&mut self) {
        if let Some(v) = self.video.as_mut() {
            v.decoder = media::Video::new();
            v.wait_key = true;
            v.parameters = [None, None];
        }
        log_line(&mut self.log, "key frame requested (wait_key re-armed)");
    }

    /// Pack one UIBC input record for the HiSight remotectl TCP port.
    /// body is a media::touch / media::key event body; wire =
    /// [0x00,0x00] + u16BE(len(IV+ct)+4) + IV + AES-CTR(6*0xFF + body)
    /// (mirrors live.rs pack_input).
    fn pack_input(&self, body: &[u8]) -> Result<Vec<u8>> {
        let key = self.session_key.as_ref().ok_or("session key missing")?[..16].to_vec();
        let mut plain = vec![255; 6];
        plain.extend(body);
        let record = encrypt(&self.crypto, &key, &plain)?;
        if record.len() + 4 > 65535 { return Err("input record too large".into()); }
        let mut out = vec![0, 0];
        out.extend(((record.len() + 4) as u16).to_be_bytes());
        out.extend(record);
        Ok(out)
    }

    /// Send an input event. kind: 0=touch, 1=key, 2=keyframe.
    /// touch payload = [x f32 BE][y f32 BE][action u8] (9 bytes), x/y in 0..=1
    /// normalized against the negotiated 800x480 display, action 0=down/1=up/2=move;
    /// key payload = [code u8] with 0 home / 1 back / 2 enter / 3 left / 4 right /
    /// 5 up / 6 down / 7 play_pause / 8 next / 9 previous. Returns the packed
    /// wire record(s) that Kotlin writes to the input TCP socket.
    pub fn send_input(&mut self, kind: u32, payload: &[u8]) -> Result<Vec<u8>> {
        match kind {
            0 => {
                if payload.len() != 9 { return Err("touch payload must be 9 bytes".into()); }
                let x = f32::from_be_bytes(payload[0..4].try_into().unwrap());
                let y = f32::from_be_bytes(payload[4..8].try_into().unwrap());
                let action = payload[8];
                if !x.is_finite() || !y.is_finite() || !(0.0..=1.0).contains(&x) || !(0.0..=1.0).contains(&y) {
                    return Err("touch coordinates out of range".into());
                }
                if action > 2 { return Err("invalid touch action".into()); }
                // v0.10.61: 换算和上限都读 hisight 里的全局画面参数——
                // 设置面板改了分辨率，这里自动跟着变，不会和协商出来的尺寸错位。
                let (vw, vh) = (super::hisight::VIDEO_W.load(std::sync::atomic::Ordering::Relaxed),
                                super::hisight::VIDEO_H.load(std::sync::atomic::Ordering::Relaxed));
                let xy = ((x * vw as f32) as u16, (y * vh as f32) as u16);
                let xy = (xy.0.min(vw.saturating_sub(1) as u16), xy.1.min(vh.saturating_sub(1) as u16));
                // v0.10.28: elapsed 对齐参考 live.rs（input_start.elapsed().as_millis()）——
                // 触摸时间戳从首次触摸起累计，全 0 可能被手机端 UIBC 排序/丢帧检测拒收。
                let now = now_us();
                let elapsed = match self.input_start_us {
                    Some(s) => ((now.saturating_sub(s)) / 1000) as u32,
                    None => { self.input_start_us = Some(now); 0 }
                };
                let body = media::touch(xy.0, xy.1, action, elapsed)?;
                log_line(&mut self.log, &format!("input touch x={} y={} action={} elapsed={}", xy.0, xy.1, action, elapsed));
                self.pack_input(&body)
            }
            1 => {
                if payload.len() != 1 { return Err("key payload must be 1 byte".into()); }
                let name = match payload[0] {
                    0 => "home", 1 => "back", 2 => "enter", 3 => "left", 4 => "right",
                    5 => "up", 6 => "down", 7 => "play_pause", 8 => "next", 9 => "previous",
                    _ => return Err("unsupported key code".into()),
                };
                let down = media::key(name, true)?;
                let up = media::key(name, false)?;
                let mut out = self.pack_input(&down)?;
                out.extend(self.pack_input(&up)?);
                log_line(&mut self.log, &format!("input key {name} (down+up)"));
                Ok(out)
            }
            2 => {
                self.request_keyframe();
                Ok(Vec::new())
            }
            _ => Err("unknown input kind".into()),
        }
    }

    /// Drain media frames for the JNI bridge (called after each feed).
    pub fn take_media(&mut self) -> Vec<MediaEvent> {
        let mut out = Vec::new();
        while let Some(e) = self.media_out.pop_front() {
            out.push(e);
            if out.len() >= 64 { break; }
        }
        out
    }

    /// v0.10.70: 视频 RTP/解密/NAL 解析。独立端口（video channel）与 RTSP 交织
    /// 模式共用——手机 SETUP 回 server_port=0 时视频以 `$` 交织帧混在 RTSP 连接里。
    fn feed_video(&mut self, data: &[u8]) -> Result<()> {
            // v0.10.72: 交织模式（Transport server_port=0）下 Kotlin 不会打开
            // CH_MEDIA_VIDEO —— open(5) 要求 media_port 非空，而交织时它恒为 None，
            // 于是 self.video 一直是 None，所有交织帧都会以 "video channel absent"
            // 报错，把整条 sight 链路判死。这里就地建解码状态。
            if self.video.is_none() {
                self.video = Some(VideoDecoder { decoder: media::Video::new(), wait_key: true, parameters: [None, None] });
                log_line(&mut self.log, "video decoder created lazily (interleaved mode)");
            }
            let v = self.video.as_mut().ok_or("video channel absent")?;
            // v0.10.26c: 显式截 16B——session_key 允许 32B（HiChain bridge key），
            // DMSDP/hisight 均已 key.take(16)；OpenSSL aes_128_ctr 对 32B 的截断行为
            // 依赖库内部实现，必须显式统一为前 16B 与手机约定一致。
            let key = self.session_key.clone().ok_or("session key missing")?[..16].to_vec();
            let record = match v.decoder.receive(data) {
                Ok(frame) => frame,
                Err(e) => {
                    self.invalid += 1;
                    v.decoder = media::Video::new();
                    v.wait_key = true;
                    v.parameters = [None, None];
                    log_line(&mut self.log, &format!("video rtp error: {e} (waiting for key frame)"));
                    return Ok(());
                }
            };
            if let Some((kind, _ts, record)) = record {
                if kind != 96 {
                    // v0.10.32: 取证——RTP payload type 非 96 时此前静默丢弃（无日志）。
                    // 若手机推 97/98 等类型会造成「有包但零帧」且无任何报错，正是黑屏特征。
                    self.video_non96 += 1;
                    if self.video_non96 <= 5 || self.video_non96 % 50 == 0 {
                        let head: String = record.iter().take(24).map(|b| format!("{b:02x}")).collect();
                        log_line(&mut self.log, &format!("video rtp type={kind} ignored (expect 96) ({}B) head={head}", record.len()));
                    }
                    return Ok(());
                }
                let plain = match decrypt(&self.crypto, &key, &record) {
                    Ok(p) => p,
                    Err(e) => {
                        self.invalid += 1;
                        v.decoder = media::Video::new();
                        v.wait_key = true;
                        v.parameters = [None, None];
                        // v0.10.32: 首包 hex 取证（H3）——判手机推的是明文（RTP 头可读）
                        // 还是密文/异常数据。此前只有文字无 hex，无法区分明文/密文。
                        let head: String = record.iter().take(24).map(|b| format!("{b:02x}")).collect();
                        log_line(&mut self.log, &format!("video decrypt error: {e} ({}B) head={head}", record.len()));
                        return Ok(());
                    }
                };
                if plain.len() > MAX_VIDEO - 1024 {
                    self.invalid += 1;
                    v.decoder = media::Video::new();
                    v.wait_key = true;
                    v.parameters = [None, None];
                    return Ok(());
                }
                let units = match nal_units(&plain) {
                    Some(u) => u,
                    None => {
                        self.invalid += 1;
                        v.decoder = media::Video::new();
                        v.wait_key = true;
                        v.parameters = [None, None];
                        return Ok(());
                    }
                };
                let key_frame = units.iter().any(|u| u[0] & 31 == 5);
                for unit in &units {
                    let kind = unit[0] & 31;
                    if matches!(kind, 7 | 8) && unit.len() <= 32768 {
                        let mut parameter = vec![0, 0, 0, 1];
                        parameter.extend(*unit);
                        v.parameters[(kind - 7) as usize] = Some(parameter);
                    }
                }
                let frame = if key_frame {
                    match (&v.parameters[0], &v.parameters[1]) {
                        (Some(sps), Some(pps)) => {
                            let mut out = sps.clone();
                            out.extend(pps);
                            out.extend(&plain);
                            out
                        }
                        _ => {
                            // v0.10.33（B1）: SPS/PPS 未齐的关键帧不可用——置 wait_key
                            // 等待手机下一个带 SPS/PPS 的 IDR；原实现不置位，后续 P 帧
                            // 直通解码器（无 SPS）→ 花屏/绿块。
                            v.wait_key = true;
                            return Ok(());
                        }
                    }
                } else {
                    plain
                };
                if frame.len() > MAX_VIDEO {
                    self.invalid += 1;
                    v.decoder = media::Video::new();
                    v.wait_key = true;
                    v.parameters = [None, None];
                    return Ok(());
                }
                if v.wait_key && !key_frame {
                    self.invalid += 1;
                    return Ok(());
                }
                v.wait_key = false;
                self.video_frames += 1;
                if key_frame { self.key_frames += 1; }
                if self.media_out.len() >= MEDIA_QUEUE { self.media_out.pop_front(); }
                self.media_out.push_back(MediaEvent::Video { data: frame, key: key_frame, pts: now_us() });
            }
            Ok(())
    }

    pub fn feed(&mut self, id: u32, data: &[u8]) -> Result<Option<Vec<u8>>> {
        let reply: Vec<u8> = if self.nearby.contains_key(&id) {
            let c = self.nearby.get_mut(&id).expect("checked nearby key");
            let mut out = Vec::new();
            for frame in c.decoder.feed(data)? {
                log_line(&mut self.log, &format!("nearby frame in: kind={} payload={}B {}", frame.kind, frame.payload.len(), super::hex(&frame.payload)));
                let r = c.negotiator.respond(&frame, &mut self.resource)?;
                if let Some(r) = r {
                    log_line(&mut self.log, &format!("nearby respond: kind={} -> {}B {}", frame.kind, r.len(), super::hex(&r)));
                    out.extend(Frame { kind: frame.kind, flags: 0, options: vec![], payload: r }.encode(Format::Nearby)?);
                }
                for (k, v) in c.negotiator.pending() {
                    log_line(&mut self.log, &format!("nearby pending: kind={} -> {}B {}", k, v.len(), super::hex(&v)));
                    out.extend(Frame { kind: k, flags: 0, options: vec![], payload: v }.encode(Format::Nearby)?);
                }
                for (k, v) in self.resource.pending() {
                    out.extend(Frame { kind: k, flags: 0, options: vec![], payload: v }.encode(Format::Nearby)?);
                }
                if self.resource.credentials_sent {
                    self.phase = "credentials_sent".into();
                    let tag = if self.hotspot_set { "REAL" } else { "PLACEHOLDER" };
                    log_line(&mut self.log, &format!("hotspot credentials sent to phone ({tag})"));
                }
            }
            out
        } else if self.business.as_ref().is_some_and(|b| b.id == id) {
            let b = self.business.as_mut().expect("checked business key");
            let mut out = Vec::new();
            for envelope in b.stream.feed(data)? {
                let envelope_bytes = envelope.to_string();
                // v0.10.9: 打印完整信封（认证成功后手机 59B 帧 oper_type 曾触发 invalid auth sequence）
                log_line(&mut self.log, &format!("business envelope: {}", envelope_bytes));
                let (operation, inner) = json::envelope(envelope_bytes.as_bytes(), b.peer_seen)?;
                if operation == 4 {
                    // v0.10.11: 荣耀 needReconnect 业务通知（oper_type=4 无 data），仅记录不参与认证。
                    log_line(&mut self.log, "business notice oper_type=4 (needReconnect)");
                    continue;
                }
                if operation == 1 {
                    let peer = inner.get("deviceId").and_then(Value::as_str).ok_or("peer identity absent")?.to_owned();
                    // v0.10.75: has_pin 必须镜像手机发来的值，不能硬编码 true。
                    // 手机 has_pin=false 表示"我已保存这台车机的配对凭据，走已配对直连"；
                    // 我们回 true 等于宣称"我不记得你"，手机会立刻退回 PIN 配对流程
                    // （1111(44) 第 42 行在同一设备上重发 has_pin=true 即此），双方状态
                    // 错位 → HiChain errorCode:1 → 只能靠"移除设备"重置后重新配对。
                    let peer_has_pin = inner.get("has_pin").and_then(Value::as_bool).unwrap_or(true);
                    log_line(&mut self.log, &format!("auth identity: peer has_pin={peer_has_pin} -> reply has_pin={peer_has_pin}"));
                    let runtime = ensure_runtime(&mut self.runtime, &self.auth_library, &self.store_path, &self.identity.device_id)?;
                    let mut session = AuthSession::new(runtime, &self.own, &peer, &self.identity.pin, 2)
                        .map_err(|e| format!("HiChain session: {e}"))?;
                    // v0.10.77: 1111(47) 第 152 行 authenticate_peer 已返回 code=0、pending=1，
                    // 但第 155 行立刻 key summary=none、认证失败。原因是发送顺序：
                    // 上一版把这条"我方认证挑战（oper_type:3）"直接推进 out，排在下面的
                    // identity handshake（oper_type:1）之前。手机先收到 3 却还没收到 1，
                    // 状态机错位，随后它发来的 message:17 自然对不上。
                    // 正确顺序：先 identity handshake，再发认证挑战。
                    let mut auth_pending: Vec<Vec<u8>> = Vec::new();
                    if !peer_has_pin {
                        match session.start(true) {
                            Ok((code, pending)) => {
                                log_line(&mut self.log, &format!(
                                    "auth paired mode: authenticate_peer code={code} pending={}", pending.len()));
                                // v0.10.78: 1111(48) 证明发送顺序已修好（挑战排在握手之后发出），
                                // 手机也确实回了 message:17，但 C 层立刻 key summary=none 判失败。
                                // 现有日志只知道"发了 1 个包"，看不到包里的 operationCode /
                                // keyLength / peerAuthId —— 而这三项正是 PAKE 阶段对账的全部依据。
                                // 这里把每个待发包原文（截断）打出来，下一轮就能直接判断
                                // 是我们发的阶段号错、还是手机回的阶段号错。
                                for packet in &pending {
                                    let head: String = std::str::from_utf8(packet)
                                        .map(|s| s.chars().take(260).collect::<String>())
                                        .unwrap_or_else(|_| "（非 UTF-8 负载）".into());
                                    log_line(&mut self.log, &format!("auth challenge payload: {head}"));
                                }
                                auth_pending = pending;
                            }
                            // 已配对入口不可用时降级回 PIN 语义。
                            // v0.10.83 自检修复：原来这里只打了一行"降级 PIN 语义"的日志，
                            // 行为上什么都没做 —— auth_pending 保持空，我们照样发出一个不含任何
                            // 认证内容的 identity 握手，手机等不到挑战只能再判一次失败。
                            // "降级"必须真的把 start_pake 跑起来，否则日志在撒谎。
                            Err(e) => {
                                log_line(&mut self.log, &format!(
                                    "auth paired mode: authenticate_peer failed: {e}，降级走 start_pake"));
                                match session.start(false) {
                                    Ok((code2, pending2)) => {
                                        log_line(&mut self.log, &format!(
                                            "auth pin mode(降级): start_pake code={code2} pending={}", pending2.len()));
                                        for packet in &pending2 {
                                            let head: String = std::str::from_utf8(packet)
                                                .map(|s| s.chars().take(260).collect::<String>())
                                                .unwrap_or_else(|_| "（非 UTF-8 负载）".into());
                                            log_line(&mut self.log, &format!("auth pin challenge payload: {head}"));
                                        }
                                        auth_pending = pending2;
                                    }
                                    Err(e2) => log_line(&mut self.log, &format!(
                                        "auth pin mode(降级): start_pake failed: {e2}")),
                                }
                            }
                        }
                    } else {
                        // v0.10.81: PIN 分支原来只打了一行日志，**没有真正启动 PAKE**。
                        // .76 把这里改成"只在 has_pin=false 时 start(true)"，顺带把 PIN 分支的
                        // start 丢了——手机发 has_pin:true 时我们什么都不做，等它发 PIN 报文，
                        // 而 C 层的 PAKE 状态机根本没起来，必然失败。
                        // 1111(49) 第 185 行手机退回 PIN 流程就是这个现场。
                        match session.start(false) {
                            Ok((code, pending)) => {
                                log_line(&mut self.log, &format!(
                                    "auth pin mode: start_pake code={code} pending={}", pending.len()));
                                for packet in &pending {
                                    let head: String = std::str::from_utf8(packet)
                                        .map(|s| s.chars().take(260).collect::<String>())
                                        .unwrap_or_else(|_| "（非 UTF-8 负载）".into());
                                    log_line(&mut self.log, &format!("auth pin challenge payload: {head}"));
                                }
                                auth_pending = pending;
                            }
                            Err(e) => log_line(&mut self.log, &format!(
                                "auth pin mode: start_pake failed: {e}")),
                        }
                    }
                    b.session = Some(session);
                    b.peer_seen = true;
                    b.generation = b.generation.checked_add(1).ok_or("auth generation exhausted")?;
                    let details = value!({
                        "deviceId": self.own, "devicename": self.identity.name,
                        "has_pin": peer_has_pin, "usb_connection": false,
                        "CONNECT_ABILITY_KEY": "1", "CAR_MODE_ID": self.model,
                    });
                    let reply = value!({
                        "version": "A_0", "discover_type": 1, "oper_type": 1,
                        "data": details.to_string(), "usb_connection": false,
                    });
                    log_line(&mut self.log, "auth identity handshake answered");
                    out.extend(reply.to_string().as_bytes());
                    // v0.10.77: 身份握手先落地，随后才把认证挑战交给手机。
                    for packet in auth_pending {
                        match std::str::from_utf8(&packet) {
                            Ok(p) => {
                                log_line(&mut self.log, &format!(
                                    "auth challenge queued after handshake (oper_type=3, {}B)", packet.len()));
                                let reply = value!({
                                    "version": "A_0", "discover_type": 1, "oper_type": 3,
                                    "data": p, "usb_connection": false,
                                });
                                out.extend(reply.to_string().as_bytes());
                            }
                            // v0.10.79: 旧写法用 if let Ok，非 UTF-8 的包会被静默丢掉。
                            // 认证包少发一条必然导致对端状态错位，而日志里没有任何痕迹——
                            // 排查时会被误判成"手机没回"。这里必须留证。
                            Err(_) => log_line(&mut self.log, &format!(
                                "auth challenge dropped: 负载非 UTF-8（{}B）", packet.len())),
                        }
                    }
                    continue;
                }
                let session = b.session.as_mut().ok_or("authentication before identity")?;
                let (_code, packets) = session.receive(inner.to_string().as_bytes())
                    .map_err(|e| format!("HiChain receive: {e}"))?;
                // v0.10.78: 把 receive 的处理结果与 C 层返回码打出来。
                // 1111(48) 第 176–177 行是"手机发 message:17 operationCode=2 → 立刻 failed"，
                // 但没有 C 层的 code/results，无法区分是阶段号不匹配还是 PAKE 数学失败。
                log_line(&mut self.log, &format!(
                    "auth receive: code={_code} out={} results={:?}",
                    packets.len(), session.results()));
                // v0.10.80: 先下发 C 层产出的包，再判失败——顺序反了就是 49 号日志的现场。
                // 1111(49) 第 178 行是 `out=1 results=[2, 1]`：C 层明明已经生成了响应包，
                // 但旧代码一看到 results 里有个 1 就先 return Err，把这一包原地扔掉了。
                // 手机在等这条响应，等不到就只有 5 秒后原包重发（第 182 行），
                // 然后再失败一次——看起来永远连不上，实际是我们自己把回话吞了。
                let mut sent = 0usize;
                for packet in packets {
                    let parsed = json::parse(&packet)?;
                    if !parsed.is_object() { return Err("invalid native response".into()); }
                    let p = std::str::from_utf8(&packet).map_err(|_| "invalid native text")?;
                    let reply = value!({
                        "version": "A_0", "discover_type": 1, "oper_type": 3,
                        "data": p, "usb_connection": false,
                    });
                    out.extend(reply.to_string().as_bytes());
                    sent += 1;
                }
                if session.results().contains(&1) {
                    let input = inner.to_string();
                    let head: String = input.chars().take(420).collect();
                    log_line(&mut self.log, &format!("auth receive input: {head}"));
                    // v0.10.76: 失败也要把当前 key 摘要打出来——用它和上次配对成功时的
                    // 摘要对比，就能判断是 keystore 里凭据与手机不匹配，还是 PAKE 入口选错。
                    let summary = session.key_summary().ok().flatten()
                        .map(|(h, n)| format!("{h}/{n}B")).unwrap_or_else(|| "none".into());
                    log_line(&mut self.log, &format!(
                        "auth failed(code=1) after sending {sent} packets, key summary={summary}"));
                    // 只有一条响应都没能发出时才真的中止；已经回了话就交给手机决定下一步。
                    // results 里的 1 在 out>0 时多半表示"本阶段需要对端再确认"，不是终态。
                    if sent == 0 {
                        return Err("HiChain authentication failed".into());
                    }
                }
                let key = session.key_for_bridge();
                let authenticated = session.results().contains(&0) && key.is_some();
                if authenticated {
                    if let Some(k) = key { self.session_key = Some(k); }
                    self.resource.authenticated = true;
                    self.phase = "authenticated".into();
                    // v0.10.76: 记下本次协商出的密钥摘要，供下次重连失败时对照。
                    let summary = session.key_summary().ok().flatten()
                        .map(|(h, n)| format!("{h}/{n}B")).unwrap_or_else(|| "none".into());
                    log_line(&mut self.log, &format!(
                        "HiChain authentication succeeded (PAKE/STS), session key stored: {summary}"));
                }
            }
            out
        } else if self.data_id == Some(id) {
            if self.data_port_sent { return Err("duplicate data-port negotiation".into()); }
            let mut decoder = Decoder::new(Format::Module);
            let frames = decoder.feed(data)?;
            if frames.len() != 1 || frames[0].kind != 1 || frames[0].payload != vec![0; 16] {
                return Err("unsupported data-port negotiation".into());
            }
            self.data_port_sent = true;
            let control_port = self.resource.offer().port + 2;
            // v0.10.14: 原实现用 4 字节 BE 端口（backend.rs:322，18B payload）；
            // dmsdp_wire.py:80 实测复刻为 2 字节网络序端口（16B payload）。
            // v0.10.13 实测：手机连 4006 完成协商后未连 4007（10s 等超时），疑似不认 18B。
            // 改 2B 端口格式。
            let mut payload = vec![0];
            payload.extend((control_port as u16).to_be_bytes());
            payload.extend([0; 13]);
            log_line(&mut self.log, "data port negotiated -> control port");
            Frame { kind: 1, flags: 0, options: vec![], payload }.encode(Format::Module)?
        } else if self.sight.as_ref().is_some_and(|c| c.id == id) {
            // v0.10.70: 分支体包成块，先把 sight 的可变借用还回去，再处理交织视频帧
            // （feed_video 要 &mut self，与 c.session 的借用不能同时存在）。
            let (out, interleaved) = {
            let c = self.sight.as_mut().ok_or("sight channel absent")?;
            // v0.10.26: sight 分支按 id 精确匹配——原 control 分支无 id 过滤，手机回
            // ANNOUNCE 200 被 feed(6) 误判 stale control channel 丢弃（1111(16)）；
            // 原 sight stale 检查会拦截 video/audio 通道（id 不同）。filter 保证
            // id 匹配后才处理，不匹配继续落到 control/video/audio。
            // v0.10.67: sight 入口取证——1111(37) 收到 307B 首帧后，engine 日志里
            // 既没有 hisight event 也没有 receive error，无法判断是没进本分支还是
            // 提前返回。这里无条件打长度+前 8 字节，先确认数据确实到了 sight。
            let in_head: String = data.iter().take(8).map(|b| format!("{b:02x}")).collect();
            log_line(&mut self.log, &format!("sight feed in {}B head={in_head}", data.len()));
            let (events, plaintexts, interleaved) = match c.session.receive(data, true) {
                Ok(v) => v,
                Err(e) => {
                    // v0.10.26d: 取证——协商失败时打第一包原始 hex，定论手机回包
                    // 是明文 RTSP（头可见 "RTSP"/"OPTIONS"）还是加密帧（随机字节）。
                    let head: String = data.iter().take(96).map(|b| format!("{b:02x}")).collect();
                    log_line(&mut self.log, &format!("sight receive error: {e} ({}B) head={head}", data.len()));
                    return Err(e.into());
                }
            };
            let mut out = Vec::new();
            for p in plaintexts {
                // Plaintext bodies are only captured for diagnostics; reply is
                // generated by the session state machine below.
                let _ = p;
            }
            for e in &events {
                if let Some(p) = e["media_port"].as_u64().map(|v| v as u16).filter(|p| *p != 0) {
                    if self.media_port != Some(p) {
                        self.media_port = Some(p);
                        log_line(&mut self.log, &format!("HiSight media endpoint discovered port={p}"));
                    }
                }
                // v0.10.32: hisight 事件全量取证（H1）——parameter_names 确认手机
                // SET_PARAMETER 是否携带 his_presentation_url（决定 PLAY target）；
                // play_acknowledged 确认手机是否回 PLAY 200；加密切换/能力应答一并落盘。
                let mut hf: Vec<String> = Vec::new();
                // v0.10.42: 白名单补齐 setup_transport / play_session——v0.10.41 新增的
                // 两个取证事件此前不在过滤器内，从未落盘（1111(26) 日志缺该行）。
                for k in ["peer_url","setup_requested","setup_no_server_port","unhandled_request","parameter_names","hisight_encryption","capabilities_replied","peer_announce_replied","play_acknowledged","play_target","setup_transport","play_session"] {
                    if let Some(v) = e.get(k) { hf.push(format!("{k}={v}")); }
                }
                if !hf.is_empty() {
                    log_line(&mut self.log, &format!("hisight event: {}", hf.join(" ")));
                }
            }
            let state = c.session.state();
            if let Some(p) = state["input_endpoint"].as_u64().map(|v| v as u16).filter(|p| *p != 0) {
                if self.input_port != Some(p) {
                    self.input_port = Some(p);
                    log_line(&mut self.log, &format!("HiSight input endpoint discovered port={p}"));
                }
            } else if self.input_port.is_none() {
                // v0.10.46: SETUP 200 的 Transport 不带 remotectl_port 时（或该轮 SETUP 未完成），
                // 输入端口永远为空 → Kotlin startInput 不执行 → 触摸全部落进 pendingInput 被丢弃。
                // 手机常把 remotectl 端口分配在媒体端口相邻位置，这里按 media_port+1 试探性兜底，
                // 端口错只会连不上（不影响视频/音频），日志明确标注以便下一轮核对。
                if let Some(m) = self.media_port {
                    let guess = m.saturating_add(1);
                    self.input_port = Some(guess);
                    log_line(&mut self.log, &format!("HiSight input endpoint 兜底 port={guess}（Transport 无 remotectl_port，按 media_port+1 试探）"));
                }
            }
            // v0.10.49: RTCP 端点——手机在 SETUP 200 的 Transport 里给了 rtcp_port=37823 这类端口。
            // 1111(30) 三段会话全部在出画面 2~2.5 秒后由手机主动断链（business/video/audio
            // 依次 closed），而每次断前都只有 RTP 单向、无任何 RTCP 回包。导出给 Kotlin 起保活。
            if let Some(p) = state["rtcp_endpoint"].as_u64().map(|v| v as u16).filter(|p| *p != 0) {
                if self.rtcp_port != Some(p) {
                    self.rtcp_port = Some(p);
                    log_line(&mut self.log, &format!("HiSight rtcp endpoint discovered port={p}"));
                }
            }
            if state["peer_teardown"] == true { self.peer_teardown = true; }
            // After SETUP negotiation, actively PLAY (mirrors backend.rs).
            // v0.10.70: 交织模式（server_port=0）没有独立媒体端口，但 PLAY 仍然必须发，
            // 否则手机不会往 RTSP 连接里推交织帧。所以判据改成「SETUP 已回 200」。
            if (self.media_port.is_some() || state["setup_ok"] == true) && !self.media_play_queued {
                let seq = c.session.request("PLAY")?;
                self.media_play_queued = true;
                for p in c.session.pending() { out.extend(p); }
                log_line(&mut self.log, &format!("HiSight PLAY requested seq={seq}"));
            } else {
                for p in c.session.pending() { out.extend(p); }
            }
            // v0.10.67: 回包取证——确认引擎到底有没有产出 SETUP/200 之类的报文。
            // 1111(37) 首帧 307B 之后主界面日志没有任何回包痕迹，只能先确认这条。
            if !out.is_empty() {
                let oh: String = out.iter().take(16).map(|b| format!("{b:02x}")).collect();
                log_line(&mut self.log, &format!("sight reply out {}B head={oh}", out.len()));
            } else {
                log_line(&mut self.log, "sight reply out 0B（引擎未产出回包）");
            }
            (out, interleaved)
            };
            // v0.10.70: RTSP 交织帧（$ 0x24 channel len payload）。手机回的 Transport 是
            // `RTP/AVP/TCP;unicast;server_port=0`（1111(40) 实证）时视频走这里，不再有独立
            // 视频端口。channel 0 = RTP 视频，channel 1 = RTCP。
            for (channel, payload) in interleaved {
                self.interleaved_frames += 1;
                if self.interleaved_frames <= 5 || self.interleaved_frames % 100 == 0 {
                    log_line(&mut self.log, &format!("sight interleaved ch={channel} {}B (n={})", payload.len(), self.interleaved_frames));
                }
                if channel == 0 {
                    self.feed_video(&payload)?;
                }
            }
            out
        } else if let Some(c) = self.control.as_mut().filter(|c| c.id == id) {
            // v0.10.26: control 分支同样按 id 精确匹配——video/audio 通道的 feed
            // （id≠control.id）不再误报 stale control channel。
            // v0.10.20: 取证——DMSDP receive 首个错误直接落引擎日志（此前只有失败后
            // heartbeat 刷屏的 requires reset，真正导致 failed 的首错误被静默吞掉）。
            // v0.10.29: 全量 DMSDP events 取证日志——v0.10.28 只打 audio_* 键，
            // 1111(20) 无 setup_sent/audio_negotiated 且手机从未发 speaker OPTIONS，
            // 唯一嫌疑是服务宣告链（cmd104 mask→service_announced）未走通，但
            // service_request_mask/service_announced 事件没打日志无法定论。全量打。
            let (events, plaintexts) = match c.session.receive(data, now_us(), false) {
                Ok(v) => v,
                Err(e) => {
                    log_line(&mut self.log, &format!("control receive error: {e} ({}B)", data.len()));
                    return Err(e.into());
                }
            };
            for e in &events {
                // 结构化键直接打印；未知键打印 JSON 全文（限 300B 防刷屏）。
                let mut fields: Vec<String> = Vec::new();
                for k in ["negotiated", "clock_initialized", "device_info_sent",
                          "service_request_mask", "device_command", "hisight_endpoint", "binary",
                          "service_announced", "audio_ready", "audio_negotiated", "audio_setup_sent",
                          "audio_stopped", "microphone_ready", "microphone_stopped",
                          "audio_negotiated_service", "encrypted"] {
                    if let Some(v) = e.get(k) {
                        fields.push(format!("{k}={v}"));
                    }
                }
                // v0.10.31 自检修复（A1）: keepalive 每秒 1 条刷屏会挤掉早期宣告链证据
                // （service_request_mask/service_announced/binary），降到每 20 次打 1 条；
                // 宣告/音频协商键不受影响，始终全量打印。
                // v0.10.34: keepalive 事件不落 raw 兜底——原实现每 20 次才打结构化键，
                // 但 fields 为空时 735 行 raw 兜底仍每秒打 1 条 JSON（1111(22) 引擎段
                // 30 条 keepalive raw 把 audio frame reject/宣告链取证挤掉，音频无声音
                // 无法判因）。keepalive 事件除 %20==1 外直接跳过，不再走 raw。
                if let Some(v) = e.get("keepalive_received") {
                    self.keepalive_seen += 1;
                    if self.keepalive_seen % 20 == 1 {
                        fields.push(format!("keepalive_received={v}"));
                    }
                    continue;
                }
                for k in ["service", "port", "session", "module", "data_type", "body_bytes",
                          "trailing_bytes", "trailing_hex", "rate", "channels", "codec"] {
                    if let Some(v) = e.get(k) { fields.push(format!("{k}={v}")); }
                }
                if !fields.is_empty() {
                    log_line(&mut self.log, &format!("dmsdp event: {}", fields.join(" ")));
                } else {
                    let raw = e.to_string();
                    log_line(&mut self.log, &format!("dmsdp event raw: {}", if raw.len() > 300 { &raw[..300] } else { &raw }));
                }
            }
            let mut out = Vec::new();
            for p in plaintexts { out.extend(p); }
            for p in c.session.pending() { out.extend(p); }
            let state = c.session.state();
            if state["negotiated"] == true && !c.negotiated {
                c.negotiated = true;
                self.phase = "dmsdp_negotiated".into();
                log_line(&mut self.log, "DMSDP negotiated (CryptoVer/CryptoSwitch)");
            }
            if let Some(p) = state["media_port"].as_u64().map(|v| v as u16).filter(|p| *p != 0) {
                if self.rtsp_port != Some(p) {
                    self.rtsp_port = Some(p);
                    log_line(&mut self.log, &format!("HiSight RTSP endpoint discovered port={p}"));
                }
            }
            out
        } else if self.video_id == Some(id) {
            // v0.10.70: 视频解析抽成 feed_video——交织模式（视频混在 RTSP 连接里）
            // 与独立端口模式共用同一套 RTP/解密/NAL 逻辑。
            self.feed_video(data)?;
            Vec::new()
        } else if self.audio_id == Some(id) {
            let a = self.audio.as_mut().ok_or("audio channel absent")?;
            let key = self.session_key.clone().ok_or("session key missing")?[..16].to_vec();
            // v0.10.28: 取证——音频 UDP 帧失败分类日志（前 5 次含首包 hex）。
            // 1111(19) 音频PCM 0KB：需区分「手机没发」(无 feed)、「前缀/长度不符」、
            // 「解密失败」、「RTP 解析失败」——每类都在这里留证据。
            let diag = |engine: &mut Engine, why: &str, data: &[u8]| {
                engine.invalid += 1;
                // v0.10.31 自检修复（B8）: 30s 窗口重置——原实现 5 次后永久静默，
                // 长会话后期音频问题无日志；每个 30s 窗口仍只打前 5 次防刷屏。
                let now = crate::monotonic_millis();
                if engine.audio_diag >= 5 && now.saturating_sub(engine.audio_diag_last_ms) > 30_000 {
                    engine.audio_diag = 0;
                }
                if engine.audio_diag < 5 {
                    engine.audio_diag += 1;
                    engine.audio_diag_last_ms = now;
                    let head: String = data.iter().take(16).map(|b| format!("{b:02x}")).collect();
                    log_line(&mut engine.log, &format!("audio frame reject: {why} ({}B) head={head}", data.len()));
                }
            };
            if data.len() < 20 || data[0] != 0xab {
                diag(self, "not 0xab prefix", data);
                return Ok(None);
            }
            let declared = u16::from_be_bytes([data[1], data[2]]) as usize;
            if declared != data.len() - 3 {
                diag(self, &format!("length mismatch declared={declared} actual={}", data.len() - 3), data);
                return Ok(None);
            }
            let decoded = match decrypt(&self.crypto, &key, &data[3..]) {
                Ok(d) => d,
                Err(e) => { diag(self, &format!("decrypt failed {e}"), data); return Ok(None); }
            };
            let frames = match a.receive(&decoded) {
                Ok(f) => f,
                Err(e) => { diag(self, &format!("rtp parse failed {e}"), data); return Ok(None); }
            };
            for frame in frames {
                self.audio_frames += 1;
                if self.media_out.len() >= MEDIA_QUEUE { self.media_out.pop_front(); }
                self.media_out.push_back(MediaEvent::Audio {
                    data: frame.aac.data, rate: frame.aac.rate, channels: frame.aac.channels, pts: now_us(),
                });
            }
            Vec::new()
        } else {
            return Err("unknown channel".into());
        };
        if reply.len() > MAX_REPLY { return Err("reply exceeds limit".into()); }
        Ok((!reply.is_empty()).then_some(reply))
    }

    /// DMSDP heartbeat — called by the Kotlin layer every ~1 s while the
    /// control channel is negotiated.
    pub fn heartbeat(&mut self, id: u32) -> Result<Option<Vec<u8>>> {
        let c = self.control.as_mut().filter(|c| c.id == id).ok_or("stale control channel")?;
        if !c.negotiated { return Ok(None); }
        // v0.10.20: DMSDP 会话 failed 后静默（返回 None），避免每秒 heartbeat 刷
        // "DMSDP session requires reset" 淹没真正导致 failed 的首错误（1111(8) 刷屏 90+ 行）。
        let mut out = match c.session.heartbeat() {
            Ok(o) => o,
            Err(_) => return Ok(None),
        };
        for p in c.session.pending() { out.extend(p); }
        Ok(Some(out))
    }

    pub fn close(&mut self, id: u32) -> Result<()> {
        if self.nearby.remove(&id).is_some() {
            log_line(&mut self.log, "nearby channel closed");
        } else if self.business.as_ref().is_some_and(|b| b.id == id) {
            self.business.take();
            log_line(&mut self.log, "business channel closed");
        } else if let Some(c) = self.control.as_mut().filter(|c| c.id == id) {
            let _ = c.session.stop_audio();
            self.control = None;
            log_line(&mut self.log, "control channel closed");
        } else if let Some(c) = self.sight.as_mut().filter(|c| c.id == id) {
            let _ = c.session.teardown();
            self.sight = None;
            log_line(&mut self.log, "sight channel closed");
        } else if self.data_id == Some(id) {
            self.data_id = None;
            self.data_port_sent = false;
            log_line(&mut self.log, "data channel closed");
        } else if self.video_id == Some(id) {
            self.video_id = None;
            self.video = None;
            log_line(&mut self.log, "video channel closed");
        } else if self.audio_id == Some(id) {
            self.audio_id = None;
            self.audio = None;
            log_line(&mut self.log, "audio channel closed");
        }
        Ok(())
    }

    pub fn status(&self) -> Value {
        value!({
            "phase": self.phase,
            "authenticated": self.resource.authenticated,
            "negotiated": self.resource.negotiated,
            "credentials_sent": self.resource.credentials_sent,
            "hotspot_set": self.hotspot_set,
            "data_port_sent": self.data_port_sent,
            "rtsp_port": self.rtsp_port,
            "media_port": self.media_port,
            "input_port": self.input_port,
            "rtcp_port": self.rtcp_port,
            "audio_port": self.audio_port,
            "peer_teardown": self.peer_teardown,
            "stats": {
                "video_frames": self.video_frames,
                "key_frames": self.key_frames,
                "audio_frames": self.audio_frames,
                "invalid": self.invalid,
                "interleaved_frames": self.interleaved_frames,
                "setup_ok": self.sight.as_ref().map(|c| c.session.setup_ok()).unwrap_or(false),
                "media_queued": self.media_out.len(),
            },
            "channels": {
                "nearby": self.nearby.len(),
                "business": self.business.is_some(),
                "control": self.control.is_some(),
                "sight": self.sight.is_some(),
                "video": self.video.is_some(),
                "audio": self.audio.is_some(),
            },
            "log": self.log.iter().cloned().collect::<Vec<_>>(),
            "core": crate::PROTOCOL_CORE_VERSION,
        })
    }

    /// v0.10.35: 重发 HiSight PLAY——PLAY 后 5s 视频仍 0 帧时由 Kotlin 定时调用
    /// （1111(19) 多次重试才成功的机制：手机媒体会话可能晚于首次 PLAY 就绪；
    /// 23 轮 play_acknowledged=true 但手机 0 推流）。返回待写回 sight RTSP
    /// socket 的记录；sight 未开/会话失败返回 Err。
    pub fn request_play(&mut self, id: u32) -> Result<Vec<u8>> {
        let c = self.sight.as_mut().filter(|c| c.id == id).ok_or("stale sight channel")?;
        c.session.request("PLAY")?;
        let mut out = Vec::new();
        for p in c.session.pending() { out.extend(p); }
        Ok(out)
    }

    /// Record a protocol error into the visible engine log. The JNI bridge
    /// calls this when `feed`/`heartbeat`/`send_input` returns Err, so the
    /// failure reason reaches the car UI instead of being swallowed by
    /// eprintln (previously the screen showed "已停止" with no error text).
    pub fn log_error(&mut self, error: &str) {
        log_line(&mut self.log, &format!("协议错误: {error}"));
    }
}
