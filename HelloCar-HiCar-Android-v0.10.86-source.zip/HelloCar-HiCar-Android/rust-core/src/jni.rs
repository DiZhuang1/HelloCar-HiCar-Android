//! Android JNI entry surface (M1/M2b) + C ABI for the HelloCar protocol core.
//!
//! M1 scope: `init` / `start` / `stop` / `status` / `self-check` plus a
//! C-ABI state callback.
//! M2b scope: Android session engine (Nearby/authentication/Resource/DMSDP
//! state machines) driven by the Kotlin platform layer over RFCOMM FE35/FE36
//! and TCP 4005/4006/4007, plus hotspot parameter back-fill
//! (`nativeSetHotspotInfo`) and the input-event stub (`nativeSendInput`).
//!
//! The auth library (`libhellocar_hichain.so`) is loaded by the Kotlin side
//! via `System.loadLibrary`; the engine dlopens it by soname inside the app
//! namespace (compiled-report §5 strategy, runtime-verified on device).

use std::collections::HashMap;
use std::ffi::{c_char, c_int, c_void, CStr, CString};
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool, Ordering};

use jni::objects::{GlobalRef, JClass, JObject, JString, JByteArray, JValue};
use jni::sys::{jint, jlong, jbyteArray};
use jni::JNIEnv;

use crate::hicar;

// ---------------------------------------------------------------------------
// v0.10.16: Rust panic 落盘。JNI 边界上的 panic 会 abort 进程，崩溃后可从
// filesDir/hellocar/hellocar_panic.txt 读取现场（与 Java 层 crash_java.txt
// 互补）。hook 进程级只装一次，目录由每次 nativeInit 刷新。
// ---------------------------------------------------------------------------
static PANIC_DIR: Mutex<Option<std::path::PathBuf>> = Mutex::new(None);
static HOOK_INSTALLED: AtomicBool = AtomicBool::new(false);

fn install_panic_hook(dir: &std::path::Path) {
    if let Ok(mut g) = PANIC_DIR.lock() {
        *g = Some(dir.to_path_buf());
    }
    if HOOK_INSTALLED.swap(true, Ordering::SeqCst) {
        return;
    }
    let default = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let payload = if let Some(s) = info.payload().downcast_ref::<&str>() {
            s.to_string()
        } else if let Some(s) = info.payload().downcast_ref::<String>() {
            s.clone()
        } else {
            "<?>".to_string()
        };
        let loc = info
            .location()
            .map(|l| format!("{}:{}:{}", l.file(), l.line(), l.column()))
            .unwrap_or_else(|| "-".into());
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_millis())
            .unwrap_or(0);
        let msg = format!("[{now}] PANIC: {payload}\n  at {loc}\n");
        if let Ok(g) = PANIC_DIR.lock() {
            if let Some(dir) = g.as_ref() {
                let _ = std::fs::write(dir.join("hellocar_panic.txt"), msg);
            }
        }
        default(info);
    }));
}

// ---------------------------------------------------------------------------
// Internal state
// ---------------------------------------------------------------------------
#[derive(Default)]
struct CoreState {
    initialized: bool,
    started: bool,
    auth_library: Option<String>,
    store_path: Option<String>,
    model: Option<String>,
    address: Option<String>,
    engine: Option<EngineGuard>,
    /// 初始化失败原因（nativeInit 各失败分支写入，nativeStatus 透出到 UI 排查）
    init_error: Option<String>,
    /// Initial frames produced by open(kind) and consumed once by nativeInitial.
    pending_initial: HashMap<u32, Vec<u8>>,
}

/// The engine holds the HiChain session (raw C handle) which is not `Send`;
/// the JNI mutex guarantees exclusive access, so transferring it between JNI
/// call sites (all under the same lock) is safe.
struct EngineGuard(Option<hicar::android_engine::Engine>);
unsafe impl Send for EngineGuard {}

static STATE: Mutex<Option<CoreState>> = Mutex::new(None);

type StateCallback = unsafe extern "C" fn(*const c_char);
static STATE_CALLBACK: Mutex<Option<StateCallback>> = Mutex::new(None);

/// Java media sinks registered by Kotlin (GlobalRefs; drained after each
/// nativeFeed call, outside the engine lock so Java callbacks never re-enter
/// the lock).
#[derive(Default, Clone)]
struct MediaSinks {
    frame: Option<GlobalRef>,
    audio: Option<GlobalRef>,
}
static MEDIA_SINKS: Mutex<Option<MediaSinks>> = Mutex::new(None);

fn drain_media(env: &mut JNIEnv, events: &[hicar::android_engine::MediaEvent]) {
    if events.is_empty() { return; }
    let sinks = MEDIA_SINKS.lock().ok().and_then(|g| g.as_ref().cloned());
    let Some(sinks) = sinks else { return; };
    for event in events {
        match event {
            hicar::android_engine::MediaEvent::Video { data, key, pts } => {
                if let Some(cb) = &sinks.frame {
                    if let Ok(arr) = env.byte_array_from_slice(data) {
                        let _ = env.call_method(cb, "onFrame", "(ZJ[B)V", &[
                            JValue::Bool(*key as u8),
                            JValue::Long(*pts as jlong),
                            JValue::Object(&arr),
                        ]);
                    }
                }
            }
            hicar::android_engine::MediaEvent::Audio { data, pts, .. } => {
                if let Some(cb) = &sinks.audio {
                    if let Ok(arr) = env.byte_array_from_slice(data) {
                        let _ = env.call_method(cb, "onAudio", "(J[B)V", &[
                            JValue::Long(*pts as jlong),
                            JValue::Object(&arr),
                        ]);
                    }
                }
            }
        }
    }
}

fn set_media_sink(frame: bool, env: &JNIEnv, cb: JObject) -> jint {
    let reference = if cb.is_null() {
        None
    } else {
        match env.new_global_ref(cb) {
            Ok(r) => Some(r),
            Err(_) => return -2,
        }
    };
    match MEDIA_SINKS.lock() {
        Ok(mut g) => {
            let sinks = g.get_or_insert_with(|| MediaSinks { frame: None, audio: None });
            if frame { sinks.frame = reference; } else { sinks.audio = reference; }
            0
        }
        Err(_) => -1,
    }
}

fn emit_state(event: &str) {
    let cb = STATE_CALLBACK.lock().ok().and_then(|g| *g);
    if let Some(cb) = cb {
        let json = format!(r#"{{"event":"{event}","core":"hellocar-android"}}"#);
        if let Ok(c) = CString::new(json) {
            unsafe { cb(c.as_ptr()) }
        }
    }
}

// ---------------------------------------------------------------------------
// Protocol-core self check (deterministic, no I/O)
// ---------------------------------------------------------------------------
fn self_check() -> Result<(), String> {
    if hicar::wire::crc16(b"123456789") == 0 {
        return Err("crc16 self-check failed".into());
    }
    // 注意：uint 编码上限为 28 bit（MAX_UINT = 0x0FFFFFFF）。
    // 原自检值 0x1234_5678 > MAX_UINT，wire::uint 直接返回 Err → nativeInit 恒为 -2。
    // 改用 0x0FFF_FFFF（28 位最大值）验证边界，往返通过即为编码正确。
    let u = hicar::wire::uint(0x0FFF_FFFF)?;
    if hicar::unhex(&hicar::hex(&u))? != u {
        return Err("uint round-trip failed".into());
    }
    let t = hicar::wire::tlv(3, b"hi")?;
    let parsed = hicar::wire::tlvs(&t)?;
    if parsed.len() != 1 || parsed[0].0 != 3 || parsed[0].1 != b"hi" {
        return Err("tlv round-trip failed".into());
    }
    // Android build: Offer::parse accepts RFC1918 private space (R1) and any
    // channel frequency (R2) instead of the fixed 192.168.49.x / 5745.
    let offer = serde_json::json!({
        "ssid": "HUAWEI-HiCar-1234",
        "bssid": "00:11:22:33:44:55",
        "password": "password123",
        "owner_ip": "192.168.100.1",
        "client_ip": "192.168.100.2",
        "port": 5678,
        "frequency": 5745,
    });
    hicar::session::Offer::parse(&offer).map_err(|e| format!("offer parse self-check failed: {e}"))?;
    Ok(())
}

fn read_cstr(p: *const c_char) -> Option<String> {
    if p.is_null() {
        None
    } else {
        unsafe { CStr::from_ptr(p) }.to_str().ok().map(str::to_owned)
    }
}

fn state_snapshot() -> String {
    let g = STATE.lock().unwrap_or_else(|e| e.into_inner());
    let s = g.as_ref();
    let engine_json = s.and_then(|s| s.engine.as_ref())
        .map(|e| e.0.as_ref().map(|e| e.status().to_string()).unwrap_or_else(|| "null".into()))
        .unwrap_or_else(|| "null".into());
    format!(
        r#"{{"initialized":{},"started":{},"auth_library":{},"store_path":{},"model":{},"address":{},"init_error":{},"engine":{},"version":"{}"}}"#,
        s.is_some_and(|s| s.initialized),
        s.is_some_and(|s| s.started),
        s.and_then(|s| s.auth_library.as_deref()).map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into()),
        s.and_then(|s| s.store_path.as_deref()).map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into()),
        s.and_then(|s| s.model.as_deref()).map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into()),
        s.and_then(|s| s.address.as_deref()).map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into()),
        s.and_then(|s| s.init_error.as_deref()).map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into()),
        engine_json,
        crate::PROTOCOL_CORE_VERSION,
    )
}

// ---------------------------------------------------------------------------
// C ABI (dlopen/dlsym friendly, stable contract for the Kotlin shim)
// ---------------------------------------------------------------------------

/// Returns a static version string pointer (never freed).
#[no_mangle]
pub extern "C" fn hellocar_abi_version() -> *const c_char {
    static VERSION: &[u8] = b"hellocar-android-core/0.1.0\0";
    VERSION.as_ptr() as *const c_char
}

/// Initialize the core. `auth_library`/`store_path` seed the HiChain runtime;
/// `model`/`address` seed the wire identity and BLE beacon.
/// Returns 0 on success; -1 invalid argument; -2 self-check failed;
/// -3 state lock error; -4 identity missing/invalid; -5 engine/crypto error.
#[no_mangle]
pub extern "C" fn hellocar_abi_init(
    auth_library: *const c_char,
    store_path: *const c_char,
    model: *const c_char,
    address: *const c_char,
) -> c_int {
    let (auth, store, model, address) = (
        read_cstr(auth_library),
        read_cstr(store_path),
        read_cstr(model),
        read_cstr(address),
    );
    if auth.is_none() || store.is_none() || model.is_none() || address.is_none() {
        return -1;
    }
    if let Err(_) = self_check() {
        return -2;
    }
    let (auth, store, model, address) = (auth.unwrap(), store.unwrap(), model.unwrap(), address.unwrap());
    let identity = match hicar::identity::Identity::load(&std::path::Path::new(&store).join("identity.json")) {
        Ok(id) => id,
        Err(_) => return -4,
    };
    let engine = match hicar::android_engine::Engine::new(identity, model.clone(), address.clone(), auth.clone(), store.clone()) {
        Ok(e) => EngineGuard(Some(e)),
        Err(_) => return -5,
    };
    if let Ok(mut g) = STATE.lock() {
        *g = Some(CoreState {
            initialized: true,
            started: false,
            auth_library: Some(auth),
            store_path: Some(store),
            model: Some(model),
            address: Some(address),
            engine: Some(engine),
            ..Default::default()
        });
    } else {
        return -3;
    }
    emit_state("init_ok");
    0
}

/// Start the projection session. Returns 0 on success; -1 not initialized.
#[no_mangle]
pub extern "C" fn hellocar_abi_start() -> c_int {
    let mut ok = false;
    if let Ok(mut g) = STATE.lock() {
        if let Some(s) = g.as_mut() {
            if s.initialized {
                s.started = true;
                ok = true;
            }
        }
    }
    if ok {
        emit_state("started");
        0
    } else {
        -1
    }
}

/// Stop the projection session. Idempotent. Returns 0.
#[no_mangle]
pub extern "C" fn hellocar_abi_stop() -> c_int {
    if let Ok(mut g) = STATE.lock() {
        if let Some(s) = g.as_mut() {
            s.started = false;
            if let Some(e) = s.engine.as_mut() {
                e.0 = None; // drop the session engine (closes HiChain sessions)
            }
        }
    }
    emit_state("stopped");
    0
}

/// Write a JSON status snapshot into `buffer` (NUL-terminated). Returns the
/// number of bytes written excluding the NUL; 0 if the buffer is too small.
#[no_mangle]
pub extern "C" fn hellocar_abi_status(buffer: *mut c_char, capacity: usize) -> c_int {
    if buffer.is_null() || capacity == 0 {
        return 0;
    }
    let json = state_snapshot();
    let bytes = json.as_bytes();
    let space = capacity - 1;
    let n = bytes.len().min(space);
    unsafe {
        std::ptr::copy_nonoverlapping(bytes.as_ptr(), buffer as *mut u8, n);
        *buffer.add(n) = 0;
    }
    n as c_int
}

/// Register an optional state callback (`fn(*const c_char)` receiving a JSON
/// event string; no ownership transfer). Pass NULL to clear. Returns 0.
#[no_mangle]
pub extern "C" fn hellocar_abi_set_state_callback(cb: Option<StateCallback>) -> c_int {
    if let Ok(mut g) = STATE_CALLBACK.lock() {
        *g = cb;
        0
    } else {
        -1
    }
}

// ---------------------------------------------------------------------------
// JNI surface (Java_* naming so System.loadLibrary finds them directly)
// ---------------------------------------------------------------------------

fn with_engine<F: FnOnce(&mut hicar::android_engine::Engine) -> Result<Vec<u8>, String>>(
    f: F,
) -> (jint, Vec<u8>) {
    let mut g = match STATE.lock() {
        Ok(g) => g,
        Err(_) => return (-3, Vec::new()),
    };
    let Some(state) = g.as_mut() else { return (-1, Vec::new()); };
    if !state.initialized { return (-1, Vec::new()); }
    let Some(guard) = state.engine.as_mut() else { return (-1, Vec::new()); };
    let Some(engine) = guard.0.as_mut() else { return (-1, Vec::new()); };
    match f(engine) {
        Ok(v) => (0, v),
        Err(e) => {
            eprintln!("[hellocar] engine error: {e}");
            // 透出到车机 UI 日志（nativeStatus().log 会渲染），避免"报错但看不到原因"
            engine.log_error(&e);
            (-2, Vec::new())
        }
    }
}

/// `external fun nativeInit(authLibrary: String, storePath: String, model: String, address: String): Int`
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeInit(
    mut env: JNIEnv,
    _class: JClass,
    auth_library: JString,
    store_path: JString,
    model: JString,
    address: JString,
) -> jint {
    let auth: Option<String> = env.get_string(&auth_library).ok().map(|v| v.into());
    let store: Option<String> = env.get_string(&store_path).ok().map(|v| v.into());
    let model: Option<String> = env.get_string(&model).ok().map(|v| v.into());
    let address: Option<String> = env.get_string(&address).ok().map(|v| v.into());
    let (auth, store, model, address) = match (auth, store, model, address) {
        (Some(a), Some(b), Some(c), Some(d)) => (a, b, c, d),
        _ => return -1,
    };
    install_panic_hook(std::path::Path::new(&store));
    if let Err(e) = self_check() {
        if let Ok(mut g) = STATE.lock() {
            let st = g.get_or_insert_with(CoreState::default);
            st.init_error = Some(format!("self_check failed: {e}"));
        }
        return -2;
    }
    let identity = match hicar::identity::Identity::load(&std::path::Path::new(&store).join("identity.json")) {
        Ok(id) => id,
        Err(e) => {
            if let Ok(mut g) = STATE.lock() {
                let st = g.get_or_insert_with(CoreState::default);
                st.init_error = Some(format!("identity load failed: {e}"));
            }
            return -4;
        }
    };
    let engine = match hicar::android_engine::Engine::new(identity, model.clone(), address.clone(), auth.clone(), store.clone()) {
        Ok(e) => EngineGuard(Some(e)),
        Err(e) => {
            if let Ok(mut g) = STATE.lock() {
                let st = g.get_or_insert_with(CoreState::default);
                st.init_error = Some(format!("engine init failed: {e}"));
            }
            return -5;
        }
    };
    if let Ok(mut g) = STATE.lock() {
        *g = Some(CoreState {
            initialized: true,
            started: false,
            auth_library: Some(auth),
            store_path: Some(store),
            model: Some(model),
            address: Some(address),
            engine: Some(engine),
            ..Default::default()
        });
    } else {
        return -3;
    }
    emit_state("init_ok");
    0
}

/// `external fun nativeStart(): Int`
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeStart(_env: JNIEnv, _class: JClass) -> jint {
    hellocar_abi_start()
}

/// `external fun nativeStop(): Int`
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeStop(_env: JNIEnv, _class: JClass) -> jint {
    hellocar_abi_stop()
}

/// `external fun nativeStatus(): String` — JSON snapshot incl. engine state.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeStatus(env: JNIEnv, _class: JClass) -> jni::sys::jstring {
    let json = state_snapshot();
    match env.new_string(json) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

// ---------------------------------------------------------------------------
// M2b JNI surface — Android session engine channels
// ---------------------------------------------------------------------------

/// `external fun nativeOpenChannel(kind: Int): Int` — channel kinds:
/// 0 NearbyRfcomm(FE35) / 1 NearbyTcp(4005) / 2 Business(FE36) / 3 Data(4006) / 4 Control(4007).
/// Returns channel id (>=0) or a negative error code; initial bytes (if any)
/// are fetched with nativeInitial(id).
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeOpenChannel(
    _env: JNIEnv, _class: JClass, kind: jint,
) -> jint {
    let mut g = match STATE.lock() {
        Ok(g) => g,
        Err(_) => return -3,
    };
    let Some(state) = g.as_mut() else { return -1; };
    if !state.initialized { return -1; }
    let Some(guard) = state.engine.as_mut() else { return -1; };
    let Some(engine) = guard.0.as_mut() else { return -1; };
    match engine.open(kind as u32) {
        Ok((id, initial)) => {
            if let Some(bytes) = initial {
                state.pending_initial.insert(id, bytes);
            }
            id as jint
        }
        Err(_) => -2,
    }
}

/// `external fun nativeInitial(channelId: Int): ByteArray` — initial frame
/// bytes for the channel (empty array if none). Consumed once.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeInitial(
    env: JNIEnv, _class: JClass, channel_id: jint,
) -> jbyteArray {
    let bytes = STATE.lock().ok()
        .and_then(|mut guard| guard.as_mut().map(|s| s.pending_initial.remove(&(channel_id as u32))))
        .flatten()
        .unwrap_or_default();
    match env.byte_array_from_slice(&bytes) {
        Ok(a) => a.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

fn bytes_from_java(env: &JNIEnv, arr: JByteArray) -> Vec<u8> {
    env.convert_byte_array(&arr)
        .map(|v| v.into_iter().map(|b| b as u8).collect())
        .unwrap_or_default()
}

/// `external fun nativeFeed(channelId: Int, data: ByteArray): ByteArray` —
/// feed bytes from the platform transport; returns reply bytes (possibly
/// empty). Errors surface as an empty reply; query nativeStatus() afterwards.
/// Media frames produced by the feed (H.264 AU / AAC-ADTS) are dispatched to
/// the registered Java callbacks (nativeSetFrameCallback/nativeSetAudioCallback)
/// after the engine lock is released.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeFeed(
    mut env: JNIEnv, _class: JClass, channel_id: jint, data: JByteArray,
) -> jbyteArray {
    let input = bytes_from_java(&env, data);
    let mut media_events: Vec<hicar::android_engine::MediaEvent> = Vec::new();
    let (code, reply) = with_engine(|e| {
        let reply = e.feed(channel_id as u32, &input)
            .map(|r| r.unwrap_or_default())?;
        media_events = e.take_media();
        Ok(reply)
    });
    if code != 0 {
        eprintln!("[hellocar] nativeFeed(channel={channel_id}) failed rc={code}");
    } else {
        drain_media(&mut env, &media_events);
    }
    match env.byte_array_from_slice(&reply) {
        Ok(a) => a.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// `external fun nativeHeartbeat(channelId: Int): ByteArray` — DMSDP
/// heartbeat for a negotiated control channel (call every ~1 s).
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeHeartbeat(
    env: JNIEnv, _class: JClass, channel_id: jint,
) -> jbyteArray {
    let (code, reply) = with_engine(|e| {
        e.heartbeat(channel_id as u32)
            .map(|r| r.unwrap_or_default())
    });
    if code != 0 {
        eprintln!("[hellocar] nativeHeartbeat(channel={channel_id}) failed rc={code}");
    }
    match env.byte_array_from_slice(&reply) {
        Ok(a) => a.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// `external fun nativeCloseChannel(channelId: Int): Int`
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeCloseChannel(
    _env: JNIEnv, _class: JClass, channel_id: jint,
) -> jint {
    let (code, _) = with_engine(|e| { e.close(channel_id as u32)?; Ok(Vec::new()) });
    code
}

/// `external fun nativeSetHotspotInfo(ssid: String, password: String, bssid: String,
/// ownerIp: String, clientIp: String, port: Int, frequency: Int): Int`
/// Back-fills the real local-only hotspot parameters into the session engine;
/// the ResourceManager credentials then carry these values.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetHotspotInfo(
    mut env: JNIEnv, _class: JClass,
    ssid: JString, password: JString, bssid: JString, owner_ip: JString, client_ip: JString,
    port: jint, frequency: jint,
) -> jint {
    let ssid: Option<String> = env.get_string(&ssid).ok().map(|v| v.into());
    let password: Option<String> = env.get_string(&password).ok().map(|v| v.into());
    let bssid: Option<String> = env.get_string(&bssid).ok().map(|v| v.into());
    let owner: Option<String> = env.get_string(&owner_ip).ok().map(|v| v.into());
    let client: Option<String> = env.get_string(&client_ip).ok().map(|v| v.into());
    let (ssid, password, bssid, owner, client) = match (ssid, password, bssid, owner, client) {
        (Some(a), Some(b), Some(c), Some(d), Some(e)) => (a, b, c, d, e),
        _ => return -1,
    };
    let (code, _) = with_engine(|e| {
        e.set_hotspot(&ssid, &password, &bssid, &owner, &client, frequency as u32, port as u32)?;
        Ok(Vec::new())
    });
    code
}

/// `external fun nativeSetNegotiateParams(ccmpVersion: Int, encPref: Int): Int`
/// v0.10.3：设置 Nearby 协商响应参数（tag2=CCMP 版本 / tag6=加密偏好），
/// 必须在 openChannel（FE35 accept）之前调用，只影响其后创建的 Negotiator。
/// 手机实测发 tag1=[4]、tag5=[2]，原固定回 [2]/[0] 可能被手机拒绝——参数化用于实车对照。
/// 返回 0 成功；-1 未初始化 / -3 状态锁错误。
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetNegotiateParams(
    _env: JNIEnv, _class: JClass, ccmp_version: jint, enc_pref: jint,
) -> jint {
    let (code, _) = with_engine(|e| {
        e.set_negotiate(ccmp_version as u8, enc_pref as u8);
        Ok(Vec::new())
    });
    code
}

/// `external fun nativeSetBusinessChannel(channel: Int): Int`
/// v0.10.5：设置 FE36 业务端点 RFCOMM 信道号（kind2 响应 uint(channel)）。
/// Android 用 listenUsingRfcommWithServiceRecord 注册 FE36 时信道由系统分配，
/// 原实现固定 24 仅在 BlueZ 静态注册下成立；须反射读取真实信道后注入，
/// 否则手机按响应中的 24 直连 FE36 失败并弹"连接失败，请重试"。
/// channel==0 视为未设置（保持默认 24）。返回 0 成功；-1 未初始化 / -3 状态锁错误。
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetBusinessChannel(
    _env: JNIEnv, _class: JClass, channel: jint,
) -> jint {
    let (code, _) = with_engine(|e| {
        e.set_business_channel(channel as u16);
        Ok(Vec::new())
    });
    code
}

/// `external fun nativeSetVideoParams(w: Int, h: Int, bitrate: Int, vbrMin: Int, vbrMax: Int, fps: Int, gop: Int): Int`
/// v0.10.61：实时设置 HiSight 协商的画面参数，下一次 GET_PARAMETER 立即生效。
/// 这些值原来是编译期写死的字符串，改个分辨率就得重编 .so、重打包、让用户重装一轮；
/// 参数化之后车机主界面的设置面板才能真的调得动。取值做基本夹取：
/// 宽 320..1920 / 高 240..1080 / 码率 0.5~20Mbps / 帧率 10~60 / GOP 1~120。
/// 返回 0（不做 engine 初始化检查——参数是进程级原子量，未初始化也应允许预设）。
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetVideoParams(
    _env: JNIEnv, _class: JClass,
    w: jint, h: jint, bitrate: jint, vbr_min: jint, vbr_max: jint, fps: jint, gop: jint,
) -> jint {
    use std::sync::atomic::Ordering;
    let cw = w.clamp(320, 1920) as u32;
    let ch = h.clamp(240, 1080) as u32;
    let cbr = bitrate.clamp(500_000, 20_000_000) as u32;
    let cmin = vbr_min.clamp(200_000, 20_000_000) as u32;
    let cmax = (vbr_max.max(cmin as i32)).clamp(200_000, 20_000_000) as u32;
    let cfps = fps.clamp(10, 60) as u32;
    let cgop = gop.clamp(1, 120) as u32;
    crate::hicar::hisight::VIDEO_W.store(cw, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_H.store(ch, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_BITRATE.store(cbr, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_VBR_MIN.store(cmin, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_VBR_MAX.store(cmax, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_FPS.store(cfps, Ordering::Relaxed);
    crate::hicar::hisight::VIDEO_GOP.store(cgop, Ordering::Relaxed);
    0
}

/// `external fun nativeSendInput(kind: Int, payload: ByteArray): ByteArray` —
/// packs an input event into the HiSight remotectl wire record(s):
///   kind 0 = touch, payload = [x f32 BE][y f32 BE][action u8] (9 bytes, x/y
///   normalized 0..1 against the negotiated 800x480 display, action
///   0=down/1=up/2=move);
///   kind 1 = key,   payload = [code u8] (0 home/1 back/2 enter/3 left/4 right/
///   5 up/6 down/7 play_pause/8 next/9 previous) — returns down+up records;
///   kind 2 = keyframe request, payload ignored — returns empty bytes and
///   re-arms the engine to wait for the next IDR.
/// Kotlin writes the returned bytes to the HiSight input TCP socket.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSendInput(
    env: JNIEnv, _class: JClass, kind: jint, payload: JByteArray,
) -> jbyteArray {
    let input = bytes_from_java(&env, payload);
    let (code, wire) = with_engine(|e| e.send_input(kind as u32, &input));
    if code != 0 {
        eprintln!("[hellocar] nativeSendInput(kind={kind}) failed rc={code}");
    }
    match env.byte_array_from_slice(&wire) {
        Ok(a) => a.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// `external fun nativeSetAudioPort(port: Int): Int` — injects the Kotlin-bound
/// local UDP port into the DMSDP speaker negotiation (must be called after
/// opening the control channel and before the phone triggers speaker OPTIONS).
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetAudioPort(
    _env: JNIEnv, _class: JClass, port: jint,
) -> jint {
    if port <= 0 || port > 65535 { return -1; }
    let (code, _) = with_engine(|e| {
        e.set_audio_port(port as u16)?;
        Ok(Vec::new())
    });
    code
}

/// `external fun nativeRequestPlay(channelId: Int): ByteArray` — v0.10.35:
/// 重发 HiSight PLAY（PLAY 后视频 0 帧兜底，1111(19) 多次重试才成功的机制）。
/// Kotlin 将返回记录写回 sight RTSP socket。
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeRequestPlay(
    env: JNIEnv, _class: JClass, channel_id: jint,
) -> jbyteArray {
    let (code, wire) = with_engine(|e| e.request_play(channel_id as u32));
    if code != 0 {
        eprintln!("[hellocar] nativeRequestPlay(channel={channel_id}) failed rc={code}");
    }
    match env.byte_array_from_slice(&wire) {
        Ok(a) => a.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

/// `external fun nativeSetFrameCallback(cb: FrameSink?): Int` — registers the
/// Java object receiving H.264 access units (`onFrame(key: Boolean, pts: Long,
/// data: ByteArray)`). Pass null to clear. Callbacks run on the calling
/// thread (the channel read thread) after the engine lock is released.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetFrameCallback(
    env: JNIEnv, _class: JClass, cb: JObject,
) -> jint {
    set_media_sink(true, &env, cb)
}

/// `external fun nativeSetAudioCallback(cb: AudioSink?): Int` — registers the
/// Java object receiving AAC-ADTS frames (`onAudio(pts: Long, data: ByteArray)`).
/// Pass null to clear.
#[no_mangle]
pub extern "system" fn Java_com_hellocar_car_HelloCarBridge_nativeSetAudioCallback(
    env: JNIEnv, _class: JClass, cb: JObject,
) -> jint {
    set_media_sink(false, &env, cb)
}

/// Optional; keeps the library versioned for the runtime.
#[no_mangle]
pub extern "system" fn JNI_OnLoad(_vm: jni::JavaVM, _reserved: *mut c_void) -> jint {
    jni::sys::JNI_VERSION_1_6
}
