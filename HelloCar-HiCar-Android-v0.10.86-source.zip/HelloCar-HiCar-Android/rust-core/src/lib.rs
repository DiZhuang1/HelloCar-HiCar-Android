//! HelloCar HiCar protocol core — Android ARM64 cdylib crate root.
//!
//! `src/hicar` is a copied-and-gated snapshot of the HelloCar protocol core
//! (the upstream core is vendored, never modified). Android platform layers (BlueZ radio,
//! ffmpeg media, multi-process private IPC, HiChain native adapter) are
//! gated out; the Kotlin layer drives the core through the JNI surface in
//! `crate::jni`.
pub mod hicar;
#[cfg(target_os = "android")]
pub mod jni;

/// Crate/ABI version string surfaced to the Kotlin layer.
pub const PROTOCOL_CORE_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Milliseconds since process start, used for engine log timestamps.
/// (std::time::Instant has no stable epoch; a process-relative monotonic
/// counter is exactly what the log needs and is portable across targets.)
pub fn monotonic_millis() -> u128 {
    static START: std::sync::OnceLock<std::time::Instant> = std::sync::OnceLock::new();
    let start = START.get_or_init(std::time::Instant::now);
    start.elapsed().as_millis()
}
